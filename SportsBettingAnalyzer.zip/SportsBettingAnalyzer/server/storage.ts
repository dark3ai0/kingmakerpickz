import { 
  users, type User, type InsertUser,
  sports, type Sport, type InsertSport,
  events, type Event, type InsertEvent,
  odds, type Odds, type InsertOdds,
  recommendations, type Recommendation, type InsertRecommendation,
  bets, type Bet, type InsertBet,
  userPreferences, type UserPreference, type InsertUserPreference,
  betExchangeAccounts, type BetExchangeAccount, type InsertBetExchangeAccount,
  automatedBets, type AutomatedBet, type InsertAutomatedBet,
  exchangeEventMappings, type ExchangeEventMapping, type InsertExchangeEventMapping,
  type EventWithOdds, type RecommendationWithEvent, type BetWithDetails, type AutomatedBetWithDetails,
  type BetExchangeProvider
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBankroll(id: number, bankroll: number): Promise<User | undefined>;
  updateUserRiskLevel(id: number, riskLevel: string): Promise<User | undefined>;
  updateUserUnitSize(id: number, unitSizePercent: number): Promise<User | undefined>;

  // Sports methods
  getAllSports(): Promise<Sport[]>;
  getSport(id: number): Promise<Sport | undefined>;
  createSport(sport: InsertSport): Promise<Sport>;
  updateSportEnabled(id: number, enabled: boolean): Promise<Sport | undefined>;

  // Events methods
  getAllEvents(): Promise<Event[]>;
  getEvent(id: number): Promise<Event | undefined>;
  getEventByExternalId(externalId: string): Promise<Event | undefined>;
  getEventsByStatus(status: string): Promise<Event[]>;
  getUpcomingEvents(limit?: number): Promise<EventWithOdds[]>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEventStatus(id: number, status: string): Promise<Event | undefined>;
  updateEventScores(id: number, homeScore: number, awayScore: number): Promise<Event | undefined>;

  // Odds methods
  getLatestOddsByEventId(eventId: number): Promise<Odds | undefined>;
  createOdds(odds: InsertOdds): Promise<Odds>;

  // Recommendations methods
  getAllRecommendations(): Promise<Recommendation[]>;
  getRecommendationsByEventId(eventId: number): Promise<Recommendation[]>;
  getTopRecommendations(limit?: number): Promise<RecommendationWithEvent[]>;
  createRecommendation(recommendation: InsertRecommendation): Promise<Recommendation>;

  // Bets methods
  getAllBetsByUserId(userId: number): Promise<Bet[]>;
  getBet(id: number): Promise<Bet | undefined>;
  createBet(bet: InsertBet): Promise<Bet>;
  updateBetStatus(id: number, status: string, settled: boolean): Promise<Bet | undefined>;
  getUserBetsWithDetails(userId: number): Promise<BetWithDetails[]>;
  getRecentBetsByUserId(userId: number, limit?: number): Promise<Bet[]>;

  // User Preferences methods
  getUserPreferences(userId: number): Promise<UserPreference | undefined>;
  createUserPreferences(preferences: InsertUserPreference): Promise<UserPreference>;
  updateUserPreferences(userId: number, preferences: Partial<InsertUserPreference>): Promise<UserPreference | undefined>;
  
  // Betting Exchange Account methods
  getBetExchangeAccountsByUserId(userId: number): Promise<BetExchangeAccount[]>;
  getBetExchangeAccount(id: number): Promise<BetExchangeAccount | undefined>;
  createBetExchangeAccount(account: InsertBetExchangeAccount): Promise<BetExchangeAccount>;
  updateBetExchangeAccount(id: number, updates: Partial<InsertBetExchangeAccount>): Promise<BetExchangeAccount | undefined>;
  
  // Automated Bets methods
  getAutomatedBetsByUserId(userId: number): Promise<AutomatedBet[]>;
  getAutomatedBet(id: number): Promise<AutomatedBet | undefined>;
  createAutomatedBet(bet: InsertAutomatedBet): Promise<AutomatedBet>;
  updateAutomatedBet(id: number, updates: Partial<InsertAutomatedBet>): Promise<AutomatedBet | undefined>;
  getAutomatedBetsWithDetails(userId: number): Promise<AutomatedBetWithDetails[]>;
  
  // Exchange Event Mapping methods
  getEventMappingsByProvider(provider: BetExchangeProvider): Promise<ExchangeEventMapping[]>;
  getEventMappingByInternalId(internalEventId: number, provider: BetExchangeProvider): Promise<ExchangeEventMapping | undefined>;
  createEventMapping(mapping: InsertExchangeEventMapping): Promise<ExchangeEventMapping>;
  updateEventMapping(id: number, updates: Partial<InsertExchangeEventMapping>): Promise<ExchangeEventMapping | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private sports: Map<number, Sport>;
  private events: Map<number, Event>;
  private odds: Map<number, Odds>;
  private recommendations: Map<number, Recommendation>;
  private bets: Map<number, Bet>;
  private userPreferences: Map<number, UserPreference>;
  private betExchangeAccounts: Map<number, BetExchangeAccount>;
  private automatedBets: Map<number, AutomatedBet>;
  private exchangeEventMappings: Map<number, ExchangeEventMapping>;
  
  private currentUserId: number;
  private currentSportId: number;
  private currentEventId: number;
  private currentOddsId: number;
  private currentRecommendationId: number;
  private currentBetId: number;
  private currentUserPreferenceId: number;
  private currentBetExchangeAccountId: number;
  private currentAutomatedBetId: number;
  private currentExchangeEventMappingId: number;

  constructor() {
    this.users = new Map();
    this.sports = new Map();
    this.events = new Map();
    this.odds = new Map();
    this.recommendations = new Map();
    this.bets = new Map();
    this.userPreferences = new Map();
    this.betExchangeAccounts = new Map();
    this.automatedBets = new Map();
    this.exchangeEventMappings = new Map();
    
    this.currentUserId = 1;
    this.currentSportId = 1;
    this.currentEventId = 1;
    this.currentOddsId = 1;
    this.currentRecommendationId = 1;
    this.currentBetId = 1;
    this.currentUserPreferenceId = 1;
    this.currentBetExchangeAccountId = 1;
    this.currentAutomatedBetId = 1;
    this.currentExchangeEventMappingId = 1;
    
    // Initialize with sample data for demonstration
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Add sample sports
    const sports = [
      { name: "NFL", enabled: true },
      { name: "NBA", enabled: true },
      { name: "MLB", enabled: true },
      { name: "NHL", enabled: true },
      { name: "UFC/MMA", enabled: true },
      { name: "Soccer", enabled: true },
      { name: "Golf", enabled: true },
      { name: "Tennis", enabled: true },
      { name: "F1", enabled: true },
      { name: "NCAA Football", enabled: true },
      { name: "NCAA Basketball", enabled: true },
      { name: "Boxing", enabled: true }
    ];
    
    sports.forEach(sport => this.createSport(sport));
    
    // Default user
    const defaultUser: InsertUser = {
      username: "demo",
      password: "password",
      bankroll: "5432.10",
      riskLevel: "moderate",
      unitSizePercent: 2
    };
    
    this.createUser(defaultUser);
    
    // Sample events
    const now = new Date();
    const todayEvening = new Date(now);
    todayEvening.setHours(20, 20, 0, 0);
    
    const todayEarlier = new Date(now);
    todayEarlier.setHours(19, 30, 0, 0);
    
    const todayAfternoon = new Date(now);
    todayAfternoon.setHours(13, 10, 0, 0);
    
    const tomorrow = new Date(now);
    tomorrow.setDate(now.getDate() + 1);
    tomorrow.setHours(22, 30, 0, 0);
    
    const tomorrowAfternoon = new Date(now);
    tomorrowAfternoon.setDate(now.getDate() + 1);
    tomorrowAfternoon.setHours(15, 0, 0, 0);
    
    const dayAfterTomorrow = new Date(now);
    dayAfterTomorrow.setDate(now.getDate() + 2);
    dayAfterTomorrow.setHours(19, 0, 0, 0);
    
    const events: InsertEvent[] = [
      // Original events
      {
        sportId: 1, // NFL
        homeTeam: "Kansas City Chiefs",
        awayTeam: "Baltimore Ravens",
        startTime: todayEvening,
        status: "scheduled",
        location: "Arrowhead Stadium",
        externalId: "nfl_101"
      },
      {
        sportId: 2, // NBA
        homeTeam: "Boston Celtics",
        awayTeam: "Miami Heat",
        startTime: todayEarlier,
        status: "scheduled",
        location: "TD Garden",
        externalId: "nba_201"
      },
      {
        sportId: 3, // MLB
        homeTeam: "New York Yankees",
        awayTeam: "Boston Red Sox",
        startTime: todayAfternoon,
        status: "scheduled",
        location: "Yankee Stadium",
        externalId: "mlb_301"
      },
      {
        sportId: 2, // NBA
        homeTeam: "Los Angeles Lakers",
        awayTeam: "Denver Nuggets",
        startTime: tomorrow,
        status: "scheduled",
        location: "Crypto.com Arena",
        externalId: "nba_202"
      },
      
      // UFC/MMA
      {
        sportId: 5, // UFC/MMA
        homeTeam: "Jon Jones",
        awayTeam: "Stipe Miocic",
        startTime: dayAfterTomorrow,
        status: "scheduled",
        location: "T-Mobile Arena, Las Vegas",
        externalId: "ufc_501"
      },
      
      // Soccer
      {
        sportId: 6, // Soccer
        homeTeam: "Manchester City",
        awayTeam: "Liverpool",
        startTime: tomorrow,
        status: "scheduled",
        location: "Etihad Stadium",
        externalId: "soccer_601"
      },
      
      // Golf
      {
        sportId: 7, // Golf
        homeTeam: "Masters Tournament",
        awayTeam: "Round 1",
        startTime: tomorrowAfternoon,
        status: "scheduled",
        location: "Augusta National",
        externalId: "golf_701"
      },
      
      // Tennis
      {
        sportId: 8, // Tennis
        homeTeam: "Novak Djokovic",
        awayTeam: "Carlos Alcaraz",
        startTime: todayEvening,
        status: "scheduled",
        location: "Arthur Ashe Stadium",
        externalId: "tennis_801"
      },
      
      // F1
      {
        sportId: 9, // F1
        homeTeam: "Miami Grand Prix",
        awayTeam: "Qualifying",
        startTime: tomorrowAfternoon,
        status: "scheduled",
        location: "Miami International Autodrome",
        externalId: "f1_901"
      },
      
      // NCAA Football
      {
        sportId: 10, // NCAA Football
        homeTeam: "Alabama",
        awayTeam: "Georgia",
        startTime: todayEvening,
        status: "scheduled",
        location: "Bryant-Denny Stadium",
        externalId: "ncaaf_1001"
      },
      
      // NCAA Basketball
      {
        sportId: 11, // NCAA Basketball
        homeTeam: "Duke",
        awayTeam: "North Carolina",
        startTime: tomorrow,
        status: "scheduled",
        location: "Cameron Indoor Stadium",
        externalId: "ncaab_1101"
      },
      
      // Boxing
      {
        sportId: 12, // Boxing
        homeTeam: "Tyson Fury",
        awayTeam: "Oleksandr Usyk",
        startTime: dayAfterTomorrow,
        status: "scheduled",
        location: "Madison Square Garden",
        externalId: "boxing_1201"
      }
    ];
    
    const eventEntities = events.map(event => this.createEvent(event));
    
    // Sample odds
    const odds: InsertOdds[] = [
      // Original odds
      {
        eventId: 1,
        moneylineHome: -135,
        moneylineAway: 115,
        spreadHome: -3,
        spreadHomeOdds: -110,
        spreadAway: 3,
        spreadAwayOdds: -110,
        totalPoints: 47.5,
        totalOverOdds: -110,
        totalUnderOdds: -110
      },
      {
        eventId: 2,
        moneylineHome: -180,
        moneylineAway: 150,
        spreadHome: -4.5,
        spreadHomeOdds: -110,
        spreadAway: 4.5,
        spreadAwayOdds: -110,
        totalPoints: 218.5,
        totalOverOdds: -110,
        totalUnderOdds: -110
      },
      {
        eventId: 3,
        moneylineHome: -125,
        moneylineAway: 105,
        spreadHome: -1.5,
        spreadHomeOdds: 125,
        spreadAway: 1.5,
        spreadAwayOdds: -145,
        totalPoints: 8.5,
        totalOverOdds: -115,
        totalUnderOdds: -105
      },
      {
        eventId: 4,
        moneylineHome: 165,
        moneylineAway: -195,
        spreadHome: 5,
        spreadHomeOdds: -110,
        spreadAway: -5,
        spreadAwayOdds: -110,
        totalPoints: 224.5,
        totalOverOdds: -110,
        totalUnderOdds: -110
      },
      
      // UFC/MMA odds
      {
        eventId: 5,
        moneylineHome: -250,
        moneylineAway: 210,
        spreadHome: null,
        spreadHomeOdds: null,
        spreadAway: null,
        spreadAwayOdds: null,
        totalPoints: 2.5, // Rounds
        totalOverOdds: -130,
        totalUnderOdds: 110
      },
      
      // Soccer odds
      {
        eventId: 6,
        moneylineHome: -110,
        moneylineAway: 240,
        spreadHome: -1,
        spreadHomeOdds: 105,
        spreadAway: 1,
        spreadAwayOdds: -125,
        totalPoints: 2.5, // Goals
        totalOverOdds: -120,
        totalUnderOdds: 100
      },
      
      // Golf odds
      {
        eventId: 7,
        moneylineHome: null, // Golf typically uses outright winner markets
        moneylineAway: null,
        spreadHome: null,
        spreadHomeOdds: null,
        spreadAway: null,
        spreadAwayOdds: null,
        totalPoints: 69.5, // Score
        totalOverOdds: -110,
        totalUnderOdds: -110
      },
      
      // Tennis odds
      {
        eventId: 8,
        moneylineHome: -160,
        moneylineAway: 140,
        spreadHome: -1.5, // Sets
        spreadHomeOdds: -130,
        spreadAway: 1.5,
        spreadAwayOdds: 110,
        totalPoints: 22.5, // Games
        totalOverOdds: -110,
        totalUnderOdds: -110
      },
      
      // F1 odds
      {
        eventId: 9,
        moneylineHome: null, // F1 typically uses outright winner markets
        moneylineAway: null,
        spreadHome: null,
        spreadHomeOdds: null,
        spreadAway: null,
        spreadAwayOdds: null,
        totalPoints: null,
        totalOverOdds: null,
        totalUnderOdds: null
      },
      
      // NCAA Football odds
      {
        eventId: 10,
        moneylineHome: -220,
        moneylineAway: 180,
        spreadHome: -7.5,
        spreadHomeOdds: -110,
        spreadAway: 7.5,
        spreadAwayOdds: -110,
        totalPoints: 55.5,
        totalOverOdds: -110,
        totalUnderOdds: -110
      },
      
      // NCAA Basketball odds
      {
        eventId: 11,
        moneylineHome: -150,
        moneylineAway: 130,
        spreadHome: -3.5,
        spreadHomeOdds: -110,
        spreadAway: 3.5,
        spreadAwayOdds: -110,
        totalPoints: 145.5,
        totalOverOdds: -110,
        totalUnderOdds: -110
      },
      
      // Boxing odds
      {
        eventId: 12,
        moneylineHome: -140,
        moneylineAway: 120,
        spreadHome: null,
        spreadHomeOdds: null,
        spreadAway: null,
        spreadAwayOdds: null,
        totalPoints: 10.5, // Rounds
        totalOverOdds: -120,
        totalUnderOdds: 100
      }
    ];
    
    odds.forEach(odds => this.createOdds(odds));
    
    // Sample recommendations
    const recommendations: InsertRecommendation[] = [
      // Original recommendations
      {
        eventId: 1,
        strategyType: "moneyline",
        recommendation: "Kansas City Chiefs",
        odds: -135,
        confidence: 78,
        value: 7.85,
        reasoning: "Chiefs have a strong home field advantage and have won 80% of their last 10 home games."
      },
      {
        eventId: 2,
        strategyType: "spread",
        recommendation: "Boston Celtics -4.5",
        odds: -110,
        confidence: 64,
        value: 5.75,
        reasoning: "Celtics have covered the spread in 7 of their last 10 games against Miami."
      },
      {
        eventId: 3,
        strategyType: "total",
        recommendation: "UNDER 8.5",
        odds: -105,
        confidence: 82,
        value: 8.5,
        reasoning: "These teams have gone under in 8 of their last 10 meetings with strong pitching matchups."
      },
      {
        eventId: 4,
        strategyType: "moneyline",
        recommendation: "Denver Nuggets",
        odds: -195,
        confidence: 58,
        value: 4.2,
        reasoning: "Nuggets have won 6 of the last 8 matchups against the Lakers."
      },
      
      // New recommendations for additional sports
      {
        eventId: 5,
        strategyType: "moneyline",
        recommendation: "Jon Jones",
        odds: -250,
        confidence: 75,
        value: 6.8,
        reasoning: "Jones has superior reach and wrestling advantages against Miocic, with a significant youth advantage."
      },
      {
        eventId: 6,
        strategyType: "total",
        recommendation: "UNDER 2.5 Goals",
        odds: 100,
        confidence: 68,
        value: 6.2,
        reasoning: "Both teams have strong defensive records and recent head-to-head meetings have averaged 1.8 goals."
      },
      {
        eventId: 7,
        strategyType: "total",
        recommendation: "UNDER 69.5",
        odds: -110,
        confidence: 62,
        value: 5.5,
        reasoning: "Weather conditions at Augusta National will be challenging with high winds predicted."
      },
      {
        eventId: 8,
        strategyType: "spread",
        recommendation: "Djokovic -1.5 Sets",
        odds: -130,
        confidence: 67,
        value: 6.1,
        reasoning: "Djokovic has won 7 of last 10 matches against Alcaraz in straight sets or 3-1."
      },
      {
        eventId: 10,
        strategyType: "spread",
        recommendation: "Georgia +7.5",
        odds: -110,
        confidence: 73,
        value: 7.1,
        reasoning: "Georgia has covered the spread in 9 of their last 12 games as underdogs."
      },
      {
        eventId: 11,
        strategyType: "total",
        recommendation: "OVER 145.5",
        odds: -110,
        confidence: 71,
        value: 6.8,
        reasoning: "Duke-UNC matchups have averaged 157 points over their last 8 meetings."
      },
      {
        eventId: 12,
        strategyType: "moneyline",
        recommendation: "Usyk",
        odds: 120,
        confidence: 63,
        value: 8.4,
        reasoning: "Usyk's technical ability and movement presents a stylistic challenge for Fury, offering value at plus odds."
      }
    ];
    
    recommendations.forEach(rec => this.createRecommendation(rec));
    
    // User preferences
    this.createUserPreferences({
      userId: 1,
      enabledSports: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], // All sports enabled by default
      minimumConfidence: 60,
      notificationsEnabled: true
    });
    
    // Sample bets
    this.createBet({
      userId: 1,
      recommendationId: 1,
      amount: "108.64",
      placedOdds: -135,
      potentialWin: "80.47"
    });
    
    this.createBet({
      userId: 1,
      recommendationId: 2,
      amount: "108.64",
      placedOdds: -110,
      potentialWin: "98.76"
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserBankroll(id: number, bankroll: number): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, bankroll: bankroll.toString() };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async updateUserRiskLevel(id: number, riskLevel: string): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, riskLevel };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async updateUserUnitSize(id: number, unitSizePercent: number): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, unitSizePercent };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Sports methods
  async getAllSports(): Promise<Sport[]> {
    return Array.from(this.sports.values());
  }
  
  async getSport(id: number): Promise<Sport | undefined> {
    return this.sports.get(id);
  }
  
  async createSport(sport: InsertSport): Promise<Sport> {
    const id = this.currentSportId++;
    const newSport: Sport = { ...sport, id };
    this.sports.set(id, newSport);
    return newSport;
  }
  
  async updateSportEnabled(id: number, enabled: boolean): Promise<Sport | undefined> {
    const sport = this.sports.get(id);
    if (!sport) return undefined;
    
    const updatedSport = { ...sport, enabled };
    this.sports.set(id, updatedSport);
    return updatedSport;
  }

  // Events methods
  async getAllEvents(): Promise<Event[]> {
    return Array.from(this.events.values());
  }
  
  async getEvent(id: number): Promise<Event | undefined> {
    return this.events.get(id);
  }
  
  async getEventByExternalId(externalId: string): Promise<Event | undefined> {
    return Array.from(this.events.values()).find(
      (event) => event.externalId === externalId
    );
  }
  
  async getEventsByStatus(status: string): Promise<Event[]> {
    return Array.from(this.events.values()).filter(
      (event) => event.status === status
    );
  }
  
  async getUpcomingEvents(limit: number = 10): Promise<EventWithOdds[]> {
    const events = Array.from(this.events.values())
      .filter(event => event.status === "scheduled" && new Date(event.startTime) > new Date())
      .sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime())
      .slice(0, limit);
      
    return Promise.all(events.map(async event => {
      const odds = await this.getLatestOddsByEventId(event.id);
      return { ...event, odds };
    }));
  }
  
  async createEvent(event: InsertEvent): Promise<Event> {
    const id = this.currentEventId++;
    const newEvent: Event = { 
      ...event, 
      id, 
      homeScore: null, 
      awayScore: null 
    };
    this.events.set(id, newEvent);
    return newEvent;
  }
  
  async updateEventStatus(id: number, status: string): Promise<Event | undefined> {
    const event = this.events.get(id);
    if (!event) return undefined;
    
    const updatedEvent = { ...event, status };
    this.events.set(id, updatedEvent);
    return updatedEvent;
  }
  
  async updateEventScores(id: number, homeScore: number, awayScore: number): Promise<Event | undefined> {
    const event = this.events.get(id);
    if (!event) return undefined;
    
    const updatedEvent = { ...event, homeScore, awayScore };
    this.events.set(id, updatedEvent);
    return updatedEvent;
  }

  // Odds methods
  async getLatestOddsByEventId(eventId: number): Promise<Odds | undefined> {
    const eventOdds = Array.from(this.odds.values())
      .filter(odds => odds.eventId === eventId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      
    return eventOdds.length > 0 ? eventOdds[0] : undefined;
  }
  
  async createOdds(odds: InsertOdds): Promise<Odds> {
    const id = this.currentOddsId++;
    const newOdds: Odds = { ...odds, id, timestamp: new Date() };
    this.odds.set(id, newOdds);
    return newOdds;
  }

  // Recommendations methods
  async getAllRecommendations(): Promise<Recommendation[]> {
    return Array.from(this.recommendations.values());
  }
  
  async getRecommendationsByEventId(eventId: number): Promise<Recommendation[]> {
    return Array.from(this.recommendations.values())
      .filter(rec => rec.eventId === eventId);
  }
  
  async getTopRecommendations(limit: number = 3): Promise<RecommendationWithEvent[]> {
    const topRecs = Array.from(this.recommendations.values())
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, limit);
      
    return Promise.all(topRecs.map(async rec => {
      const event = await this.getEvent(rec.eventId);
      if (!event) throw new Error(`Event not found for recommendation ${rec.id}`);
      
      const odds = await this.getLatestOddsByEventId(event.id);
      return { 
        ...rec, 
        event: { ...event, odds } 
      };
    }));
  }
  
  async createRecommendation(recommendation: InsertRecommendation): Promise<Recommendation> {
    const id = this.currentRecommendationId++;
    const newRecommendation: Recommendation = { 
      ...recommendation, 
      id, 
      timestamp: new Date() 
    };
    this.recommendations.set(id, newRecommendation);
    return newRecommendation;
  }

  // Bets methods
  async getAllBetsByUserId(userId: number): Promise<Bet[]> {
    return Array.from(this.bets.values())
      .filter(bet => bet.userId === userId);
  }
  
  async getBet(id: number): Promise<Bet | undefined> {
    return this.bets.get(id);
  }
  
  async createBet(bet: InsertBet): Promise<Bet> {
    const id = this.currentBetId++;
    const newBet: Bet = { 
      ...bet, 
      id, 
      status: "pending", 
      settled: false,
      createdAt: new Date(),
      settledAt: null
    };
    this.bets.set(id, newBet);
    return newBet;
  }
  
  async updateBetStatus(id: number, status: string, settled: boolean): Promise<Bet | undefined> {
    const bet = this.bets.get(id);
    if (!bet) return undefined;
    
    const updatedBet: Bet = { 
      ...bet, 
      status, 
      settled,
      settledAt: settled ? new Date() : null
    };
    this.bets.set(id, updatedBet);
    return updatedBet;
  }
  
  async getUserBetsWithDetails(userId: number): Promise<BetWithDetails[]> {
    const userBets = await this.getAllBetsByUserId(userId);
    
    return Promise.all(userBets.map(async bet => {
      const recommendation = await this.recommendations.get(bet.recommendationId);
      if (!recommendation) throw new Error(`Recommendation not found for bet ${bet.id}`);
      
      const event = await this.getEvent(recommendation.eventId);
      if (!event) throw new Error(`Event not found for recommendation ${recommendation.id}`);
      
      const odds = await this.getLatestOddsByEventId(event.id);
      
      return {
        ...bet,
        recommendation: {
          ...recommendation,
          event: { ...event, odds }
        }
      };
    }));
  }
  
  async getRecentBetsByUserId(userId: number, limit: number = 5): Promise<Bet[]> {
    return (await this.getAllBetsByUserId(userId))
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
  }

  // User Preferences methods
  async getUserPreferences(userId: number): Promise<UserPreference | undefined> {
    return Array.from(this.userPreferences.values())
      .find(pref => pref.userId === userId);
  }
  
  async createUserPreferences(preferences: InsertUserPreference): Promise<UserPreference> {
    const id = this.currentUserPreferenceId++;
    const newPreferences: UserPreference = { ...preferences, id };
    this.userPreferences.set(id, newPreferences);
    return newPreferences;
  }
  
  async updateUserPreferences(userId: number, preferences: Partial<InsertUserPreference>): Promise<UserPreference | undefined> {
    const userPrefs = Array.from(this.userPreferences.values())
      .find(pref => pref.userId === userId);
      
    if (!userPrefs) return undefined;
    
    const updatedPrefs: UserPreference = { 
      ...userPrefs,
      ...preferences
    };
    this.userPreferences.set(userPrefs.id, updatedPrefs);
    return updatedPrefs;
  }

  // Betting Exchange Account methods
  async getBetExchangeAccountsByUserId(userId: number): Promise<BetExchangeAccount[]> {
    return Array.from(this.betExchangeAccounts.values()).filter(
      (account) => account.userId === userId
    );
  }

  async getBetExchangeAccount(id: number): Promise<BetExchangeAccount | undefined> {
    return this.betExchangeAccounts.get(id);
  }

  async createBetExchangeAccount(account: InsertBetExchangeAccount): Promise<BetExchangeAccount> {
    const id = this.currentBetExchangeAccountId++;
    const newAccount: BetExchangeAccount = {
      ...account,
      id,
      lastAuthenticated: new Date(),
      createdAt: new Date()
    };
    this.betExchangeAccounts.set(id, newAccount);
    return newAccount;
  }

  async updateBetExchangeAccount(id: number, updates: Partial<InsertBetExchangeAccount>): Promise<BetExchangeAccount | undefined> {
    const account = this.betExchangeAccounts.get(id);
    if (!account) return undefined;

    const updatedAccount: BetExchangeAccount = {
      ...account,
      ...updates,
      lastAuthenticated: new Date()
    };
    this.betExchangeAccounts.set(id, updatedAccount);
    return updatedAccount;
  }

  // Automated Bets methods
  async getAutomatedBetsByUserId(userId: number): Promise<AutomatedBet[]> {
    return Array.from(this.automatedBets.values()).filter(
      (bet) => bet.userId === userId
    );
  }

  async getAutomatedBet(id: number): Promise<AutomatedBet | undefined> {
    return this.automatedBets.get(id);
  }

  async createAutomatedBet(bet: InsertAutomatedBet): Promise<AutomatedBet> {
    const id = this.currentAutomatedBetId++;
    const newBet: AutomatedBet = {
      ...bet,
      id,
      status: "pending",
      exchangeBetId: null,
      matchedPrice: null,
      errorMessage: null,
      createdAt: new Date(),
      executedAt: null
    };
    this.automatedBets.set(id, newBet);
    return newBet;
  }

  async updateAutomatedBet(id: number, updates: Partial<InsertAutomatedBet>): Promise<AutomatedBet | undefined> {
    const bet = this.automatedBets.get(id);
    if (!bet) return undefined;

    const updatedBet: AutomatedBet = {
      ...bet,
      ...updates
    };
    this.automatedBets.set(id, updatedBet);
    return updatedBet;
  }

  async getAutomatedBetsWithDetails(userId: number): Promise<AutomatedBetWithDetails[]> {
    const automatedBets = await this.getAutomatedBetsByUserId(userId);
    
    const betsWithDetails: AutomatedBetWithDetails[] = await Promise.all(automatedBets.map(async (bet) => {
      let internalBet: Bet | undefined;
      if (bet.betId) {
        internalBet = await this.getBet(bet.betId);
      }

      const exchangeDetails = {
        eventName: "N/A", // In a real implementation, you would fetch these details from the exchange API
        marketName: "N/A",
        selectionName: "N/A"
      };

      return {
        ...bet,
        internalBet,
        exchangeDetails
      };
    }));

    return betsWithDetails;
  }

  // Exchange Event Mapping methods
  async getEventMappingsByProvider(provider: BetExchangeProvider): Promise<ExchangeEventMapping[]> {
    return Array.from(this.exchangeEventMappings.values()).filter(
      (mapping) => mapping.provider === provider
    );
  }

  async getEventMappingByInternalId(internalEventId: number, provider: BetExchangeProvider): Promise<ExchangeEventMapping | undefined> {
    return Array.from(this.exchangeEventMappings.values()).find(
      (mapping) => mapping.internalEventId === internalEventId && mapping.provider === provider
    );
  }

  async createEventMapping(mapping: InsertExchangeEventMapping): Promise<ExchangeEventMapping> {
    const id = this.currentExchangeEventMappingId++;
    const newMapping: ExchangeEventMapping = {
      ...mapping,
      id,
      lastUpdated: new Date()
    };
    this.exchangeEventMappings.set(id, newMapping);
    return newMapping;
  }

  async updateEventMapping(id: number, updates: Partial<InsertExchangeEventMapping>): Promise<ExchangeEventMapping | undefined> {
    const mapping = this.exchangeEventMappings.get(id);
    if (!mapping) return undefined;

    const updatedMapping: ExchangeEventMapping = {
      ...mapping,
      ...updates,
      lastUpdated: new Date()
    };
    this.exchangeEventMappings.set(id, updatedMapping);
    return updatedMapping;
  }
}

export const storage = new MemStorage();

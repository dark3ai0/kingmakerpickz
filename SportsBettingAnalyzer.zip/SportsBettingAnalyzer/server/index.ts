import express from "express";
import routes from "./routes";
import { setupVite, serveStatic, log } from "./vite";

const app = express();
app.use(express.json());

// API logging middleware
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;

  res.on("finish", () => {
    if (path.startsWith("/api")) {
      const duration = Date.now() - start;
      log(`${req.method} ${path} ${res.statusCode} in ${duration}ms`);
    }
  });
  next();
});

// API routes
app.use("/api", routes);

// Error handling
app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  const status = err.status || err.statusCode || 500;
  const message = err.message || "Internal Server Error";
  res.status(status).json({ message });
});

// Setup Vite or static serving
if (app.get("env") === "development") {
  setupVite(app);
} else {
  serveStatic(app);
}

// Start server
app.listen(5000, "0.0.0.0", () => {
  log("Server running on port 5000");
});
import express, { Router } from "express";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertUserSchema, 
  insertBetSchema,
  BetExchangeProvider
} from "@shared/schema";
import { generateRecommendations } from "./lib/strategies";
import { getSportsData } from "./lib/sportsDataApi";
import { generatePodcastScript } from "./lib/geminiApi";
import { authenticateWithExchange, getOddsForMarket as getExchangeOdds, placeBet, getAccountBalance } from "./lib/betExchangeApi";
import { DEFAULT_USER_ID } from "./constants";

const router = Router();

// User routes
router.get("/user/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ message: "Invalid user ID" });

  const user = await storage.getUser(id);
  if (!user) return res.status(404).json({ message: "User not found" });

  const { password, ...userWithoutPassword } = user;
  res.json(userWithoutPassword);
});

router.post("/user", async (req, res) => {
  try {
    const userData = insertUserSchema.parse(req.body);
    const existingUser = await storage.getUserByUsername(userData.username);
    if (existingUser) return res.status(409).json({ message: "Username exists" });

    const user = await storage.createUser(userData);
    const { password, ...userWithoutPassword } = user;
    res.status(201).json(userWithoutPassword);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Invalid data", errors: error.errors });
    }
    res.status(500).json({ message: "Error creating user" });
  }
});

router.patch("/user/:id/bankroll", async (req: express.Request, res: express.Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const { bankroll } = req.body;
    if (typeof bankroll !== "number" || bankroll < 0) {
      return res.status(400).json({ message: "Invalid bankroll amount" });
    }
    
    const updatedUser = await storage.updateUserBankroll(id, bankroll);
    if (!updatedUser) {
      return res.status(404).json({ message: "User not found" });
    }
    
    const { password, ...userWithoutPassword } = updatedUser;
    res.json(userWithoutPassword);
  });

router.patch("/user/:id/risk-level", async (req: express.Request, res: express.Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const { riskLevel } = req.body;
    if (!["low", "moderate", "high"].includes(riskLevel)) {
      return res.status(400).json({ message: "Invalid risk level" });
    }
    
    const updatedUser = await storage.updateUserRiskLevel(id, riskLevel);
    if (!updatedUser) {
      return res.status(404).json({ message: "User not found" });
    }
    
    const { password, ...userWithoutPassword } = updatedUser;
    res.json(userWithoutPassword);
  });

router.patch("/user/:id/unit-size", async (req: express.Request, res: express.Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const { unitSizePercent } = req.body;
    if (typeof unitSizePercent !== "number" || unitSizePercent <= 0 || unitSizePercent > 10) {
      return res.status(400).json({ message: "Invalid unit size percentage" });
    }
    
    const updatedUser = await storage.updateUserUnitSize(id, unitSizePercent);
    if (!updatedUser) {
      return res.status(404).json({ message: "User not found" });
    }
    
    const { password, ...userWithoutPassword } = updatedUser;
    res.json(userWithoutPassword);
  });


// Betting routes
router.post("/bets", async (req, res) => {
  try {
    const betData = insertBetSchema.parse(req.body);
    const user = await storage.getUser(betData.userId);
    if (!user) return res.status(404).json({ message: "User not found" });

    const recommendation = await storage.getRecommendation(betData.recommendationId);
    if (!recommendation) return res.status(404).json({ message: "Recommendation not found" });

    const bet = await storage.createBet(betData);
    const newBankroll = parseFloat(user.bankroll) - parseFloat(betData.amount);
    await storage.updateUserBankroll(user.id, newBankroll);

    res.status(201).json(bet);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: "Invalid data", errors: error.errors });
    }
    res.status(500).json({ message: "Error creating bet" });
  }
});

router.get("/bets/user/:userId", async (req, res) => {
  const userId = parseInt(req.params.userId);
  if (isNaN(userId)) return res.status(400).json({ message: "Invalid user ID" });

  const bets = await storage.getAllBetsByUserId(userId);
  res.json(bets);
});

router.get("/bets/:id", async (req: express.Request, res: express.Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid bet ID" });
    }
    
    const bet = await storage.getBet(id);
    if (!bet) {
      return res.status(404).json({ message: "Bet not found" });
    }
    
    res.json(bet);
  });

router.get("/bets/user/:userId/details", async (req: express.Request, res: express.Response) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const betsWithDetails = await storage.getUserBetsWithDetails(userId);
    res.json(betsWithDetails);
  });


// Sports data routes 
router.get("/events/upcoming", async (req, res) => {
  const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
  const events = await storage.getUpcomingEvents(limit);
  res.json(events);
});

router.get("/sports", async (_req: express.Request, res: express.Response) => {
    const sports = await storage.getAllSports();
    res.json(sports);
  });

router.get("/events", async (_req: express.Request, res: express.Response) => {
    const events = await storage.getAllEvents();
    res.json(events);
  });

router.get("/events/:id", async (req: express.Request, res: express.Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid event ID" });
    }
    
    const event = await storage.getEvent(id);
    if (!event) {
      return res.status(404).json({ message: "Event not found" });
    }
    
    const odds = await storage.getLatestOddsByEventId(id);
    res.json({ ...event, odds });
  });

router.post("/refresh-data", async (_req, res) => {
  try {
    const data = await getSportsData();
    res.json({ message: "Sports data refreshed successfully", data });
  } catch (error) {
    res.status(500).json({ message: "Error refreshing sports data" });
  }
});

// AI Analysis routes
router.post("/ai/analyze", async (req, res) => {
  try {
    const { eventId, matchup, betType } = req.body;
    if (!matchup || !betType) return res.status(400).json({ message: "Missing parameters" });

    const analysis = await generatePodcastScript(matchup, "preview");
    if (eventId) {
      await storage.createAiAnalysis({
        eventId,
        userId: DEFAULT_USER_ID,
        query: `Analysis for ${matchup}, ${betType}`,
        response: analysis,
        analysisType: 'event'
      });
    }
    res.json({ analysis });
  } catch (error) {
    res.status(500).json({ message: "Failed to generate analysis" });
  }
});

router.get("/recommendations", async (_req: express.Request, res: express.Response) => {
    const recommendations = await storage.getAllRecommendations();
    res.json(recommendations);
  });

router.get("/recommendations/top", async (req: express.Request, res: express.Response) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 3;
    const topRecommendations = await storage.getTopRecommendations(limit);
    res.json(topRecommendations);
  });

router.get("/recommendations/event/:eventId", async (req: express.Request, res: express.Response) => {
    const eventId = parseInt(req.params.eventId);
    if (isNaN(eventId)) {
      return res.status(400).json({ message: "Invalid event ID" });
    }
    
    const recommendations = await storage.getRecommendationsByEventId(eventId);
    res.json(recommendations);
  });


// Exchange integration routes
router.post("/exchange/auth", async (req, res) => {
  try {
    const { provider, credentials, userId } = req.body;
    if (!provider || !credentials || !userId) {
      return res.status(400).json({ message: "Missing parameters" });
    }

    const sessionToken = await authenticateWithExchange(provider as BetExchangeProvider, credentials);
    const account = await storage.createBetExchangeAccount({
      userId,
      provider,
      username: credentials.username || 'unknown',
      token: sessionToken,
      active: true
    });

    const { token, ...accountWithoutToken } = account;
    res.json({ success: true, account: accountWithoutToken });
  } catch (error) {
    res.status(500).json({ success: false, message: "Authentication failed" });
  }
});

router.post("/exchange/place-bet", async (req, res) => {
  try {
    const { accountId, eventId, marketId, selectionId, betType, stake, price } = req.body;
    if (!accountId || !eventId || !marketId || !selectionId || !betType || !stake || !price) {
      return res.status(400).json({ message: "Missing parameters" });
    }

    const account = await storage.getBetExchangeAccount(parseInt(accountId));
    if (!account) return res.status(404).json({ message: "Account not found" });

    const betResult = await placeBet(account.provider as BetExchangeProvider, account.token, {
      provider: account.provider as BetExchangeProvider,
      eventId,
      marketId,
      selectionId,
      betType: betType as 'back' | 'lay',
      stake: parseFloat(stake),
      price: parseFloat(price)
    });

    res.json({ success: true, bet: betResult });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to place bet" });
  }
});

router.get("/bet-exchange/accounts/user/:userId", async (req: express.Request, res: express.Response) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const accounts = await storage.getBetExchangeAccountsByUserId(userId);
    
    // Don't send tokens in the response for security
    const accountsWithoutTokens = accounts.map(account => {
      const { token, ...accountWithoutToken } = account;
      return accountWithoutToken;
    });
    
    res.json(accountsWithoutTokens);
  });

router.post("/bet-exchange/accounts", async (req: express.Request, res: express.Response) => {
    try {
      const accountData = insertBetExchangeAccountSchema.parse(req.body);
      const user = await storage.getUser(accountData.userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const account = await storage.createBetExchangeAccount(accountData);
      
      // Don't send token in the response for security
      const { token, ...accountWithoutToken } = account;
      res.status(201).json(accountWithoutToken);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid account data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating bet exchange account" });
    }
  });

router.patch("/bet-exchange/accounts/:id", async (req: express.Request, res: express.Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid account ID" });
    }
    
    try {
      const account = await storage.getBetExchangeAccount(id);
      if (!account) {
        return res.status(404).json({ message: "Account not found" });
      }
      
      // Update account
      const updatedAccount = await storage.updateBetExchangeAccount(id, req.body);
      
      // Don't send token in the response for security
      const { token, ...accountWithoutToken } = updatedAccount!;
      res.json(accountWithoutToken);
    } catch (error) {
      res.status(500).json({ message: "Error updating bet exchange account" });
    }
  });

router.get("/bet-exchange/odds/:accountId/:eventId", async (req: express.Request, res: express.Response) => {
    const accountId = parseInt(req.params.accountId);
    const eventId = parseInt(req.params.eventId);
    
    if (isNaN(accountId) || isNaN(eventId)) {
      return res.status(400).json({ message: "Invalid account ID or event ID" });
    }
    
    try {
      // Get the account for authentication
      const account = await storage.getBetExchangeAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "Account not found" });
      }
      
      // Get the event mapping
      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      // Find the mapping for this event and provider
      const mapping = await storage.getEventMappingByInternalId(eventId, account.provider as BetExchangeProvider);
      if (!mapping) {
        return res.status(404).json({ message: "No exchange mapping found for this event" });
      }
      
      // Get odds from the exchange
      const exchangeOdds = await getExchangeOdds(
        account.provider as BetExchangeProvider,
        account.token,
        mapping.exchangeEventId
      );
      
      res.json(exchangeOdds);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error getting exchange odds", 
        error: error.message 
      });
    }
  });

  router.get("/bet-exchange/event-mappings/:provider", async (req: express.Request, res: express.Response) => {
    const { provider } = req.params;
    
    // Validate provider
    if (!['betfair', 'pinnacle', 'draftkings', 'fanduel', 'betmgm'].includes(provider)) {
      return res.status(400).json({ message: "Invalid exchange provider" });
    }
    
    const mappings = await storage.getEventMappingsByProvider(provider as BetExchangeProvider);
    res.json(mappings);
  });

  router.post("/bet-exchange/event-mappings", async (req: express.Request, res: express.Response) => {
    try {
      const mappingData = insertExchangeEventMappingSchema.parse(req.body);
      
      // Verify the internal event exists
      const event = await storage.getEvent(mappingData.internalEventId);
      if (!event) {
        return res.status(404).json({ message: "Internal event not found" });
      }
      
      // Verify no duplicate mapping exists
      const existingMapping = await storage.getEventMappingByInternalId(
        mappingData.internalEventId, 
        mappingData.provider
      );
      
      if (existingMapping) {
        return res.status(409).json({ message: "Mapping already exists for this event and provider" });
      }
      
      const mapping = await storage.createEventMapping(mappingData);
      res.status(201).json(mapping);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid mapping data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating exchange event mapping" });
    }
  });

  router.patch("/bet-exchange/event-mappings/:id", async (req: express.Request, res: express.Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid mapping ID" });
    }
    
    try {
      // First check if mapping exists
      const mapping = await storage.getEventMappingByInternalId(id, req.body.provider);
      if (!mapping) {
        return res.status(404).json({ message: "Mapping not found" });
      }
      
      // Update mapping
      const updatedMapping = await storage.updateEventMapping(id, req.body);
      res.json(updatedMapping);
    } catch (error) {
      res.status(500).json({ message: "Error updating exchange event mapping" });
    }
  });

  router.get("/automated-bets/user/:userId", async (req: express.Request, res: express.Response) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const bets = await storage.getAutomatedBetsByUserId(userId);
    res.json(bets);
  });

  router.get("/automated-bets/:id", async (req: express.Request, res: express.Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid automated bet ID" });
    }
    
    const bet = await storage.getAutomatedBet(id);
    if (!bet) {
      return res.status(404).json({ message: "Automated bet not found" });
    }
    
    res.json(bet);
  });

  router.post("/automated-bets", async (req: express.Request, res: express.Response) => {
    try {
      const betData = insertAutomatedBetSchema.parse(req.body);
      const user = await storage.getUser(betData.userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Verify the exchange account exists
      const account = await storage.getBetExchangeAccount(betData.accountId);
      if (!account) {
        return res.status(404).json({ message: "Bet exchange account not found" });
      }
      
      // Create the automated bet
      const automatedBet = await storage.createAutomatedBet(betData);
      res.status(201).json(automatedBet);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid automated bet data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating automated bet" });
    }
  });

  router.patch("/automated-bets/:id", async (req: express.Request, res: express.Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid automated bet ID" });
    }
    
    try {
      const bet = await storage.getAutomatedBet(id);
      if (!bet) {
        return res.status(404).json({ message: "Automated bet not found" });
      }
      
      // Update automated bet
      const updatedBet = await storage.updateAutomatedBet(id, req.body);
      res.json(updatedBet);
    } catch (error) {
      res.status(500).json({ message: "Error updating automated bet" });
    }
  });

  router.get("/automated-bets/user/:userId/details", async (req: express.Request, res: express.Response) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const betsWithDetails = await storage.getAutomatedBetsWithDetails(userId);
    res.json(betsWithDetails);
  });

  router.get("/preferences/user/:userId", async (req: express.Request, res: express.Response) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const preferences = await storage.getUserPreferences(userId);
    if (!preferences) {
      return res.status(404).json({ message: "User preferences not found" });
    }
    
    res.json(preferences);
  });

  router.post("/preferences", async (req: express.Request, res: express.Response) => {
    try {
      const preferencesData = insertUserPreferenceSchema.parse(req.body);
      const user = await storage.getUser(preferencesData.userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const existingPreferences = await storage.getUserPreferences(preferencesData.userId);
      if (existingPreferences) {
        return res.status(409).json({ message: "User preferences already exist" });
      }
      
      const preferences = await storage.createUserPreferences(preferencesData);
      res.status(201).json(preferences);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid preferences data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating user preferences" });
    }
  });

  router.patch("/preferences/user/:userId", async (req: express.Request, res: express.Response) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    try {
      // Partially validate the request body
      const updatedPreferences = await storage.updateUserPreferences(userId, req.body);
      if (!updatedPreferences) {
        return res.status(404).json({ message: "User preferences not found" });
      }
      
      res.json(updatedPreferences);
    } catch (error) {
      res.status(500).json({ message: "Error updating user preferences" });
    }
  });

  router.post("/quickpick", async (req: express.Request, res: express.Response) => {
    try {
      const { sport, betType, amount = 10 } = req.body;
      
      const quickPick = await generateQuickPick(sport, betType, amount);
      
      // Store the quick pick as an AI analysis
      await storage.createAiAnalysis({
        userId: DEFAULT_USER_ID,
        query: `Quick pick for ${sport || 'any sport'}, ${betType || 'any bet type'}`,
        response: JSON.stringify(quickPick),
        analysisType: 'quickpick'
      });
      
      res.json(quickPick);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate quick pick" });
    }
  });
  
  router.post("/analyze-bet", async (req: express.Request, res: express.Response) => {
    try {
      const { event, betType, pick, odds } = req.body;
      
      if (!event || !betType || !pick) {
        return res.status(400).json({ message: "Missing required parameters" });
      }
      
      // Use the enhanced edge analysis system when odds are provided
      if (odds) {
        const edgeAnalysis = await import('./lib/edgeAnalysis');
        const result = await edgeAnalysis.analyzeBetForEdge(event, betType, pick, odds);
        return res.json(result);
      }
      
      // Fall back to simpler analysis if odds not provided
      const analysis = await analyzeBet(event, betType, pick);
      
      res.json(analysis);
    } catch (error) {
      res.status(500).json({ message: "Failed to analyze bet" });
    }
  });

  router.post("/schedule-bet", async (req: express.Request, res: express.Response) => {
    try {
      const { 
        userId, 
        eventId, 
        betType, 
        pick, 
        amount, 
        odds, 
        scheduledDate, 
        reminderEnabled, 
        reminderTime 
      } = req.body;
      
      if (!userId || !eventId || !betType || !pick || !amount || !odds || !scheduledDate) {
        return res.status(400).json({ message: "Missing required parameters" });
      }
      
      const edgeAnalysis = await import('./lib/edgeAnalysis');
      const scheduledBet = await edgeAnalysis.scheduleBet(
        userId,
        eventId,
        betType,
        pick,
        amount,
        odds,
        new Date(scheduledDate),
        reminderEnabled,
        reminderTime
      );
      
      // If reminder is enabled, create a reminder
      if (reminderEnabled && reminderTime) {
        const event = await storage.getEvent(eventId);
        if (event) {
          await edgeAnalysis.createBetReminder(
            userId,
            scheduledBet.id,
            eventId,
            reminderTime,
            new Date(event.startTime)
          );
        }
      }
      
      res.json(scheduledBet);
    } catch (error) {
      res.status(500).json({ message: "Error scheduling bet" });
    }
  });
  
  router.get("/edge-bets", async (req: express.Request, res: express.Response) => {
    try {
      const count = req.query.count ? parseInt(req.query.count as string) : 3;
      
      const events = await storage.getUpcomingEvents(10);
      if (!events || events.length === 0) {
        return res.json([]);
      }
      
      const edgeAnalysis = await import('./lib/edgeAnalysis');
      const edgeBets = await edgeAnalysis.findBestEdgeBets(events, count);
      
      res.json(edgeBets || []);
    } catch (error) {
      console.error('Edge bets error:', error);
      res.json([]); // Return empty array instead of error
    }
  });
  
  router.get("/betting-tips", async (req: express.Request, res: express.Response) => {
    try {
      const count = req.query.count ? parseInt(req.query.count as string) : 3;
      
      const tips = await generateBettingTips(count);
      
      res.json(tips);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate betting tips" });
    }
  });
  
  router.post("/bankroll/calculate-bet-size", async (req: express.Request, res: express.Response) => {
    try {
      const { 
        bankroll, 
        riskLevel = 'medium', 
        confidence = 5, 
        winProbability = 0.5, 
        odds = -110, 
        startingBankroll,
        recentResults = [],
        unitSizePercent = 2
      } = req.body;
      
      // Validate required parameters
      if (!bankroll || typeof bankroll !== "number" || bankroll <= 0) {
        return res.status(400).json({ message: "Invalid bankroll amount" });
      }
      
      // Validate risk level
      if (!["low", "medium", "high"].includes(riskLevel)) {
        return res.status(400).json({ message: "Invalid risk level (must be 'low', 'medium', or 'high')" });
      }
      
      // Validate confidence (1-10 scale)
      if (typeof confidence !== "number" || confidence < 1 || confidence > 10) {
        return res.status(400).json({ message: "Invalid confidence value (must be 1-10)" });
      }
      
      // Validate win probability (0-1 scale)
      if (typeof winProbability !== "number" || winProbability <= 0 || winProbability >= 1) {
        return res.status(400).json({ message: "Invalid win probability (must be between 0 and 1)" });
      }
      
      // Use starting bankroll if provided, otherwise use current
      const effectiveStartingBankroll = startingBankroll || bankroll;
      
      // Calculate optimal bet size using multiple algorithms
      const result = calculateOptimalBetSize(
        bankroll,
        riskLevel,
        confidence,
        winProbability,
        odds,
        effectiveStartingBankroll,
        recentResults,
        unitSizePercent
      );
      
      res.json(result);
    } catch (error) {
      console.error("Error in bankroll management:", error);
      res.status(500).json({ message: "Failed to calculate optimal bet size" });
    }
  });

  router.get("/crypto/wallets/user/:userId", async (req: express.Request, res: express.Response) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const wallets = await storage.getCryptoWallets(userId);
    res.json(wallets);
  });
  
  router.post("/crypto/wallets", async (req: express.Request, res: express.Response) => {
    try {
      const walletData = insertCryptoWalletSchema.parse(req.body);
      const wallet = await storage.createCryptoWallet(walletData);
      res.status(201).json(wallet);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid wallet data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating wallet" });
    }
  });
  
  router.patch("/crypto/wallets/:id", async (req: express.Request, res: express.Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid wallet ID" });
    }
    
    const updatedWallet = await storage.updateCryptoWallet(id, req.body);
    if (!updatedWallet) {
      return res.status(404).json({ message: "Wallet not found" });
    }
    
    res.json(updatedWallet);
  });

  router.post("/podcast/event", async (req: express.Request, res: express.Response) => {
    try {
      const { event, type = 'preview' } = req.body;
      
      if (!event) {
        return res.status(400).json({ message: "Missing required event parameter" });
      }
      
      const script = await generatePodcastScript(event, type as 'preview' | 'recap');
      
      // Store the podcast script
      await storage.createAiAnalysis({
        userId: DEFAULT_USER_ID,
        query: `${type} podcast for ${event}`,
        response: script,
        analysisType: 'podcast'
      });
      
      // Always return a 200 response since we'll fall back to generated content
      res.json({ 
        script, 
        info: !process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY.trim() === '' 
          ? 'Using fallback podcast script (no API key provided)' 
          : undefined 
      });
    } catch (error) {
      console.error('Error in podcast event API:', error);
      // Instead of returning a 500, use fallback content from geminiApi.ts
      const fallbackScript = getFallbackPodcastScript(event, type as 'preview' | 'recap');
      res.json({ 
        script: fallbackScript,
        info: 'Using fallback podcast script due to API error' 
      });
    }
  });
  
  router.get("/podcast/top-picks", async (_req: express.Request, res: express.Response) => {
    try {
      const script = await generateTopPicksPodcast();
      
      // Store the podcast script
      await storage.createAiAnalysis({
        userId: DEFAULT_USER_ID,
        query: "Top picks podcast",
        response: script,
        analysisType: 'podcast'
      });
      
      // Always return a 200 response since we'll fall back to generated content
      res.json({ 
        script, 
        info: !process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY.trim() === '' 
          ? 'Using fallback podcast script (no API key provided)' 
          : undefined 
      });
    } catch (error) {
      console.error('Error in top picks podcast API:', error);
      // Instead of returning a 500, use fallback and return success
      const fallbackScript = await generateTopPicksPodcast();
      res.json({ 
        script: fallbackScript,
        info: 'Using fallback podcast script due to API error' 
      });
    }
  });
  
  router.post("/podcast/strategy", async (req: express.Request, res: express.Response) => {
    try {
      const { strategy } = req.body;
      
      if (!strategy) {
        return res.status(400).json({ message: "Missing required strategy parameter" });
      }
      
      const script = await generateStrategyPodcast(strategy);
      
      // Store the podcast script
      await storage.createAiAnalysis({
        userId: DEFAULT_USER_ID,
        query: `Strategy podcast for ${strategy}`,
        response: script,
        analysisType: 'podcast'
      });
      
      // Always return a 200 response since we'll fall back to generated content
      res.json({ 
        script, 
        info: !process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY.trim() === '' 
          ? 'Using fallback podcast script (no API key provided)' 
          : undefined 
      });
    } catch (error) {
      console.error('Error in strategy podcast API:', error);
      // Instead of returning a 500, use fallback and return success
      const fallbackScript = await generateStrategyPodcast(strategy);
      res.json({ 
        script: fallbackScript,
        info: 'Using fallback podcast script due to API error' 
      });
    }
  });

  router.get("/widgets/user/:userId", async (req: express.Request, res: express.Response) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const widgets = await storage.getDashboardWidgets(userId);
    res.json(widgets);
  });
  
  router.post("/widgets", async (req: express.Request, res: express.Response) => {
    try {
      const widgetData = insertDashboardWidgetSchema.parse(req.body);
      const widget = await storage.createDashboardWidget(widgetData);
      res.status(201).json(widget);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid widget data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating widget" });
    }
  });
  
  router.patch("/widgets/:id", async (req: express.Request, res: express.Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid widget ID" });
    }
    
    const updatedWidget = await storage.updateDashboardWidget(id, req.body);
    if (!updatedWidget) {
      return res.status(404).json({ message: "Widget not found" });
    }
    
    res.json(updatedWidget);
  });
  
  router.delete("/widgets/:id", async (req: express.Request, res: express.Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid widget ID" });
    }
    
    const deleted = await storage.deleteDashboardWidget(id);
    if (!deleted) {
      return res.status(404).json({ message: "Widget not found" });
    }
    
    res.json({ message: "Widget deleted successfully" });
  });

  router.post("/ai/strategy-comparison", async (req: express.Request, res: express.Response) => {
    try {
      const { eventId, event } = req.body;
      
      if (!event) {
        return res.status(400).json({ message: "Missing required parameters" });
      }
      
      const comparison = await compareStrategies(event);
      
      // Store the analysis
      if (eventId) {
        await storage.createAiAnalysis({
          eventId,
          userId: DEFAULT_USER_ID,
          query: `Strategy comparison for ${event}`,
          response: comparison,
          analysisType: 'strategy'
        });
      }
      
      res.json({ comparison });
    } catch (error) {
      res.status(500).json({ message: "Failed to generate strategy comparison" });
    }
  });
  
  router.get("/ai/crypto-insights", async (_req: express.Request, res: express.Response) => {
    try {
      const insights = await getCryptoMarketInsights();
      
      // Store the analysis
      await storage.createAiAnalysis({
        userId: DEFAULT_USER_ID,
        query: "Crypto market insights",
        response: insights,
        analysisType: 'crypto'
      });
      
      res.json({ insights });
    } catch (error) {
      res.status(500).json({ message: "Failed to generate crypto insights" });
    }
  });

  router.get("/self-learning/weights", async (_req: express.Request, res: express.Response) => {
    try {
      const weights = getModelWeights();
      res.json({ weights });
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error retrieving model weights", 
        error: error.message 
      });
    }
  });
  
  router.post("/self-learning/train", async (req: express.Request, res: express.Response) => {
    try {
      // Get user betting history with details
      const userId = req.body.userId || DEFAULT_USER_ID;
      const bettingHistory = await storage.getUserBetsWithDetails(userId);
      
      if (!bettingHistory || bettingHistory.length === 0) {
        return res.status(400).json({ 
          message: "No betting history found for training" 
        });
      }
      
      // Train the model
      const result = trainModel(bettingHistory);
      
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error training model", 
        error: error.message 
      });
    }
  });
  
  router.post("/self-learning/predict", async (req: express.Request, res: express.Response) => {
    try {
      const { eventId, betType, pick } = req.body;
      
      if (!eventId || !betType || !pick) {
        return res.status(400).json({ 
          message: "Missing required parameters: eventId, betType, pick" 
        });
      }
      
      // Get event and odds data
      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      const odds = await storage.getLatestOddsByEventId(eventId);
      if (!odds) {
        return res.status(404).json({ message: "Odds not found for this event" });
      }
      
      // Generate prediction
      const prediction = predictConfidence(event, odds, betType, pick);
      
      res.json({
        eventId,
        betType,
        pick,
        prediction
      });
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error generating prediction", 
        error: error.message 
      });
    }
  });
  
  router.get("/self-learning/edge-bets", async (req: express.Request, res: express.Response) => {
    try {
      // Get upcoming events
      const limit = parseInt(req.query.limit as string) || 10;
      const events = await storage.getUpcomingEvents(limit);
      
      if (!events || events.length === 0) {
        return res.json([]);
      }
      
      // Get all odds
      const allOdds: Odds[] = [];
      for (const event of events) {
        const odds = await storage.getLatestOddsByEventId(event.id);
        if (odds) {
          allOdds.push(odds);
        }
      }
      
      // Generate edge bets
      const edgeBets = generateEdgeBets(
        events.map(e => e.event), 
        allOdds
      );
      
      res.json(edgeBets);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error generating edge bets", 
        error: error.message 
      });
    }
  });
  
  router.post("/self-learning/reset", async (req: express.Request, res: express.Response) => {
    try {
      const { sportId, betType } = req.body;
      
      if (!sportId) {
        return res.status(400).json({ message: "Missing required parameter: sportId" });
      }
      
      const result = resetModelWeights(sportId, betType);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error resetting model weights", 
        error: error.message 
      });
    }
  });

  router.post("/bet-exchange/place-bet", async (req: express.Request, res: express.Response) => {
    try {
      const { accountId, eventId, marketId, selectionId, betType, stake, price } = req.body;
      
      if (!accountId || !eventId || !marketId || !selectionId || !betType || !stake || !price) {
        return res.status(400).json({ message: "Missing required parameters" });
      }
      
      // Get the account for authentication
      const account = await storage.getBetExchangeAccount(parseInt(accountId));
      if (!account) {
        return res.status(404).json({ message: "Account not found" });
      }
      
      // Get the event mapping
      const mapping = await storage.getEventMappingByInternalId(
        parseInt(eventId), 
        account.provider as BetExchangeProvider
      );
      if (!mapping) {
        return res.status(404).json({ message: "No exchange mapping found for this event" });
      }
      
      // Place the bet
      const betResult = await placeBet(account.provider as BetExchangeProvider, account.token, {
        provider: account.provider as BetExchangeProvider,
        eventId: mapping.exchangeEventId,
        marketId,
        selectionId,
        betType: betType as 'back' | 'lay',
        stake: parseFloat(stake),
        price: parseFloat(price)
      });
      
      // Create an internal automated bet record
      const automatedBet = await storage.createAutomatedBet({
        userId: account.userId,
        accountId: account.id,
        betType,
        exchangeProvider: account.provider,
        exchangeBetId: betResult.betId || null,
        marketId,
        selectionId,
        stake,
        requestedPrice: price.toString(),
        status: betResult.status,
        matchedPrice: betResult.status === 'success' ? price.toString() : null,
        errorMessage: betResult.status === 'failed' ? betResult.message : null
      });
      
      res.json({
        success: betResult.status === 'success',
        bet: automatedBet,
        exchangeResponse: betResult
      });
    } catch (error: any) {
      res.status(500).json({ 
        success: false,
        message: "Error placing bet on exchange", 
        error: error.message 
      });
    }
  });
  
  router.get("/bet-exchange/balance/:accountId", async (req: express.Request, res: express.Response) => {
    const accountId = parseInt(req.params.accountId);
    
    if (isNaN(accountId)) {
      return res.status(400).json({ message: "Invalid account ID" });
    }
    
    try {
      // Get the account for authentication
      const account = await storage.getBetExchangeAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "Account not found" });
      }
      
      // Get balance from the exchange
      const balance = await getAccountBalance(
        account.provider as BetExchangeProvider,
        account.token
      );
      
      res.json(balance);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error getting exchange account balance", 
        error: error.message 
      });
    }
  });

  export default router;
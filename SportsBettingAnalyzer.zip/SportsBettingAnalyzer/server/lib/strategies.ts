import { storage } from "../storage";
import type { 
  EventWithOdds, 
  InsertRecommendation, 
  Recommendation 
} from "@shared/schema";

/**
 * Generate recommendations based on different betting strategies
 */
export async function generateRecommendations(): Promise<Recommendation[]> {
  try {
    // Get upcoming events with the latest odds
    const upcomingEvents = await storage.getUpcomingEvents(10);
    
    // Generate recommendations for each event
    const recommendations: Recommendation[] = [];
    
    for (const event of upcomingEvents) {
      if (!event.odds) continue;
      
      // Apply different strategies
      const moneylineRec = await applyMoneylineStrategy(event);
      const spreadRec = await applySpreadStrategy(event);
      const totalRec = await applyTotalStrategy(event);
      
      if (moneylineRec) recommendations.push(moneylineRec);
      if (spreadRec) recommendations.push(spreadRec);
      if (totalRec) recommendations.push(totalRec);
    }
    
    return recommendations;
  } catch (error) {
    console.error("Error generating recommendations:", error);
    throw new Error("Failed to generate recommendations");
  }
}

/**
 * Moneyline Strategy
 * This strategy analyzes straight up win probabilities and compares them to the implied
 * probabilities from the odds to find value bets.
 */
async function applyMoneylineStrategy(event: EventWithOdds): Promise<Recommendation | null> {
  if (!event.odds) return null;
  
  const { moneylineHome, moneylineAway } = event.odds;
  if (!moneylineHome || !moneylineAway) return null;
  
  // Convert American odds to implied probabilities
  const homeImpliedProbability = oddsToImpliedProbability(moneylineHome);
  const awayImpliedProbability = oddsToImpliedProbability(moneylineAway);
  
  // Simulate our own probability model (in a real app, this would be much more sophisticated)
  // For simplicity, we'll slightly adjust the implied probabilities based on random factors
  const homeProbabilityAdjustment = Math.random() * 0.15 - 0.075; // Between -7.5% and +7.5%
  const ourHomeProbability = Math.min(Math.max(homeImpliedProbability + homeProbabilityAdjustment, 0.1), 0.9);
  const ourAwayProbability = 1 - ourHomeProbability;
  
  // Calculate edge (our probability - implied probability)
  const homeEdge = ourHomeProbability - homeImpliedProbability;
  const awayEdge = ourAwayProbability - awayImpliedProbability;
  
  // Determine the bet with the highest edge
  let recommendation: string;
  let odds: number;
  let confidence: number;
  let value: number;
  let reasoning: string;
  
  if (homeEdge > awayEdge && homeEdge > 0.02) { // 2% edge threshold
    recommendation = event.homeTeam;
    odds = moneylineHome;
    confidence = ourHomeProbability * 100;
    value = homeEdge * 100;
    reasoning = `${event.homeTeam} have a better chance of winning than the odds suggest.`;
  } else if (awayEdge > 0.02) {
    recommendation = event.awayTeam;
    odds = moneylineAway;
    confidence = ourAwayProbability * 100;
    value = awayEdge * 100;
    reasoning = `${event.awayTeam} have a better chance of winning than the odds suggest.`;
  } else {
    // No significant edge found
    return null;
  }
  
  // Create the recommendation
  const insertRec: InsertRecommendation = {
    eventId: event.id,
    strategyType: "moneyline",
    recommendation,
    odds,
    confidence: parseFloat(confidence.toFixed(1)),
    value: parseFloat(value.toFixed(2)),
    reasoning
  };
  
  return await storage.createRecommendation(insertRec);
}

/**
 * Spread Strategy
 * This strategy analyzes team performance against the spread to find value.
 */
async function applySpreadStrategy(event: EventWithOdds): Promise<Recommendation | null> {
  if (!event.odds) return null;
  
  const { spreadHome, spreadHomeOdds, spreadAway, spreadAwayOdds } = event.odds;
  if (spreadHome === null || spreadHomeOdds === null || spreadAway === null || spreadAwayOdds === null) {
    return null;
  }
  
  // In a real app, we would use historical data, team strength metrics, etc.
  // For simplicity, we'll simulate our own spread prediction
  
  // Simulate our projection for the spread (with some randomness)
  const marketSpread = Math.abs(spreadHome);
  const spreadVariation = Math.random() * marketSpread * 0.5;
  const ourSpreadProjection = marketSpread - spreadVariation;
  
  // Determine if there's value
  const spreadDifference = marketSpread - ourSpreadProjection;
  
  // Only recommend if our projection differs significantly from the market
  if (spreadDifference < 1) return null;
  
  // Choose side based on our projection
  let recommendation: string;
  let odds: number;
  let confidence: number;
  let reasoning: string;
  
  if (spreadHome < 0) { // Home team is favored
    if (ourSpreadProjection < marketSpread) {
      // We think the spread should be smaller, so take the underdog
      recommendation = `${event.awayTeam} +${marketSpread}`;
      odds = spreadAwayOdds;
      confidence = 50 + (spreadDifference * 5); // Higher difference = higher confidence
      reasoning = `The spread for ${event.awayTeam} is too high based on our projections.`;
    } else {
      // No value found
      return null;
    }
  } else { // Away team is favored
    if (ourSpreadProjection < marketSpread) {
      // We think the spread should be smaller, so take the underdog
      recommendation = `${event.homeTeam} +${marketSpread}`;
      odds = spreadHomeOdds;
      confidence = 50 + (spreadDifference * 5);
      reasoning = `The spread for ${event.homeTeam} is too high based on our projections.`;
    } else {
      // No value found
      return null;
    }
  }
  
  // Apply some constraints to confidence
  confidence = Math.min(Math.max(confidence, 50), 85);
  
  // Create the recommendation
  const insertRec: InsertRecommendation = {
    eventId: event.id,
    strategyType: "spread",
    recommendation,
    odds,
    confidence: parseFloat(confidence.toFixed(1)),
    value: parseFloat(spreadDifference.toFixed(2)),
    reasoning
  };
  
  return await storage.createRecommendation(insertRec);
}

/**
 * Total Points (Over/Under) Strategy
 * This strategy analyzes team scoring patterns to find value in over/under bets.
 */
async function applyTotalStrategy(event: EventWithOdds): Promise<Recommendation | null> {
  if (!event.odds) return null;
  
  const { totalPoints, totalOverOdds, totalUnderOdds } = event.odds;
  if (totalPoints === null || totalOverOdds === null || totalUnderOdds === null) {
    return null;
  }
  
  // In a real app, we'd use historical scoring data, pace, defensive metrics, etc.
  // For simplicity, we'll simulate our own total prediction
  
  // Simulate our projection for the total (with some randomness)
  const totalVariation = Math.random() * totalPoints * 0.2 - (totalPoints * 0.1);
  const ourTotalProjection = totalPoints + totalVariation;
  
  // Determine if there's value
  const totalDifference = Math.abs(totalPoints - ourTotalProjection);
  
  // Only recommend if our projection differs significantly from the market
  if (totalDifference < totalPoints * 0.05) return null; // At least 5% difference
  
  // Choose over/under based on our projection
  let recommendation: string;
  let odds: number;
  let confidence: number;
  let reasoning: string;
  
  if (ourTotalProjection < totalPoints) {
    recommendation = `UNDER ${totalPoints}`;
    odds = totalUnderOdds;
    confidence = 60 + (totalDifference / totalPoints * 100);
    reasoning = `Our projection of ${ourTotalProjection.toFixed(1)} points is lower than the market total.`;
  } else {
    recommendation = `OVER ${totalPoints}`;
    odds = totalOverOdds;
    confidence = 60 + (totalDifference / totalPoints * 100);
    reasoning = `Our projection of ${ourTotalProjection.toFixed(1)} points is higher than the market total.`;
  }
  
  // Apply some constraints to confidence
  confidence = Math.min(Math.max(confidence, 55), 90);
  
  // Create the recommendation
  const insertRec: InsertRecommendation = {
    eventId: event.id,
    strategyType: "total",
    recommendation,
    odds,
    confidence: parseFloat(confidence.toFixed(1)),
    value: parseFloat(totalDifference.toFixed(2)),
    reasoning
  };
  
  return await storage.createRecommendation(insertRec);
}

/**
 * Utility function to convert American odds to implied probability
 */
function oddsToImpliedProbability(odds: number): number {
  if (odds > 0) {
    return 100 / (odds + 100);
  } else {
    return Math.abs(odds) / (Math.abs(odds) + 100);
  }
}

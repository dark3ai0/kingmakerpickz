
import { SpeechClient } from '@google-cloud/speech';

const speechClient = new SpeechClient();

export async function transcribeCommand(audioBuffer: Buffer) {
  try {
    const [response] = await speechClient.recognize({
      audio: { content: audioBuffer.toString('base64') },
      config: {
        encoding: 'LINEAR16',
        sampleRateHertz: 16000,
        languageCode: 'en-US',
        model: 'command_and_search'
      }
    });

    return response.results?.[0]?.alternatives?.[0]?.transcript || '';
  } catch (error) {
    console.error('Speech recognition error:', error);
    throw error;
  }
}

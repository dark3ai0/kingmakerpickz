
import { ImageAnnotatorClient } from '@google-cloud/vision';
import { VideoIntelligenceServiceClient } from '@google-cloud/video-intelligence';

const visionClient = new ImageAnnotatorClient();
const videoClient = new VideoIntelligenceServiceClient();

export async function analyzeGameImage(imageBuffer: Buffer) {
  try {
    const [result] = await visionClient.annotateImage({
      image: { content: imageBuffer.toString('base64') },
      features: [
        { type: 'OBJECT_LOCALIZATION' },
        { type: 'LABEL_DETECTION' },
        { type: 'TEXT_DETECTION' }
      ]
    });

    return {
      players: result.localizedObjectAnnotations?.filter(obj => obj.name === 'Person'),
      labels: result.labelAnnotations,
      text: result.textAnnotations?.[0]?.description
    };
  } catch (error) {
    console.error('Vision AI error:', error);
    throw error;
  }
}

export async function analyzeGameHighlights(videoUri: string) {
  try {
    const [operation] = await videoClient.annotateVideo({
      inputUri: videoUri,
      features: ['LABEL_DETECTION', 'SHOT_CHANGE_DETECTION']
    });

    const [response] = await operation.promise();
    return {
      labels: response.annotationResults?.[0]?.shotLabelAnnotations,
      shots: response.annotationResults?.[0]?.shotChanges
    };
  } catch (error) {
    console.error('Video Intelligence error:', error);
    throw error;
  }
}

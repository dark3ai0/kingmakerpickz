import { GoogleGenerativeAI } from "@google/generative-ai";
import { storage } from "../storage";
import { Event, Odds, Sport } from "../../shared/schema";

// Initialize the Gemini API client
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");

// Define models
const geminiProModel = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });

// Placeholder function -  Replace with actual Cloud Vision API integration
async function analyzePlayerImage(imageUrl: string): Promise<any> {
  //  This is a placeholder. Replace with actual Cloud Vision API call.
  //  The function should analyze the image and return relevant insights.
  //  Example insights: player emotion, player form, crowd reaction etc.

  console.log(`Analyzing image: ${imageUrl}`);
  //Simulate some vision analysis results. Replace this with actual API call.
  return {
    playerEmotion: "focused",
    playerForm: "good",
    crowdReaction: "positive"
  };
}


/**
 * Generate a quick pick recommendation using Gemini API and Cloud Vision API (if image provided)
 */
export async function generateQuickPick(sportFilter?: string, betTypeFilter?: string, amount: number = 10, playerImageUrl?: string): Promise<any> {
  try {
    const sports: Sport[] = await storage.getAllSports();
    const events: Event[] = await storage.getAllEvents();
    const activeEvents = events.filter(event => event.status === 'scheduled');

    // Analyze any player/team images if available
    let visionInsights = null;
    if (playerImageUrl) {
      visionInsights = await analyzePlayerImage(playerImageUrl);
    }

    // Build prompt based on filters and vision insights
    let prompt = `Generate a sports betting recommendation based on current events in ${sportFilter || 'any sport'} with the following details:

    1. A specific game/match/event to bet on
    2. The type of bet: ${betTypeFilter || 'Moneyline, Spread, Total, or Prop bet'}
    3. Your pick with odds (e.g., "Dolphins +3.5 (-110)")
    4. Confidence level (1-10)
    5. Bet amount: $${amount}
    6. A brief explanation for why this is a good bet

    Format your response exactly as JSON with the following structure:
    {
      "sport": "NFL",
      "event": "Bills vs Chiefs",
      "betType": "Spread",
      "pick": "Chiefs -3.5 (-110)",
      "odds": -110,
      "confidence": 8,
      "amount": ${amount},
      "potentialWin": 9.09,
      "reasoning": "Brief explanation..."
    }

    Important: Only include in your response a valid JSON object with NO additional text before or after.`;


    if (visionInsights) {
      prompt += `\n\nVision Analysis Insights: ${JSON.stringify(visionInsights)}`;
    }

    // Get available events to provide context
    let eventContext = "Available events:\n";
    for (const event of activeEvents.slice(0, 10)) {
      const odds = await storage.getLatestOddsByEventId(event.id);
      eventContext += `- ${event.homeTeam} vs ${event.awayTeam} (${sports.find(s => s.id === event.sportId)?.name || 'Unknown sport'})\n`;
      if (odds) {
        eventContext += `  Odds: ML Home ${odds.moneylineHome} / ML Away ${odds.moneylineAway}, Spread: ${odds.spreadHome} (${odds.spreadHomeOdds}/${odds.spreadAwayOdds}), Total: ${odds.totalPoints} (${odds.totalOverOdds}/${odds.totalUnderOdds})\n`;
      }
    }

    prompt += "\n\n" + eventContext;

    // Get response from Gemini
    const result = await geminiProModel.generateContent(prompt);
    const response = result.response;
    const text = response.text();

    // Parse JSON from response
    // Note: In production, add better error handling for malformed JSON
    try {
      const quickPick = JSON.parse(text);
      return quickPick;
    } catch (err) {
      console.error("Failed to parse Gemini response as JSON:", text);
      throw new Error("Failed to generate proper quick pick recommendation");
    }
  } catch (error) {
    console.error("Error generating quick pick:", error);
    throw error;
  }
}

/**
 * Analyze a bet and provide confidence rating using Gemini API
 */
export async function analyzeBet(event: string, betType: string, pick: string): Promise<any> {
  try {
    const prompt = `Analyze this sports bet and provide a detailed breakdown:

    Event: ${event}
    Bet Type: ${betType}
    Pick: ${pick}

    Please provide:
    1. A confidence rating (1-10)
    2. Key factors supporting this bet
    3. Main risks to be aware of
    4. Overall recommendation

    Format your response exactly as JSON with the following structure:
    {
      "confidence": 7,
      "supportingFactors": ["Factor 1", "Factor 2", "Factor 3"],
      "risks": ["Risk 1", "Risk 2"],
      "recommendation": "Bet with caution",
      "analysis": "Detailed analysis..."
    }

    Only include a valid JSON object with NO additional text before or after.`;

    // Get response from Gemini
    const result = await geminiProModel.generateContent(prompt);
    const response = result.response;
    const text = response.text();

    try {
      const analysis = JSON.parse(text);
      return analysis;
    } catch (err) {
      console.error("Failed to parse Gemini response as JSON:", text);
      throw new Error("Failed to generate bet analysis");
    }
  } catch (error) {
    console.error("Error analyzing bet:", error);
    throw error;
  }
}

/**
 * Generate betting tips based on recent performance using Gemini API
 */
export async function generateBettingTips(count: number = 3): Promise<any> {
  try {
    const prompt = `Generate ${count} useful sports betting tips for beginners. These should be practical, actionable advice that helps someone new to sports betting avoid common mistakes and improve their chances of success.

    Format your response exactly as JSON with the following structure:
    {
      "tips": [
        {
          "title": "Manage Your Bankroll",
          "description": "Never bet more than 5% of your total bankroll on a single wager...",
          "category": "Strategy" 
        },
        ...
      ]
    }

    Possible categories: Strategy, Research, Psychology, Value Betting, Discipline

    Only include a valid JSON object with NO additional text before or after.`;

    // Get response from Gemini
    const result = await geminiProModel.generateContent(prompt);
    const response = result.response;
    const text = response.text();

    try {
      const tips = JSON.parse(text);
      return tips;
    } catch (err) {
      console.error("Failed to parse Gemini response as JSON:", text);
      throw new Error("Failed to generate betting tips");
    }
  } catch (error) {
    console.error("Error generating betting tips:", error);
    throw error;
  }
}
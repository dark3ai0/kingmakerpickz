
import { PredictionServiceClient } from '@google-cloud/aiplatform';
import { protos } from '@google-cloud/aiplatform';

const predictionClient = new PredictionServiceClient();

export async function predictOutcome(features: any) {
  try {
    const endpoint = process.env.VERTEX_ENDPOINT;
    const location = process.env.GOOGLE_CLOUD_LOCATION;
    
    // Add AutoML capabilities
    const autoMLModel = await predictionClient.createAutoMLModel({
      parent: `projects/${process.env.GOOGLE_CLOUD_PROJECT}/locations/${location}`,
      model: {
        displayName: 'SportsBettingModel',
        trainingData: features.historicalData,
        predictionType: 'classification'
      }
    });
    const project = process.env.GOOGLE_CLOUD_PROJECT;
    const location = process.env.GOOGLE_CLOUD_LOCATION;

    const request = {
      endpoint: `projects/${project}/locations/${location}/endpoints/${endpoint}`,
      instances: [features],
      parameters: {
        confidenceThreshold: 0.5,
        maxPredictions: 5
      }
    };

    const [response] = await predictionClient.predict(request);
    
    return {
      prediction: response.predictions[0],
      confidence: response.predictions[0].confidence,
      alternatives: response.predictions.slice(1)
    };
  } catch (error) {
    console.error('Vertex AI prediction error:', error);
    throw error;
  }
}

export async function batchPredict(features: any[]) {
  try {
    const endpoint = process.env.VERTEX_BATCH_ENDPOINT;
    const [operation] = await predictionClient.batchPredict({
      endpoint: endpoint,
      instances: features
    });

    const [response] = await operation.promise();
    return response;
  } catch (error) {
    console.error('Batch prediction error:', error);
    throw error;
  }
}

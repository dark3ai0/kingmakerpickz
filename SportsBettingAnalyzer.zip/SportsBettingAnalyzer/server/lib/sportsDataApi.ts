import { storage } from "../storage";
import { refreshSportsData, initializeSports } from "./apiSportsClient";
import type { InsertEvent, InsertOdds } from "@shared/schema";

// Check if we have API_SPORTS_KEY environment variable
const hasApiKey = !!process.env.API_SPORTS_KEY;

// Initialize sports data
(async () => {
  if (hasApiKey) {
    try {
      await initializeSports();
      console.log("Sports initialized successfully with API-Sports");
    } catch (error) {
      console.error("Failed to initialize sports with API-Sports:", error);
    }
  }
})();

// Fetch data from API-Sports when available, fallback to synthetic data if not
export async function getSportsData() {
  try {
    // Use the API-Sports integration when API key is available
    if (hasApiKey) {
      const result = await refreshSportsData();
      console.log(`API-Sports data refresh: ${result.events} events, ${result.odds} odds updated`);
      
      // Return in the format expected by existing code
      return {
        message: "Sports data refreshed from API-Sports",
        events: result.events,
        odds: result.odds
      };
    }
    
    // Fallback to synthetic data when no API key
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Get current events to check for updates
    const currentEvents = await storage.getAllEvents();
    
    // Sample data for demonstration (synthetic fallback)
    const eventUpdates = [
      {
        externalId: "nfl_101",
        status: "scheduled",
        homeScore: null,
        awayScore: null,
        odds: {
          moneylineHome: -130,
          moneylineAway: 110,
          spreadHome: -3,
          spreadHomeOdds: -110,
          spreadAway: 3,
          spreadAwayOdds: -110,
          totalPoints: 48,
          totalOverOdds: -110,
          totalUnderOdds: -110
        }
      },
      {
        externalId: "nba_201",
        status: "scheduled",
        homeScore: null,
        awayScore: null,
        odds: {
          moneylineHome: -185,
          moneylineAway: 155,
          spreadHome: -5,
          spreadHomeOdds: -110,
          spreadAway: 5,
          spreadAwayOdds: -110,
          totalPoints: 219,
          totalOverOdds: -110,
          totalUnderOdds: -110
        }
      }
    ];
    
    // Process updates
    const processed = await Promise.all(eventUpdates.map(async (update) => {
      const existingEvent = await storage.getEventByExternalId(update.externalId);
      
      if (existingEvent) {
        // Update event status and scores if needed
        if (existingEvent.status !== update.status || 
            existingEvent.homeScore !== update.homeScore || 
            existingEvent.awayScore !== update.awayScore) {
          await storage.updateEventStatus(existingEvent.id, update.status);
          if (update.homeScore !== null && update.awayScore !== null) {
            await storage.updateEventScores(existingEvent.id, update.homeScore, update.awayScore);
          }
        }
        
        // Get latest odds
        const latestOdds = await storage.getLatestOddsByEventId(existingEvent.id);
        
        // Check if odds have changed
        const oddsChanged = !latestOdds || 
          latestOdds.moneylineHome !== update.odds.moneylineHome ||
          latestOdds.moneylineAway !== update.odds.moneylineAway ||
          latestOdds.spreadHome !== update.odds.spreadHome ||
          latestOdds.spreadAway !== update.odds.spreadAway ||
          latestOdds.totalPoints !== update.odds.totalPoints;
        
        // If odds changed, create new odds entry
        if (oddsChanged) {
          const newOdds: InsertOdds = {
            eventId: existingEvent.id,
            ...update.odds
          };
          await storage.createOdds(newOdds);
        }
        
        return {
          event: existingEvent,
          oddsUpdated: oddsChanged
        };
      }
      
      return { event: null, oddsUpdated: false };
    }));
    
    // Add a new event occasionally
    const shouldAddNewEvent = Math.random() > 0.7;
    
    if (shouldAddNewEvent) {
      // Create a new event
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(19, 0, 0, 0);
      
      const newEventData: InsertEvent = {
        sportId: 4, // NHL
        homeTeam: "Toronto Maple Leafs",
        awayTeam: "Montreal Canadiens",
        startTime: tomorrow,
        status: "scheduled",
        location: "Scotiabank Arena",
        homeScore: null,
        awayScore: null,
        externalId: "nhl_401"
      };
      
      const newEvent = await storage.createEvent(newEventData);
      
      // Add odds for the new event
      const newOdds: InsertOdds = {
        eventId: newEvent.id,
        moneylineHome: -125,
        moneylineAway: 105,
        spreadHome: -1.5,
        spreadHomeOdds: 170,
        spreadAway: 1.5,
        spreadAwayOdds: -200,
        totalPoints: 6.5,
        totalOverOdds: -110,
        totalUnderOdds: -110
      };
      
      await storage.createOdds(newOdds);
      
      processed.push({
        event: newEvent,
        oddsUpdated: true,
        new: true
      });
    }
    
    console.log("Using synthetic sports data (no API_SPORTS_KEY available)");
    return processed;
  } catch (error) {
    console.error("Error fetching sports data:", error);
    throw new Error("Failed to fetch sports data");
  }
}

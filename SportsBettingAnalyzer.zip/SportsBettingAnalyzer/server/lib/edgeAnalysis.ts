import { Event, Odds } from "@shared/schema";
import { storage } from "../storage";
import { predictConfidence } from "./selfLearningModel";
import { getBettingAnalysis } from "./perplexityApi";

interface EdgeBet {
  eventId: number;
  homeTeam: string;
  awayTeam: string;
  betType: string;
  pick: string;
  confidence: number;
  odds: number;
  impliedProbability: number;
  modelProbability: number;
  edge: number;
  recommendedStake: number;
  reasoning: string;
  startTime: Date;
  sportId: number;
}

/**
 * Generate edge bets based on upcoming events and odds
 * @param limit Maximum number of edge bets to return
 * @param sportId Optional filter for specific sport
 * @returns Array of edge bets with maximum mathematical edge
 */
export async function generateEdgeBets(limit: number = 5, sportId?: number): Promise<EdgeBet[]> {
  try {
    // Get upcoming events
    let events = await storage.getUpcomingEvents(limit * 3);
    
    // Filter by sport if requested
    if (sportId) {
      events = events.filter(event => event.sportId === sportId);
    }
    
    // Return empty array if no events
    if (!events || events.length === 0) {
      return [];
    }
    
    const edgeBets: EdgeBet[] = [];
    
    // Process each event
    for (const event of events) {
      // Get latest odds
      const odds = await storage.getLatestOddsByEventId(event.id);
      if (!odds) continue;
      
      // Check moneyline edge
      checkEdge(event, odds, "moneyline", "home", edgeBets);
      checkEdge(event, odds, "moneyline", "away", edgeBets);
      
      // Check spread edge
      checkEdge(event, odds, "spread", "home", edgeBets);
      checkEdge(event, odds, "spread", "away", edgeBets);
      
      // Check total edge
      checkEdge(event, odds, "total", "over", edgeBets);
      checkEdge(event, odds, "total", "under", edgeBets);
    }
    
    // Sort by edge (highest first) and limit results
    return edgeBets.sort((a, b) => b.edge - a.edge).slice(0, limit);
  } catch (error) {
    console.error("Error generating edge bets:", error);
    return [];
  }
}

/**
 * Check if a bet has an edge worth considering
 * @param event Event data
 * @param odds Odds data
 * @param betType Type of bet (moneyline, spread, total)
 * @param pick Specific pick (home, away, over, under)
 * @param edgeBets Array to add edge bets to
 */
async function checkEdge(
  event: Event,
  odds: Odds,
  betType: string,
  pick: string,
  edgeBets: EdgeBet[]
): Promise<void> {
  // Don't process bets without odds
  const oddsValue = getOddsValue(odds, betType, pick);
  if (oddsValue === null) return;
  
  // Minimum edge threshold to consider (5%)
  const EDGE_THRESHOLD = 0.05;
  
  // Convert odds to implied probability
  const impliedProbability = convertOddsToImpliedProbability(oddsValue);
  
  // Calculate model confidence
  const prediction = await predictConfidence(event, odds, betType, pick);
  const modelProbability = prediction.confidence;
  
  // Calculate edge
  const edge = modelProbability - impliedProbability;
  
  // If edge exceeds threshold, add to edge bets
  if (edge > EDGE_THRESHOLD) {
    // Calculate recommended stake (Kelly Criterion with fraction)
    const kellyFraction = 0.25; // Conservative Kelly (25%)
    const recommendedStake = Math.max(0, kellyFraction * ((modelProbability * (oddsValue / 100)) - ((1 - modelProbability) * 1)) / (oddsValue / 100));
    
    // Generate reasoning
    const matchup = `${event.homeTeam} vs ${event.awayTeam}`;
    const betDescription = getBetDescription(betType, pick, event, odds);
    let reasoning = await getBettingAnalysis(matchup, betDescription);
    
    edgeBets.push({
      eventId: event.id,
      sportId: event.sportId,
      homeTeam: event.homeTeam,
      awayTeam: event.awayTeam,
      betType,
      pick,
      confidence: modelProbability,
      odds: oddsValue,
      impliedProbability,
      modelProbability,
      edge,
      recommendedStake,
      reasoning,
      startTime: event.startTime
    });
  }
}

/**
 * Get the odds value for a specific bet type and pick
 * @param odds Odds data
 * @param betType Type of bet (moneyline, spread, total)
 * @param pick Specific pick (home, away, over, under)
 * @returns Odds value or null if not available
 */
function getOddsValue(odds: Odds, betType: string, pick: string): number | null {
  switch (betType) {
    case "moneyline":
      return pick === "home" ? odds.moneylineHome : odds.moneylineAway;
    case "spread":
      return pick === "home" ? odds.spreadHomeOdds : odds.spreadAwayOdds;
    case "total":
      return pick === "over" ? odds.totalOverOdds : odds.totalUnderOdds;
    default:
      return null;
  }
}

/**
 * Convert American odds to implied probability
 * @param americanOdds American odds (e.g., -110, +150)
 * @returns Implied probability (0-1)
 */
function convertOddsToImpliedProbability(americanOdds: number): number {
  if (americanOdds === 0) return 0.5;
  
  if (americanOdds > 0) {
    return 100 / (americanOdds + 100);
  } else {
    return Math.abs(americanOdds) / (Math.abs(americanOdds) + 100);
  }
}

/**
 * Get user-friendly description of the bet
 * @param betType Type of bet (moneyline, spread, total)
 * @param pick Specific pick (home, away, over, under)
 * @param event Event data
 * @param odds Odds data
 * @returns Formatted bet description
 */
function getBetDescription(betType: string, pick: string, event: Event, odds: Odds): string {
  switch (betType) {
    case "moneyline":
      return `${pick === "home" ? event.homeTeam : event.awayTeam} Moneyline`;
    case "spread":
      if (pick === "home") {
        const spreadValue = odds.spreadHome || 0;
        return `${event.homeTeam} ${spreadValue > 0 ? "+" : ""}${spreadValue}`;
      } else {
        const spreadValue = odds.spreadAway || 0;
        return `${event.awayTeam} ${spreadValue > 0 ? "+" : ""}${spreadValue}`;
      }
    case "total":
      return `${pick.toUpperCase()} ${odds.totalPoints || 0} total points`;
    default:
      return "Unknown bet type";
  }
}

/**
 * Calculate recommended bet size based on bankroll and edge
 * @param bankroll User's bankroll
 * @param edge Edge percentage (0-1)
 * @param riskLevel User's risk tolerance (conservative, moderate, aggressive)
 * @returns Recommended bet size
 */
export function calculateBetSize(bankroll: number, edge: number, riskLevel: string): number {
  // Base Kelly stake
  let kellyStake = edge;
  
  // Adjust for risk level
  const riskFactor = getRiskFactor(riskLevel);
  kellyStake *= riskFactor;
  
  // Calculate bet size
  const betSize = bankroll * kellyStake;
  
  // Round to whole dollars
  return Math.round(betSize);
}

/**
 * Get risk factor multiplier based on risk level
 * @param riskLevel User's risk tolerance (conservative, moderate, aggressive)
 * @returns Risk factor multiplier
 */
function getRiskFactor(riskLevel: string): number {
  switch (riskLevel.toLowerCase()) {
    case "conservative":
      return 0.25; // 1/4 Kelly
    case "moderate":
      return 0.5; // 1/2 Kelly
    case "aggressive":
      return 0.75; // 3/4 Kelly
    default:
      return 0.33; // Default to 1/3 Kelly
  }
}
import { GoogleGenerativeAI } from '@google/generative-ai';

// API key from environment variables
const API_KEY = process.env.GEMINI_API_KEY;

// Initialize the Gemini API client
let genAI: GoogleGenerativeAI | null = null;

// Define available models 
const MODELS = {
  GEMINI_PRO: 'gemini-pro',
  GEMINI_PRO_VISION: 'gemini-pro-vision',
  GEMINI_2_5: 'gemini-2.5-pro',
  GEMINI_2_5_VISION: 'gemini-2.5-pro-vision',
  GEMINI_EMBEDDING: 'embedding-001'
};

// Initialize models
let genAiModels: { [key: string]: any } = {};

// Check if API key is valid and initialize the client
try {
  if (API_KEY && API_KEY.trim() !== '') {
    genAI = new GoogleGenerativeAI(API_KEY);

    // Initialize all models
    genAiModels = {
      pro: genAI.getGenerativeModel({ model: MODELS.GEMINI_PRO }),
      vision: genAI.getGenerativeModel({ model: MODELS.GEMINI_PRO_VISION }),
      advanced: genAI.getGenerativeModel({ model: MODELS.GEMINI_2_5 }),
      advancedVision: genAI.getGenerativeModel({ model: MODELS.GEMINI_2_5_VISION })
    };

    console.log('Gemini API models initialized successfully');
  } else {
    console.warn('GEMINI_API_KEY not set or empty');
  }
} catch (error) {
  console.error('Error initializing Gemini API models:', error);
}

/**
 * Generate podcast script for event preview or recap
 * @param event The event to analyze
 * @param type The type of podcast (preview or recap)
 * @returns Generated podcast script
 */
export async function generatePodcastScript(event: string, type: 'preview' | 'recap'): Promise<string> {
  try {
    if (!genAI) {
      console.warn('GEMINI_API_KEY not set, using fallback response');
      return getFallbackPodcastScript(event, type);
    }

    const model = genAI.getGenerativeModel({ model: MODELS.GEMINI_PRO });

    const prompt = type === 'preview' 
      ? `You are DK, the charismatic and knowledgeable host of 'KingMakerPickz', 
        a popular sports betting podcast. Create an engaging 2-3 minute podcast script previewing this upcoming event: ${event}.

        Include:
        - Exciting intro with your catchphrase "What's good kings and queens, this is DK coming at you with another KingMakerPickz breakdown!"
        - Key storylines and matchup analysis
        - Recent form of both teams/competitors
        - Key players to watch and their impact
        - Betting angles including odds analysis
        - Your personal prediction
        - Sign off with your catchphrase "Remember kings and queens, it's not about making every pick, it's about making the RIGHT picks! This is DK with KingMakerPickz, signing off."

        Use a conversational, high-energy tone with occasional betting slang. Format as a complete podcast script.`

      : `You are DK, the charismatic and knowledgeable host of 'KingMakerPickz', 
        a popular sports betting podcast. Create an engaging 2-3 minute podcast script recapping this event: ${event}.

        Include:
        - Exciting intro with your catchphrase "What's good kings and queens, this is DK coming at you with another KingMakerPickz breakdown!"
        - Summary of the game/match result
        - Key moments and turning points
        - Standout player performances
        - Analysis of how the result compared to betting expectations
        - Lessons learned for future betting opportunities
        - Sign off with your catchphrase "Remember kings and queens, it's not about making every pick, it's about making the RIGHT picks! This is DK with KingMakerPickz, signing off."

        Use a conversational, high-energy tone with occasional betting slang. Format as a complete podcast script.`;

    const result = await model.generateContent(prompt);
    const text = result.response.text();
    return text;
  } catch (error) {
    console.error('Error generating podcast script:', error);
    return getFallbackPodcastScript(event, type);
  }
}

/**
 * Generate podcast script for top picks of the week
 * @returns Generated podcast script
 */
export async function generateTopPicksPodcast(): Promise<string> {
  try {
    if (!genAI) {
      console.warn('GEMINI_API_KEY not set, using fallback response');
      return getFallbackTopPicksPodcast();
    }

    const model = genAI.getGenerativeModel({ model: MODELS.GEMINI_PRO });

    const prompt = `You are DK, the charismatic and knowledgeable host of 'KingMakerPickz', 
      a popular sports betting podcast. Create an engaging 3-4 minute podcast script for your weekly "Top 3 Picks" episode.

      Include:
      - Exciting intro with your catchphrase "What's good kings and queens, this is DK coming at you with this week's KingMakerPickz Top 3!"
      - Brief market overview (which sports are active, any big line movements)
      - Your 3 top picks for the week, each with:
        * The matchup and bet type (spread, moneyline, total, prop)
        * Current odds and whether they've moved
        * Your detailed reasoning (stats, trends, situational factors)
        * Confidence level (1-10 scale)
      - One "stay away" game that others might bet but you're avoiding
      - Sign off with your catchphrase "Remember kings and queens, it's not about making every pick, it's about making the RIGHT picks! This is DK with KingMakerPickz, signing off."

      Use current, realistic matchups from the active sports calendar. Use a conversational, high-energy tone with occasional betting slang. Format as a complete podcast script.`;

    const result = await model.generateContent(prompt);
    const text = result.response.text();
    return text;
  } catch (error) {
    console.error('Error generating top picks podcast:', error);
    return getFallbackTopPicksPodcast();
  }
}

/**
 * Generate podcast script for betting strategy
 * @param strategy The betting strategy to explain
 * @returns Generated podcast script
 */
export async function generateStrategyPodcast(strategy: string): Promise<string> {
  try {
    if (!genAI) {
      console.warn('GEMINI_API_KEY not set, using fallback response');
      return getFallbackStrategyPodcast(strategy);
    }

    const model = genAI.getGenerativeModel({ model: MODELS.GEMINI_PRO });

    const prompt = `You are DK, the charismatic and knowledgeable host of 'KingMakerPickz', 
      a popular sports betting podcast. Create an engaging 3-4 minute podcast script for your "Strategy Breakdown" segment focusing on ${strategy}.

      Include:
      - Exciting intro with your catchphrase "What's good kings and queens, this is DK coming at you with a KingMakerPickz Strategy Breakdown!"
      - Clear explanation of the ${strategy} betting strategy
      - Examples of when and how to apply this strategy
      - Common mistakes to avoid
      - How to track results and adjust with this strategy
      - One or two specific examples applying the strategy to current sports matchups
      - Sign off with your catchphrase "Remember kings and queens, it's not about making every pick, it's about making the RIGHT picks! This is DK with KingMakerPickz, signing off."

      Use a conversational, high-energy tone with occasional betting slang. Format as a complete podcast script.`;

    const result = await model.generateContent(prompt);
    const text = result.response.text();
    return text;
  } catch (error) {
    console.error('Error generating strategy podcast:', error);
    return getFallbackStrategyPodcast(strategy);
  }
}

/**
 * Fallback podcast script for events when API is unavailable
 */
function getFallbackPodcastScript(event: string, type: 'preview' | 'recap'): string {
  if (type === 'preview') {
    return `What's good kings and queens, this is DK coming at you with another KingMakerPickz breakdown!

Today we're diving into ${event} - a matchup that's got everyone talking. This one's shaping up to be an absolute banger!

Looking at the recent form, both teams have been showing some flashes of brilliance, but also some concerning weaknesses. The key matchup to watch is definitely going to be in the trenches - whoever controls the line of scrimmage here is going to have a massive advantage.

The oddsmakers have this one pretty tight, which isn't surprising given how evenly matched these squads are. I'm seeing a slight edge for the home team, but there's definitely value on the total here as well.

My KingMakerPickz prediction? I'm leaning towards the under here. Both defenses have been stepping up lately, and in big games like this, the scoring tends to tighten up.

Remember kings and queens, it's not about making every pick, it's about making the RIGHT picks! This is DK with KingMakerPickz, signing off.`;
  } else {
    return `What's good kings and queens, this is DK coming at you with another KingMakerPickz breakdown!

What a game we just witnessed with ${event}! This one lived up to all the hype and then some.

The turning point came in the third quarter when that momentum shift changed everything. You could feel the energy in the building completely flip, and from there it was a different ballgame.

For those who followed our KingMakerPickz recommendation on the underdog, congratulations on cashing that ticket! This is exactly why we emphasize value over favorites - sometimes the smart money is going against the public.

The lesson here is clear: always look at the matchups rather than just the names on the jersey. That's where the true edge comes for serious bettors.

Remember kings and queens, it's not about making every pick, it's about making the RIGHT picks! This is DK with KingMakerPickz, signing off.`;
  }
}

/**
 * Fallback top picks podcast when API is unavailable
 */
function getFallbackTopPicksPodcast(): string {
  return `What's good kings and queens, this is DK coming at you with this week's KingMakerPickz Top 3!

Before we dive in, let's take a quick look at the betting landscape this week. We've got a full slate of NBA and NHL action, plus some key college matchups that are presenting some really interesting opportunities for us.

Alright, let's get to my top three picks for the week:

Pick #1: Lakers +3.5 vs. the Bucks. The line opened at +5 and has been moving our way, which is already a good sign. The Bucks have been struggling on back-to-backs, and this is the second game of a road trip for them. LeBron has been absolutely locked in, and I love the Lakers getting points at home here. Confidence level: 8 out of 10.

Pick #2: Hurricanes/Bruins Under 5.5 goals. Both these teams have elite goaltending and two of the best defensive systems in the NHL. The last four matchups between these teams have averaged just 4.2 total goals. This has all the makings of a 2-1 or 3-2 type of game. Confidence level: 9 out of 10.

Pick #3: Kentucky -6 vs. Tennessee. This is a classic case of a team being undervalued after a couple of underwhelming performances. Kentucky's offensive efficiency is still elite, and Tennessee has been struggling in true road games. I expect Kentucky to come out fired up and cover this number. Confidence level: 7.5 out of 10.

Now for one game I'm staying far away from: Nets vs. Sixers. The uncertainty around Embiid's minutes and the Nets' inconsistent lineup has made this game impossible to handicap with confidence. Sometimes the best bet is no bet, kings and queens.

Remember kings and queens, it's not about making every pick, it's about making the RIGHT picks! This is DK with KingMakerPickz, signing off.`;
}

/**
 * Fallback strategy podcast when API is unavailable
 */
function getFallbackStrategyPodcast(strategy: string): string {
  return `What's good kings and queens, this is DK coming at you with a KingMakerPickz Strategy Breakdown!

Today we're diving deep into ${strategy} - a powerful approach that can give you a serious edge if you know how to use it right.

At its core, ${strategy} is all about identifying value where the market has mispriced it. This isn't just throwing darts at underdogs - it's about finding spots where the odds don't accurately reflect the true probabilities.

The key to making this work is rigorous research and disciplined bankroll management. You've got to be willing to do the homework that casual bettors won't do. That means digging into advanced stats, studying situational spots, and understanding motivational factors.

A common mistake I see kings and queens making is applying this strategy inconsistently. You can't just use it when it feels right - you need to commit to the process and trust it even through the inevitable downswings.

Let me give you a real-world example: In tonight's Celtics-Heat game, the market is heavily favoring the Celtics at -7.5. But applying our ${strategy} approach, we can see that the Heat actually match up surprisingly well in the key statistical categories. While I'm not necessarily saying bet the Heat, this is exactly the type of game where this strategy would have you looking closely at the underdog.

Remember kings and queens, it's not about making every pick, it's about making the RIGHT picks! This is DK with KingMakerPickz, signing off.`;
}

export async function analyzeEvent(event: string, type: 'preview' | 'analysis'): Promise<string> {
  try {
    if (!genAI) throw new Error('Gemini API not initialized');

    const model = genAiModels.advanced;
    const prompt = type === 'preview' 
      ? `Analyze this upcoming sports event and provide detailed insights: ${event}`
      : `Provide post-game analysis and key takeaways for: ${event}`;

    const result = await model.generateContent(prompt);
    return result.response.text();
  } catch (error) {
    console.error('Error analyzing event:', error);
    throw error;
  }
}

export async function generateBettingStrategy(params: any): Promise<any> {
  try {
    if (!genAI) throw new Error('Gemini API not initialized');

    const model = genAiModels.advanced;
    const result = await model.generateContent({
      contents: [{
        parts: [{
          text: `Generate an advanced betting strategy considering these parameters: ${JSON.stringify(params)}`
        }]
      }]
    });

    return JSON.parse(result.response.text());
  } catch (error) {
    console.error('Error generating strategy:', error);
    throw error;
  }
}
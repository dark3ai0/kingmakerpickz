import axios from 'axios';
import { storage } from '../storage';
import { InsertEvent, InsertOdds, InsertSport } from '@shared/schema';

// API key from environment variables
const API_KEY = process.env.API_SPORTS_KEY;

// Base URLs for different sports
const API_URLS = {
  football: 'https://v3.football.api-sports.io',
  basketball: 'https://v1.basketball.api-sports.io',
  baseball: 'https://v1.baseball.api-sports.io',
  hockey: 'https://v1.hockey.api-sports.io',
  rugby: 'https://v1.rugby.api-sports.io',
  american_football: 'https://v1.american-football.api-sports.io',
  formula1: 'https://v1.formula-1.api-sports.io',
  mma: 'https://v1.mma.api-sports.io',
  tennis: 'https://v1.tennis.api-sports.io',
  golf: 'https://v1.golf.api-sports.io',
  cricket: 'https://v1.cricket.api-sports.io',
  esports: 'https://v1.esports.api-sports.io'
};

// Headers for API requests
const headers = {
  'x-rapidapi-key': API_KEY,
  'x-rapidapi-host': 'v3.football.api-sports.io'
};

// Map of sport IDs to API endpoints
const sportApiMap: Record<number, { api: string, leagueIds: number[] }> = {
  1: { api: 'american_football', leagueIds: [1] }, // NFL
  2: { api: 'basketball', leagueIds: [12, 40] }, // NBA and NCAAB
  3: { api: 'baseball', leagueIds: [1] }, // MLB
  4: { api: 'hockey', leagueIds: [57] }, // NHL
  5: { api: 'football', leagueIds: [39, 2, 3, 140] }, // Premier League, Champions League, Europa League, La Liga
  6: { api: 'rugby', leagueIds: [16] }, // Six Nations
  7: { api: 'formula1', leagueIds: [1] }, // Formula 1
  8: { api: 'mma', leagueIds: [1] }, // UFC
  9: { api: 'tennis', leagueIds: [1, 2] }, // Tennis Majors
  10: { api: 'golf', leagueIds: [1] }, // PGA Tour
  11: { api: 'cricket', leagueIds: [1] }, // Cricket
  12: { api: 'esports', leagueIds: [1, 2, 3] } // Esports
};

// Fetch fixtures (events) for a specific sport
export async function fetchFixtures(sportId: number): Promise<any[]> {
  try {
    const sportConfig = sportApiMap[sportId];
    if (!sportConfig) {
      console.error(`No API configuration for sport ID: ${sportId}`);
      return [];
    }

    const { api, leagueIds } = sportConfig;
    const baseUrl = API_URLS[api as keyof typeof API_URLS];
    if (!baseUrl) {
      console.error(`No base URL for API: ${api}`);
      return [];
    }

    // Update headers for the specific API
    const apiHeaders = { ...headers, 'x-rapidapi-host': new URL(baseUrl).hostname };

    // Fetch fixtures for each league
    const allFixtures: any[] = [];
    for (const leagueId of leagueIds) {
      // We're looking for upcoming fixtures (next 7 days)
      const from = new Date();
      const to = new Date();
      to.setDate(to.getDate() + 7);

      const fromStr = from.toISOString().split('T')[0];
      const toStr = to.toISOString().split('T')[0];

      // Get fixtures endpoint varies by sport
      let endpoint = `/fixtures?league=${leagueId}&season=2024&from=${fromStr}&to=${toStr}`;
      if (api === 'basketball') {
        endpoint = `/games?league=${leagueId}&season=2023-2024&date=${fromStr}`;
      } else if (api === 'american_football') {
        endpoint = `/games?league=${leagueId}&season=2024`;
      }

      const response = await axios.get(`${baseUrl}${endpoint}`, { headers: apiHeaders });
      const fixtures = response.data.response || [];
      allFixtures.push(...fixtures);
    }

    return allFixtures;
  } catch (error) {
    console.error('Error fetching fixtures:', error);
    return [];
  }
}

// Fetch odds for a specific fixture
export async function fetchOdds(sportId: number, fixtureId: string): Promise<any> {
  try {
    const sportConfig = sportApiMap[sportId];
    if (!sportConfig) {
      console.error(`No API configuration for sport ID: ${sportId}`);
      return null;
    }

    const { api } = sportConfig;
    const baseUrl = API_URLS[api as keyof typeof API_URLS];
    if (!baseUrl) {
      console.error(`No base URL for API: ${api}`);
      return null;
    }

    // Update headers for the specific API
    const apiHeaders = { ...headers, 'x-rapidapi-host': new URL(baseUrl).hostname };

    // Endpoint varies by sport
    let endpoint = `/odds?fixture=${fixtureId}&bookmaker=1`;
    if (api === 'basketball') {
      endpoint = `/odds?game=${fixtureId}&bookmaker=1`;
    } else if (api === 'american_football') {
      endpoint = `/odds?game=${fixtureId}&bookmaker=1`;
    }

    const response = await axios.get(`${baseUrl}${endpoint}`, { headers: apiHeaders });
    return response.data.response[0] || null;
  } catch (error) {
    console.error(`Error fetching odds for fixture ${fixtureId}:`, error);
    return null;
  }
}

// Convert API fixture to our internal event format
function convertFixtureToEvent(fixture: any, sportId: number): InsertEvent {
  let homeTeam = '';
  let awayTeam = '';
  let startTime = new Date();
  let location = null;
  let externalId = '';

  // Different sports have different data structures
  if (sportId === 5) { // Soccer
    homeTeam = fixture.teams.home.name;
    awayTeam = fixture.teams.away.name;
    startTime = new Date(fixture.fixture.date);
    location = fixture.fixture.venue?.name || null;
    externalId = fixture.fixture.id.toString();
  } else if (sportId === 2) { // Basketball
    homeTeam = fixture.teams.home.name;
    awayTeam = fixture.teams.away.name;
    startTime = new Date(fixture.date);
    location = fixture.arena?.name || null;
    externalId = fixture.id.toString();
  } else if (sportId === 1) { // American Football
    homeTeam = fixture.teams.home.name;
    awayTeam = fixture.teams.away.name;
    startTime = new Date(fixture.game.date);
    location = fixture.game.venue?.name || null;
    externalId = fixture.game.id.toString();
  } else {
    // Default mapping for other sports (baseball, hockey, etc.)
    homeTeam = fixture.teams?.home?.name || fixture.home?.name || 'Unknown Home';
    awayTeam = fixture.teams?.away?.name || fixture.away?.name || 'Unknown Away';
    startTime = new Date(fixture.date || fixture.fixture?.date || fixture.game?.date || new Date());
    location = fixture.venue?.name || fixture.arena?.name || null;
    externalId = (fixture.id || fixture.fixture?.id || fixture.game?.id).toString();
  }

  return {
    sportId,
    homeTeam,
    awayTeam,
    startTime,
    location,
    status: 'scheduled',
    homeScore: null,
    awayScore: null,
    externalId
  };
}

// Convert API odds to our internal odds format
function convertOddsToInternalFormat(oddsData: any, eventId: number, sportId: number): InsertOdds {
  let moneylineHome = null;
  let moneylineAway = null;
  let spreadHome = null;
  let spreadHomeOdds = null;
  let spreadAway = null;
  let spreadAwayOdds = null;
  let totalPoints = null;
  let totalOverOdds = null;
  let totalUnderOdds = null;

  try {
    if (sportId === 5) { // Soccer
      // Find moneyline (1x2 in soccer)
      const moneylineMarket = oddsData.bookmakers[0]?.bets.find((b: any) => b.name === 'Match Winner');
      if (moneylineMarket) {
        moneylineHome = convertEuropeanToAmerican(moneylineMarket.values.find((v: any) => v.value === 'Home')?.odd);
        moneylineAway = convertEuropeanToAmerican(moneylineMarket.values.find((v: any) => v.value === 'Away')?.odd);
      }

      // Find totals
      const totalsMarket = oddsData.bookmakers[0]?.bets.find((b: any) => b.name === 'Goals Over/Under');
      if (totalsMarket) {
        const mainTotal = totalsMarket.values.find((v: any) => v.value.includes('Over'));
        if (mainTotal) {
          totalPoints = parseFloat(mainTotal.value.split(' ')[1]);
          totalOverOdds = convertEuropeanToAmerican(mainTotal.odd);
          
          const underTotal = totalsMarket.values.find((v: any) => 
            v.value.includes('Under') && v.value.includes(totalPoints.toString()));
          if (underTotal) {
            totalUnderOdds = convertEuropeanToAmerican(underTotal.odd);
          }
        }
      }

      // Find handicap (spread)
      const handicapMarket = oddsData.bookmakers[0]?.bets.find((b: any) => b.name === 'Asian Handicap');
      if (handicapMarket) {
        const homeHandicap = handicapMarket.values.find((v: any) => v.value.startsWith('Home'));
        if (homeHandicap) {
          spreadHome = parseFloat(homeHandicap.value.split(' ')[1]);
          spreadHomeOdds = convertEuropeanToAmerican(homeHandicap.odd);
          
          const awayHandicap = handicapMarket.values.find((v: any) => 
            v.value.startsWith('Away') && v.value.includes((-spreadHome).toString()));
          if (awayHandicap) {
            spreadAway = -spreadHome;
            spreadAwayOdds = convertEuropeanToAmerican(awayHandicap.odd);
          }
        }
      }
    } else if (sportId === 2) { // Basketball
      // Find moneyline
      const moneylineMarket = oddsData.bookmakers[0]?.bets.find((b: any) => b.name === 'Money Line');
      if (moneylineMarket) {
        moneylineHome = parseFloat(moneylineMarket.values.find((v: any) => v.value === 'Home')?.odd);
        moneylineAway = parseFloat(moneylineMarket.values.find((v: any) => v.value === 'Away')?.odd);
      }

      // Find totals
      const totalsMarket = oddsData.bookmakers[0]?.bets.find((b: any) => b.name === 'Over/Under');
      if (totalsMarket) {
        const mainTotal = totalsMarket.values.find((v: any) => v.value.includes('Over'));
        if (mainTotal) {
          totalPoints = parseFloat(mainTotal.value.split(' ')[1]);
          totalOverOdds = parseFloat(mainTotal.odd);
          
          const underTotal = totalsMarket.values.find((v: any) => 
            v.value.includes('Under') && v.value.includes(totalPoints.toString()));
          if (underTotal) {
            totalUnderOdds = parseFloat(underTotal.odd);
          }
        }
      }

      // Find spread
      const spreadMarket = oddsData.bookmakers[0]?.bets.find((b: any) => b.name === 'Point Spread');
      if (spreadMarket) {
        const homeSpread = spreadMarket.values.find((v: any) => v.value.includes('Home'));
        if (homeSpread) {
          spreadHome = parseFloat(homeSpread.value.split(' ')[1]);
          spreadHomeOdds = parseFloat(homeSpread.odd);
          
          const awaySpread = spreadMarket.values.find((v: any) => 
            v.value.includes('Away') && v.value.includes((-spreadHome).toString()));
          if (awaySpread) {
            spreadAway = -spreadHome;
            spreadAwayOdds = parseFloat(awaySpread.odd);
          }
        }
      }
    } else {
      // Default handling for other sports (football, baseball, hockey, etc.)
      // Moneyline
      const moneylineMarket = oddsData.bookmakers?.[0]?.bets.find((b: any) => 
        b.name === 'Money Line' || b.name === 'Match Winner');
      if (moneylineMarket) {
        moneylineHome = parseFloat(moneylineMarket.values.find((v: any) => 
          v.value === 'Home' || v.value.includes('1'))?.odd);
        moneylineAway = parseFloat(moneylineMarket.values.find((v: any) => 
          v.value === 'Away' || v.value.includes('2'))?.odd);
      }

      // Totals
      const totalsMarket = oddsData.bookmakers?.[0]?.bets.find((b: any) => 
        b.name === 'Over/Under' || b.name === 'Goals Over/Under' || b.name === 'Total');
      if (totalsMarket) {
        const mainTotal = totalsMarket.values.find((v: any) => v.value.includes('Over'));
        if (mainTotal) {
          const parts = mainTotal.value.split(' ');
          totalPoints = parseFloat(parts[parts.length - 1]);
          totalOverOdds = parseFloat(mainTotal.odd);
          
          const underTotal = totalsMarket.values.find((v: any) => 
            v.value.includes('Under') && v.value.includes(totalPoints?.toString() || ''));
          if (underTotal) {
            totalUnderOdds = parseFloat(underTotal.odd);
          }
        }
      }

      // Spread
      const spreadMarket = oddsData.bookmakers?.[0]?.bets.find((b: any) => 
        b.name === 'Point Spread' || b.name === 'Handicap' || b.name === 'Asian Handicap');
      if (spreadMarket) {
        const homeSpread = spreadMarket.values.find((v: any) => 
          v.value.includes('Home') || v.value.includes('1'));
        if (homeSpread) {
          const parts = homeSpread.value.split(' ');
          for (const part of parts) {
            const num = parseFloat(part);
            if (!isNaN(num)) {
              spreadHome = num;
              break;
            }
          }
          spreadHomeOdds = parseFloat(homeSpread.odd);
          
          const awaySpread = spreadMarket.values.find((v: any) => 
            v.value.includes('Away') || v.value.includes('2'));
          if (awaySpread) {
            spreadAway = -spreadHome!;
            spreadAwayOdds = parseFloat(awaySpread.odd);
          }
        }
      }
    }
  } catch (error) {
    console.error('Error parsing odds data:', error);
  }

  return {
    eventId,
    moneylineHome,
    moneylineAway,
    spreadHome,
    spreadHomeOdds,
    spreadAway,
    spreadAwayOdds,
    totalPoints,
    totalOverOdds,
    totalUnderOdds
  };
}

// Utility function to convert European odds (decimal) to American odds
function convertEuropeanToAmerican(europeanOdds: string | number): number | null {
  if (!europeanOdds) return null;
  
  const decimal = parseFloat(europeanOdds.toString());
  if (isNaN(decimal)) return null;
  
  // Convert decimal odds to American
  if (decimal >= 2.0) {
    return Math.round((decimal - 1) * 100);
  } else {
    return Math.round(-100 / (decimal - 1));
  }
}

// Refresh all sports data
export async function refreshSportsData(): Promise<{ events: number, odds: number }> {
  try {
    const sports = await storage.getAllSports();
    let eventCount = 0;
    let oddsCount = 0;
    
    // Process each sport
    for (const sport of sports) {
      // Skip disabled sports
      if (!sport.enabled) continue;
      
      // Fetch fixtures for this sport
      const fixtures = await fetchFixtures(sport.id);
      
      // Process each fixture
      for (const fixture of fixtures) {
        // Convert fixture to our internal event format
        const eventData = convertFixtureToEvent(fixture, sport.id);
        
        // Check if this event already exists
        let event = await storage.getEventByExternalId(eventData.externalId);
        
        if (!event) {
          // Create new event
          event = await storage.createEvent(eventData);
          eventCount++;
        }
        
        // Fetch odds for this event
        const oddsData = await fetchOdds(sport.id, eventData.externalId);
        
        if (oddsData) {
          // Convert odds to our internal format
          const odds = convertOddsToInternalFormat(oddsData, event.id, sport.id);
          
          // Create odds record
          await storage.createOdds(odds);
          oddsCount++;
        }
      }
    }
    
    return { events: eventCount, odds: oddsCount };
  } catch (error) {
    console.error('Error refreshing sports data:', error);
    return { events: 0, odds: 0 };
  }
}

// Initialize sports
export async function initializeSports(): Promise<void> {
  try {
    // Define sports
    const sportsToInitialize: InsertSport[] = [
      { name: 'American Football', enabled: true },
      { name: 'Basketball', enabled: true },
      { name: 'Baseball', enabled: true },
      { name: 'Hockey', enabled: true },
      { name: 'Soccer', enabled: true },
      { name: 'Rugby', enabled: true },
      { name: 'Formula 1', enabled: true },
      { name: 'MMA', enabled: true }
    ];
    
    // Check for existing sports first
    const existingSports = await storage.getAllSports();
    
    if (existingSports.length === 0) {
      // Create sports
      for (const sport of sportsToInitialize) {
        await storage.createSport(sport);
      }
      console.log('Sports initialized successfully');
    }
  } catch (error) {
    console.error('Error initializing sports:', error);
  }
}
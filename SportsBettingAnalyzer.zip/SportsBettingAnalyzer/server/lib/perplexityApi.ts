import axios from 'axios';

const API_KEY = process.env.PERPLEXITY_API_KEY;
const API_URL = 'https://api.perplexity.ai/chat/completions';

interface PerplexityResponse {
  id: string;
  model: string;
  object: string;
  created: number;
  citations: string[];
  choices: {
    index: number;
    finish_reason: string;
    message: {
      role: string;
      content: string;
    };
    delta: {
      role: string;
      content: string;
    };
  }[];
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

/**
 * Get betting analysis from Perplexity
 * @param matchup The teams involved in the matchup
 * @param bet The type of bet (moneyline, spread, etc.)
 * @returns Analysis text
 */
export async function getBettingAnalysis(matchup: string, bet: string): Promise<string> {
  try {
    const systemMessage = `You are a sports betting analyst with 15+ years of experience. 
    Provide a detailed analysis for the given matchup and bet type. 
    Include team strengths, weaknesses, recent form, head-to-head record, injuries, 
    statistical insights, and a clear prediction.`;

    const messages = [
      { role: 'system', content: systemMessage },
      { role: 'user', content: `Analyze this betting opportunity: ${matchup}, ${bet}. Provide your detailed analysis, stats, and prediction.` }
    ];

    const response = await makePerplexityRequest(messages);
    return response.content;
  } catch (error) {
    console.error('Error getting betting analysis:', error);
    return "Sorry, I couldn't generate an analysis at this time. Please try again later.";
  }
}

/**
 * Compare different betting strategies for an event
 * @param event The event to analyze
 * @returns Comparison text
 */
export async function compareStrategies(event: string): Promise<string> {
  try {
    const systemMessage = `You are a sports betting expert with deep knowledge of various betting strategies. 
    For the given event, compare different betting approaches including:
    1. Value betting
    2. Arbitrage betting
    3. Hedging strategies
    4. Prop betting opportunities
    5. Live betting tactics
    Provide specific examples and recommended implementations for this particular event.`;

    const messages = [
      { role: 'system', content: systemMessage },
      { role: 'user', content: `Compare different betting strategies for this event: ${event}. Show specific opportunities and approaches.` }
    ];

    const response = await makePerplexityRequest(messages);
    return response.content;
  } catch (error) {
    console.error('Error comparing strategies:', error);
    return "Sorry, I couldn't generate strategy comparisons at this time. Please try again later.";
  }
}

/**
 * Get crypto market insights from Perplexity
 * @returns Crypto market insights text
 */
export async function getCryptoMarketInsights(): Promise<string> {
  try {
    const systemMessage = `You are a crypto market analyst with expertise in how cryptocurrency trends 
    impact sports betting markets and sportsbooks. Provide insights on:
    1. Current crypto market conditions affecting sports betting platforms
    2. Opportunities for bettors using crypto
    3. How crypto volatility impacts betting strategies
    4. Recommendations for crypto usage in sports betting`;

    const messages = [
      { role: 'system', content: systemMessage },
      { role: 'user', content: `Provide current insights on cryptocurrency markets as they relate to sports betting. 
        Include analysis of major coins (BTC, ETH, etc.), transaction advantages, and strategic recommendations.` }
    ];

    const response = await makePerplexityRequest(messages);
    return response.content;
  } catch (error) {
    console.error('Error getting crypto insights:', error);
    return "Sorry, I couldn't generate crypto market insights at this time. Please try again later.";
  }
}

/**
 * Helper function to make requests to Perplexity API
 * @param messages Array of message objects
 * @returns The assistant's response content
 */
async function makePerplexityRequest(messages: {role: string, content: string}[]): Promise<{content: string, citations?: string[]}> {
  if (!API_KEY) {
    console.warn('PERPLEXITY_API_KEY not set, using fallback response');
    return { 
      content: "This is a fallback response. For detailed analysis, please set up the Perplexity API key." 
    };
  }

  try {
    const response = await axios.post<PerplexityResponse>(
      API_URL,
      {
        model: "llama-3.1-sonar-small-128k-online",
        messages,
        max_tokens: 1024,
        temperature: 0.2,
        top_p: 0.9,
        search_domain_filter: ["perplexity.ai"],
        return_images: false,
        return_related_questions: false,
        search_recency_filter: "month",
        top_k: 0,
        stream: false,
        presence_penalty: 0,
        frequency_penalty: 1
      },
      {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    return {
      content: response.data.choices[0].message.content,
      citations: response.data.citations
    };
  } catch (error: unknown) {
    if (axios.isAxiosError(error) && error.response) {
      console.error('Perplexity API error:', error.response.data);
      throw new Error(`Perplexity API error: ${error.response.status}`);
    }
    throw error;
  }
}
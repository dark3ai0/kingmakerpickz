import { Event, Odds, BetWithDetails } from "@shared/schema";
import { AutoMLClient } from '@google-cloud/automl';
import { PredictionServiceClient } from '@google-cloud/aiplatform';

interface ModelWeights {
  [sportId: string]: {
    [betType: string]: {
      teamStrength: number;
      recentForm: number;
      headToHead: number;
      homeAdvantage: number;
      injuries: number;
      weather: number;
      motivation: number;
      restDays: number;
      publicBetting: number;
      oddsTrend: number;
    }
  }
}

// Initial model weights (This will likely be replaced or updated by the GCP model)
let modelWeights: ModelWeights = {
  // Basketball (NBA, NCAAB)
  "2": {
    "moneyline": {
      teamStrength: 0.25,
      recentForm: 0.20,
      headToHead: 0.15,
      homeAdvantage: 0.10,
      injuries: 0.15,
      weather: 0.00,
      motivation: 0.05,
      restDays: 0.05,
      publicBetting: 0.02,
      oddsTrend: 0.03
    },
    "spread": {
      teamStrength: 0.20,
      recentForm: 0.20,
      headToHead: 0.15,
      homeAdvantage: 0.10,
      injuries: 0.15,
      weather: 0.00,
      motivation: 0.05,
      restDays: 0.08,
      publicBetting: 0.03,
      oddsTrend: 0.04
    },
    "total": {
      teamStrength: 0.15,
      recentForm: 0.20,
      headToHead: 0.10,
      homeAdvantage: 0.05,
      injuries: 0.15,
      weather: 0.00,
      motivation: 0.05,
      restDays: 0.15,
      publicBetting: 0.05,
      oddsTrend: 0.10
    }
  },
  // Football (NFL, NCAAF)
  "1": {
    "moneyline": {
      teamStrength: 0.25,
      recentForm: 0.20,
      headToHead: 0.10,
      homeAdvantage: 0.10,
      injuries: 0.15,
      weather: 0.05,
      motivation: 0.05,
      restDays: 0.05,
      publicBetting: 0.02,
      oddsTrend: 0.03
    },
    "spread": {
      teamStrength: 0.20,
      recentForm: 0.20,
      headToHead: 0.10,
      homeAdvantage: 0.10,
      injuries: 0.15,
      weather: 0.05,
      motivation: 0.05,
      restDays: 0.08,
      publicBetting: 0.03,
      oddsTrend: 0.04
    },
    "total": {
      teamStrength: 0.15,
      recentForm: 0.15,
      headToHead: 0.10,
      homeAdvantage: 0.05,
      injuries: 0.15,
      weather: 0.15,
      motivation: 0.05,
      restDays: 0.10,
      publicBetting: 0.05,
      oddsTrend: 0.05
    }
  },
  // Baseball (MLB)
  "3": {
    "moneyline": {
      teamStrength: 0.20,
      recentForm: 0.25,
      headToHead: 0.10,
      homeAdvantage: 0.05,
      injuries: 0.15,
      weather: 0.05,
      motivation: 0.05,
      restDays: 0.10,
      publicBetting: 0.02,
      oddsTrend: 0.03
    },
    "spread": {
      teamStrength: 0.15,
      recentForm: 0.25,
      headToHead: 0.10,
      homeAdvantage: 0.05,
      injuries: 0.15,
      weather: 0.05,
      motivation: 0.05,
      restDays: 0.10,
      publicBetting: 0.05,
      oddsTrend: 0.05
    },
    "total": {
      teamStrength: 0.15,
      recentForm: 0.20,
      headToHead: 0.10,
      homeAdvantage: 0.05,
      injuries: 0.15,
      weather: 0.10,
      motivation: 0.05,
      restDays: 0.10,
      publicBetting: 0.05,
      oddsTrend: 0.05
    }
  },
  // Hockey (NHL)
  "4": {
    "moneyline": {
      teamStrength: 0.25,
      recentForm: 0.20,
      headToHead: 0.10,
      homeAdvantage: 0.10,
      injuries: 0.15,
      weather: 0.00,
      motivation: 0.05,
      restDays: 0.10,
      publicBetting: 0.02,
      oddsTrend: 0.03
    },
    "spread": {
      teamStrength: 0.20,
      recentForm: 0.20,
      headToHead: 0.10,
      homeAdvantage: 0.10,
      injuries: 0.15,
      weather: 0.00,
      motivation: 0.05,
      restDays: 0.10,
      publicBetting: 0.05,
      oddsTrend: 0.05
    },
    "total": {
      teamStrength: 0.15,
      recentForm: 0.20,
      headToHead: 0.10,
      homeAdvantage: 0.05,
      injuries: 0.15,
      weather: 0.00,
      motivation: 0.05,
      restDays: 0.15,
      publicBetting: 0.05,
      oddsTrend: 0.10
    }
  },
  // Soccer
  "5": {
    "moneyline": {
      teamStrength: 0.25,
      recentForm: 0.25,
      headToHead: 0.15,
      homeAdvantage: 0.10,
      injuries: 0.10,
      weather: 0.02,
      motivation: 0.08,
      restDays: 0.02,
      publicBetting: 0.01,
      oddsTrend: 0.02
    },
    "spread": {
      teamStrength: 0.20,
      recentForm: 0.25,
      headToHead: 0.15,
      homeAdvantage: 0.10,
      injuries: 0.10,
      weather: 0.02,
      motivation: 0.08,
      restDays: 0.05,
      publicBetting: 0.02,
      oddsTrend: 0.03
    },
    "total": {
      teamStrength: 0.15,
      recentForm: 0.20,
      headToHead: 0.15,
      homeAdvantage: 0.05,
      injuries: 0.10,
      weather: 0.10,
      motivation: 0.05,
      restDays: 0.10,
      publicBetting: 0.05,
      oddsTrend: 0.05
    }
  },
  // Default for all other sports
  "default": {
    "moneyline": {
      teamStrength: 0.25,
      recentForm: 0.20,
      headToHead: 0.15,
      homeAdvantage: 0.10,
      injuries: 0.10,
      weather: 0.05,
      motivation: 0.05,
      restDays: 0.05,
      publicBetting: 0.02,
      oddsTrend: 0.03
    },
    "spread": {
      teamStrength: 0.20,
      recentForm: 0.20,
      headToHead: 0.15,
      homeAdvantage: 0.10,
      injuries: 0.10,
      weather: 0.05,
      motivation: 0.05,
      restDays: 0.08,
      publicBetting: 0.03,
      oddsTrend: 0.04
    },
    "total": {
      teamStrength: 0.15,
      recentForm: 0.20,
      headToHead: 0.10,
      homeAdvantage: 0.05,
      injuries: 0.10,
      weather: 0.05,
      motivation: 0.05,
      restDays: 0.15,
      publicBetting: 0.05,
      oddsTrend: 0.10
    }
  }
};

interface TrainingResult {
  previousWeights: any;
  newWeights: any;
  improvements: {
    [betType: string]: {
      beforeAccuracy: number;
      afterAccuracy: number;
      percentageImprovement: number;
    }
  };
  processedBets: number;
}

interface PredictionResult {
  confidence: number;
  factors: {
    [factor: string]: {
      weight: number;
      score: number;
      contribution: number;
    }
  };
  expectedValue: number;
}

interface EdgeBet {
  eventId: number;
  homeTeam: string;
  awayTeam: string;
  betType: string;
  pick: string;
  confidence: number;
  impliedProbability: number;
  modelProbability: number;
  edge: number;
  recommendedStake: number;
  reasoning: string;
  startTime: Date;
}

const autoMLClient = new AutoMLClient();
const predictionClient = new PredictionServiceClient();

// Returns the current model weights
export function getModelWeights(): ModelWeights {
  return modelWeights;
}

// Reset model weights for a specific sport and bet type (or all bet types if not specified)
export function resetModelWeights(sportId: number | string, betType?: string): { success: boolean; message: string } {
  const sportIdStr = sportId.toString();

  if (!modelWeights[sportIdStr]) {
    return {
      success: false,
      message: `Sport ID ${sportId} not found in model`
    };
  }

  if (betType) {
    if (!modelWeights[sportIdStr][betType]) {
      return {
        success: false,
        message: `Bet type ${betType} not found for sport ID ${sportId}`
      };
    }

    // Reset weights for specific bet type to defaults
    modelWeights[sportIdStr][betType] = { ...modelWeights["default"][betType] };

    return {
      success: true,
      message: `Reset model weights for sport ID ${sportId}, bet type ${betType}`
    };
  }

  // Reset all bet types for this sport
  modelWeights[sportIdStr] = {
    "moneyline": { ...modelWeights["default"]["moneyline"] },
    "spread": { ...modelWeights["default"]["spread"] },
    "total": { ...modelWeights["default"]["total"] }
  };

  return {
    success: true,
    message: `Reset all model weights for sport ID ${sportId}`
  };
}

// Simulate model training based on betting history (This will be replaced)
export async function trainModel(bets: BetWithDetails[]): Promise<TrainingResult> {
    try {
        const trainingData = transformBetsForAutoML(bets); // Function to transform data for AutoML
        const model = await trainModelWithAutoML(trainingData);
        //Further processing of the model from AutoML to update modelWeights (implementation needed)
        return {previousWeights: {}, newWeights: modelWeights, improvements: {}, processedBets: bets.length}

    } catch(error){
        console.error("Error training model:", error);
        throw error;
    }
}

async function trainModelWithAutoML(trainingData: any){
    try {
      const [operation] = await autoMLClient.createModel({
        parent: `projects/${process.env.GOOGLE_CLOUD_PROJECT}/locations/${process.env.GOOGLE_CLOUD_LOCATION}`,
        model: {
          displayName: 'sports-betting-model',
          tablesModel: {
            inputFeatureColumns: ['team_stats', 'historical_odds', 'weather', 'injuries'],
            targetColumn: 'outcome'
          }
        },
        trainingData
      });

      const [model] = await operation.promise();
      return model;
    } catch (error) {
      console.error('Error training model:', error);
      throw error;
    }
}


function transformBetsForAutoML(bets: BetWithDetails[]): any {
    //Implementation to transform bets array into a format suitable for AutoML training
    //This will likely involve extracting relevant features and creating the appropriate structure.
    return []; // Placeholder, needs implementation
}


// Helper function to normalize weights to ensure they sum to 1
function normalizeWeights(weights: any) {
  const sum = Object.values(weights).reduce((acc: number, val: any) => acc + val, 0);

  if (sum > 0 && Math.abs(sum - 1) > 0.01) {
    Object.keys(weights).forEach(key => {
      weights[key] = weights[key] / sum;
    });
  }
}

// Calculate weight adjustments based on bet outcome
function calculateWeightAdjustments(bet: any, weights: any, prediction: any): any {
  const LEARNING_RATE = 0.02;
  const adjustments: any = {};
  const isWin = bet.result === "win";

  // Initialize all adjustments to 0
  Object.keys(weights).forEach(factor => {
    adjustments[factor] = 0;
  });

  // If prediction was correct (high confidence win or low confidence loss), small positive adjustments
  // If prediction was wrong (high confidence loss or low confidence win), larger negative adjustments
  if ((prediction.confidence > 0.6 && isWin) || (prediction.confidence < 0.4 && !isWin)) {
    // Prediction was correct, small positive reinforcement
    Object.keys(prediction.factors).forEach(factor => {
      const contribution = prediction.factors[factor].contribution;
      adjustments[factor] = LEARNING_RATE * 0.5 * contribution;
    });
  } else if ((prediction.confidence > 0.6 && !isWin) || (prediction.confidence < 0.4 && isWin)) {
    // Prediction was wrong, stronger negative adjustment
    Object.keys(prediction.factors).forEach(factor => {
      const contribution = prediction.factors[factor].contribution;
      adjustments[factor] = -LEARNING_RATE * contribution;
    });
  } else {
    // Prediction was neutral (0.4-0.6), minor adjustments
    Object.keys(prediction.factors).forEach(factor => {
      const contribution = prediction.factors[factor].contribution;
      adjustments[factor] = LEARNING_RATE * 0.1 * (isWin ? contribution : -contribution);
    });
  }

  return adjustments;
}

// Helper function to simulate a prediction for training purposes
function simulatePrediction(event: any, odds: any, betType: string, pick: string, weights: any): PredictionResult {
  // Get factor scores
  const factors: { [key: string]: { weight: number; score: number; contribution: number; } } = {};
  let totalContribution = 0;

  // Calculate factor scores (simplified for simulation)
  Object.keys(weights).forEach(factor => {
    const weight = weights[factor];
    // Generate a simulated score between 0-1
    const score = simulateFactorScore(factor, event, odds, betType, pick);
    const contribution = weight * score;

    factors[factor] = {
      weight,
      score,
      contribution
    };

    totalContribution += contribution;
  });

  // Calculate confidence (0-1)
  const confidence = Math.min(1, Math.max(0, totalContribution));

  // Calculate expected value
  const impliedProbability = calculateImpliedProbability(odds, betType, pick);
  const modelProbability = confidence;
  const edge = modelProbability - impliedProbability;
  const expectedValue = (modelProbability * 1) - ((1 - modelProbability) * 1);

  return {
    confidence,
    factors,
    expectedValue
  };
}

// Simulate factor scores (in real implementation, this would use actual data)
function simulateFactorScore(
  factor: string,
  event: any,
  odds: any,
  betType: string,
  pick: string
): number {
  // In a real implementation, these would be calculated based on actual data
  // For simulation, we'll return reasonable values

  switch (factor) {
    case "teamStrength":
      return Math.random() * 0.3 + 0.5; // 0.5-0.8 range
    case "recentForm":
      return Math.random() * 0.6 + 0.2; // 0.2-0.8 range
    case "headToHead":
      return Math.random() * 0.5 + 0.3; // 0.3-0.8 range
    case "homeAdvantage":
      if (pick === event.homeTeam) {
        return Math.random() * 0.3 + 0.6; // 0.6-0.9 range for home team picks
      }
      return Math.random() * 0.3 + 0.2; // 0.2-0.5 range for away team picks
    case "injuries":
      return Math.random() * 0.6 + 0.2; // 0.2-0.8 range
    case "weather":
      return Math.random() * 0.7 + 0.1; // 0.1-0.8 range
    case "motivation":
      return Math.random() * 0.5 + 0.3; // 0.3-0.8 range
    case "restDays":
      return Math.random() * 0.6 + 0.2; // 0.2-0.8 range
    case "publicBetting":
      return Math.random() * 0.4 + 0.3; // 0.3-0.7 range
    case "oddsTrend":
      return Math.random() * 0.5 + 0.3; // 0.3-0.8 range
    default:
      return 0.5;
  }
}

// Generate a prediction for a potential bet (This will be replaced)
export async function predictConfidence(
  event: Event,
  odds: Odds,
  betType: string,
  pick: string
): Promise<PredictionResult> {
    try{
        const features = transformEventForPrediction(event, odds, betType, pick); // Function to transform data for prediction
        const prediction = await generatePredictionsWithVertexAI(features);
        //Further processing of the prediction from Vertex AI (implementation needed)
        return {confidence: 0.5, factors: {}, expectedValue: 0}; // Placeholder, needs implementation

    } catch (error){
        console.error("Error generating prediction:", error);
        throw error;
    }
}

async function generatePredictionsWithVertexAI(features: any){
    try {
      const endpoint = process.env.MODEL_ENDPOINT;
      const [response] = await predictionClient.predict({
        endpoint,
        instances: [features]
      });

      return {
        predictions: response.predictions,
        metadata: response.metadata
      };
    } catch (error) {
      console.error('Error generating predictions:', error);
      throw error;
    }
}

function transformEventForPrediction(event: Event, odds: Odds, betType: string, pick: string): any {
    //Implementation to transform event and odds data into a format suitable for Vertex AI prediction
    //This will likely involve selecting relevant features and creating the appropriate structure.
    return {}; // Placeholder, needs implementation
}

// Actual implementation of factor score calculation
function calculateFactorScore(
  factor: string,
  event: Event,
  odds: Odds,
  betType: string,
  pick: string
): number {
  // This would be a sophisticated analysis in production
  // For now, we'll use similar values to the simulation

  switch (factor) {
    case "teamStrength":
      return 0.65; // Placeholder for team strength analysis
    case "recentForm":
      return 0.60; // Placeholder for recent form analysis
    case "headToHead":
      return 0.55; // Placeholder for head-to-head analysis
    case "homeAdvantage":
      return pick === event.homeTeam ? 0.75 : 0.35; // Home team advantage
    case "injuries":
      return 0.50; // Placeholder for injury analysis
    case "weather":
      return 0.50; // Placeholder for weather analysis
    case "motivation":
      return 0.60; // Placeholder for motivation analysis
    case "restDays":
      return 0.55; // Placeholder for rest days analysis
    case "publicBetting":
      return 0.50; // Placeholder for public betting analysis
    case "oddsTrend":
      return 0.55; // Placeholder for odds trend analysis
    default:
      return 0.50;
  }
}

// Calculate implied probability from odds based on bet type
function calculateImpliedProbability(odds: Odds, betType: string, pick: string): number {
  switch (betType) {
    case "moneyline":
      if (pick === "home") {
        return convertOddsToImpliedProbability(odds.moneylineHome || 0);
      } else {
        return convertOddsToImpliedProbability(odds.moneylineAway || 0);
      }
    case "spread":
      if (pick === "home") {
        return convertOddsToImpliedProbability(odds.spreadHomeOdds || 0);
      } else {
        return convertOddsToImpliedProbability(odds.spreadAwayOdds || 0);
      }
    case "total":
      if (pick === "over") {
        return convertOddsToImpliedProbability(odds.totalOverOdds || 0);
      } else {
        return convertOddsToImpliedProbability(odds.totalUnderOdds || 0);
      }
    default:
      return 0.5;
  }
}

// Convert American odds to implied probability
function convertOddsToImpliedProbability(americanOdds: number): number {
  if (americanOdds === 0) return 0.5;

  if (americanOdds > 0) {
    return 100 / (americanOdds + 100);
  } else {
    return Math.abs(americanOdds) / (Math.abs(americanOdds) + 100);
  }
}

// Generate potential edge bets from upcoming events
export function generateEdgeBets(events: Event[], allOdds: Odds[]): EdgeBet[] {
  const edgeBets: EdgeBet[] = [];
  const EDGE_THRESHOLD = 0.05; // 5% edge minimum

  events.forEach((event, index) => {
    const odds = allOdds[index];
    if (!odds) return;

    // Check moneyline bets
    checkEdgeBet(event, odds, "moneyline", "home", edgeBets, EDGE_THRESHOLD);
    checkEdgeBet(event, odds, "moneyline", "away", edgeBets, EDGE_THRESHOLD);

    // Check spread bets
    checkEdgeBet(event, odds, "spread", "home", edgeBets, EDGE_THRESHOLD);
    checkEdgeBet(event, odds, "spread", "away", edgeBets, EDGE_THRESHOLD);

    // Check total bets
    checkEdgeBet(event, odds, "total", "over", edgeBets, EDGE_THRESHOLD);
    checkEdgeBet(event, odds, "total", "under", edgeBets, EDGE_THRESHOLD);
  });

  // Sort by edge (highest first)
  return edgeBets.sort((a, b) => b.edge - a.edge);
}

// Helper function to check for edge bets
function checkEdgeBet(
  event: Event,
  odds: Odds,
  betType: string,
  pick: string,
  edgeBets: EdgeBet[],
  threshold: number
): void {
  // Calculate model confidence
  const prediction = predictConfidence(event, odds, betType, pick);
  const modelProbability = prediction.confidence;

  // Get implied probability from odds
  const impliedProbability = calculateImpliedProbability(odds, betType, pick);

  // Calculate edge
  const edge = modelProbability - impliedProbability;

  // If edge exceeds threshold, add to edge bets
  if (edge > threshold) {
    // Calculate recommended stake (Kelly Criterion with fraction)
    const kellyFraction = 0.3; // Conservative Kelly
    const recommendedStake = Math.max(0, kellyFraction * ((modelProbability * 1) - ((1 - modelProbability) * 1)) / 1);

    // Generate reasoning
    const reasoning = generateBetReasoning(event, odds, betType, pick, prediction, edge);

    edgeBets.push({
      eventId: event.id,
      homeTeam: event.homeTeam,
      awayTeam: event.awayTeam,
      betType,
      pick,
      confidence: modelProbability,
      impliedProbability,
      modelProbability,
      edge,
      recommendedStake,
      reasoning,
      startTime: event.startTime
    });
  }
}

// Generate reasoning for edge bets
function generateBetReasoning(
  event: Event,
  odds: Odds,
  betType: string,
  pick: string,
  prediction: PredictionResult,
  edge: number
): string {
  // Get top factors
  const sortedFactors = Object.entries(prediction.factors)
    .sort((a, b) => b[1].contribution - a[1].contribution)
    .slice(0, 3);

  // Format the bet description
  let betDescription = "";
  switch (betType) {
    case "moneyline":
      betDescription = `${pick === "home" ? event.homeTeam : event.awayTeam} moneyline`;
      break;
    case "spread":
      if (pick === "home") {
        betDescription = `${event.homeTeam} ${odds.spreadHome >= 0 ? "+" : ""}${odds.spreadHome || 0}`;
      } else {
        betDescription = `${event.awayTeam} ${odds.spreadAway >= 0 ? "+" : ""}${odds.spreadAway || 0}`;
      }
      break;
    case "total":
      betDescription = `${pick.toUpperCase()} ${odds.totalPoints || 0}`;
      break;
  }

  // Generate reasoning text
  return `The model gives ${betDescription} a ${(prediction.confidence * 100).toFixed(1)}% chance of winning, ` +
         `compared to the implied odds of ${(impliedProbability * 100).toFixed(1)}%, creating a ${(edge * 100).toFixed(1)}% edge. ` +
         `Key factors: ${sortedFactors.map(([factor, data]) =>
           `${factor} (${(data.contribution * 100).toFixed(1)}%)`).join(", ")}.`;
}
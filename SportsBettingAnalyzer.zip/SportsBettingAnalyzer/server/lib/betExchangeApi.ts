import axios from 'axios';
import { BetExchangeProvider } from '@shared/schema';
import { storage } from '../storage';

// Interface for credentials
interface ExchangeCredentials {
  username: string;
  password: string;
  appKey?: string;
}

// Interface for API configuration
interface ExchangeApiConfig {
  baseUrl: string;
  headers: Record<string, string>;
  auth: {
    username?: string;
    password?: string;
    token?: string;
    appKey?: string;
  };
}

// Interface for bet placement request
interface PlaceBetRequest {
  userId: number;
  exchangeProvider: string;
  marketId: string;
  selectionId: string;
  betType: string;
  stake: string;
  requestedPrice: string;
  betId?: number | null;
}

// Interface for bet response
interface PlaceBetResponse {
  success: boolean;
  betId?: string;
  message?: string;
  error?: string;
  matchedPrice?: number;
}

// Interface for account balance
interface AccountBalance {
  available: number;
  exposure: number;
  total: number;
  currency: string;
}

// Interface for market data
interface MarketData {
  marketId: string;
  marketName: string;
  eventName: string;
  selections: {
    selectionId: string;
    selectionName: string;
    price: number;
    size: number;
  }[];
}

// API configurations for different exchanges
const exchangeConfigs: Record<BetExchangeProvider, (token: string) => ExchangeApiConfig> = {
  betfair: (token: string) => ({
    baseUrl: 'https://api.betfair.com/exchange/betting/rest/v1.0',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'X-Application': process.env.BETFAIR_APP_KEY || '',
      'X-Authentication': token
    },
    auth: {
      appKey: process.env.BETFAIR_APP_KEY || ''
    }
  }),
  pinnacle: (token: string) => ({
    baseUrl: 'https://api.pinnacle.com/v1',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    auth: {}
  }),
  draftkings: (token: string) => ({
    baseUrl: 'https://api.draftkings.com/v1',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    auth: {}
  }),
  fanduel: (token: string) => ({
    baseUrl: 'https://api.fanduel.com/v1',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    auth: {}
  }),
  betmgm: (token: string) => ({
    baseUrl: 'https://api.betmgm.com/v1',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    auth: {}
  })
};

/**
 * Main authentication wrapper for the various betting exchanges
 * @param provider Betting exchange provider
 * @param credentials Object containing username, password, and optional appKey
 * @returns Authentication result with token if successful
 */
export async function authenticateWithExchange(
  provider: BetExchangeProvider,
  credentials: ExchangeCredentials
): Promise<string> {
  const { username, password } = credentials;
  
  // Authenticate with the exchange
  const result = await authenticateExchange(provider, username, password);
  
  if (!result.success || !result.token) {
    throw new Error(result.message || 'Authentication failed');
  }
  
  return result.token;
}

/**
 * Authenticate with a betting exchange
 * @param provider Betting exchange provider
 * @param username Username for authentication
 * @param password Password for authentication
 * @returns Authentication token or error
 */
export async function authenticateExchange(
  provider: BetExchangeProvider,
  username: string,
  password: string
): Promise<{ success: boolean; token?: string; message?: string }> {
  try {
    switch (provider) {
      case 'betfair':
        return await authenticateBetfair(username, password);
      case 'pinnacle':
      case 'draftkings':
      case 'fanduel':
      case 'betmgm':
        // For now, these providers return a mock implementation
        return { 
          success: true, 
          token: `mock-token-${provider}-${Date.now()}`,
          message: `${provider} authentication successful (mock implementation)`
        };
      default:
        return { success: false, message: 'Unsupported betting exchange provider' };
    }
  } catch (error: unknown) {
    console.error(`Error authenticating with ${provider}:`, error);
    if (error instanceof Error) {
      return { success: false, message: `Authentication error: ${error.message}` };
    }
    return { success: false, message: 'Unknown authentication error' };
  }
}

/**
 * Authenticate with Betfair exchange
 * @param username Betfair username
 * @param password Betfair password
 * @returns Authentication token or error
 */
async function authenticateBetfair(username: string, password: string): Promise<{ success: boolean; token?: string; message?: string }> {
  try {
    const response = await axios.post(
      'https://identitysso.betfair.com/api/login',
      { username, password },
      {
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-Application': process.env.BETFAIR_APP_KEY || ''
        }
      }
    );

    if (response.data.status === 'SUCCESS') {
      return { success: true, token: response.data.token };
    } else {
      return { success: false, message: response.data.error || 'Authentication failed' };
    }
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      return { success: false, message: `Betfair authentication error: ${error.response.data.error || error.message}` };
    }
    return { success: false, message: 'Unknown Betfair authentication error' };
  }
}

/**
 * Authenticate with Matchbook exchange
 * @param username Matchbook username
 * @param password Matchbook password
 * @returns Authentication token or error
 */
async function authenticateMatchbook(username: string, password: string): Promise<{ success: boolean; token?: string; message?: string }> {
  try {
    const response = await axios.post(
      'https://api.matchbook.com/bpapi/rest/security/session',
      { username, password },
      {
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        }
      }
    );

    if (response.data.session) {
      return { success: true, token: response.data.session.token };
    } else {
      return { success: false, message: 'Matchbook authentication failed' };
    }
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      return { success: false, message: `Matchbook authentication error: ${error.response.data.message || error.message}` };
    }
    return { success: false, message: 'Unknown Matchbook authentication error' };
  }
}

/**
 * Authenticate with Betdaq exchange
 * @param username Betdaq username
 * @param password Betdaq password
 * @returns Authentication token or error
 */
async function authenticateBetdaq(username: string, password: string): Promise<{ success: boolean; token?: string; message?: string }> {
  // Note: Betdaq uses a different authentication method in production
  // This is a simplified version for demonstration purposes
  try {
    const response = await axios.post(
      'https://api.betdaq.com/v2.0/Authentication/SignIn',
      { username, password },
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    if (response.data.success) {
      return { success: true, token: response.data.token };
    } else {
      return { success: false, message: response.data.message || 'Betdaq authentication failed' };
    }
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      return { success: false, message: `Betdaq authentication error: ${error.response.data.message || error.message}` };
    }
    return { success: false, message: 'Unknown Betdaq authentication error' };
  }
}

/**
 * Authenticate with Smarkets exchange
 * @param username Smarkets username
 * @param password Smarkets password
 * @returns Authentication token or error
 */
async function authenticateSmarkets(username: string, password: string): Promise<{ success: boolean; token?: string; message?: string }> {
  try {
    const response = await axios.post(
      'https://api.smarkets.com/v3/auth/token/',
      { username, password },
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    if (response.data.token) {
      return { success: true, token: response.data.token };
    } else {
      return { success: false, message: 'Smarkets authentication failed' };
    }
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      return { success: false, message: `Smarkets authentication error: ${error.response.data.message || error.message}` };
    }
    return { success: false, message: 'Unknown Smarkets authentication error' };
  }
}

/**
 * Get markets for an event from a betting exchange
 * @param provider Betting exchange provider
 * @param token Authentication token
 * @param eventId External event ID on the exchange
 * @returns Market data or error
 */
export async function getMarketsForEvent(
  provider: BetExchangeProvider,
  token: string,
  eventId: string
): Promise<{ success: boolean; markets?: MarketData[]; message?: string }> {
  try {
    const config = exchangeConfigs[provider](token);
    
    // Different exchanges have different endpoints and data structures
    switch (provider) {
      case 'betfair':
        const response = await axios.post(
          `${config.baseUrl}/listMarketCatalogue`,
          {
            filter: {
              eventIds: [eventId]
            },
            maxResults: 100,
            marketProjection: ['MARKET_DESCRIPTION', 'RUNNER_DESCRIPTION']
          },
          { headers: config.headers }
        );

        // Transform Betfair response to our common format
        const markets = response.data.map((market: any) => ({
          marketId: market.marketId,
          marketName: market.marketName,
          eventName: market.event?.name || 'Unknown Event',
          selections: market.runners.map((runner: any) => ({
            selectionId: runner.selectionId,
            selectionName: runner.runnerName,
            price: 0, // Prices need to be fetched separately in Betfair
            size: 0
          }))
        }));

        return { success: true, markets };
        
      case 'pinnacle':
      case 'draftkings':
      case 'fanduel':
      case 'betmgm':
        // Mock implementation for other providers
        return { 
          success: true, 
          markets: [
            {
              marketId: `mock-market-${provider}-1`,
              marketName: 'Match Odds',
              eventName: 'Mock Event',
              selections: [
                { selectionId: 'mock-selection-1', selectionName: 'Home Team', price: 1.95, size: 1000 },
                { selectionId: 'mock-selection-2', selectionName: 'Away Team', price: 2.05, size: 1000 }
              ]
            }
          ]
        };
        
      default:
        return { success: false, message: 'Unsupported betting exchange provider' };
    }
  } catch (error) {
    console.error(`Error getting markets from ${provider}:`, error);
    return { success: false, message: `Error fetching markets: ${error instanceof Error ? error.message : 'Unknown error'}` };
  }
}

/**
 * Get odds for a specific market
 * @param provider Betting exchange provider
 * @param token Authentication token
 * @param marketId Market ID on the exchange
 * @returns Market odds data or error
 */
export async function getOddsForMarket(
  provider: BetExchangeProvider,
  token: string,
  marketId: string
): Promise<{ success: boolean; odds?: any; message?: string }> {
  try {
    const config = exchangeConfigs[provider](token);
    
    // Different exchanges have different endpoints and data structures
    switch (provider) {
      case 'betfair':
        const response = await axios.post(
          `${config.baseUrl}/listMarketBook`,
          {
            marketIds: [marketId],
            priceProjection: {
              priceData: ['EX_BEST_OFFERS'],
              virtualise: true
            }
          },
          { headers: config.headers }
        );

        if (response.data && response.data.length > 0) {
          const market = response.data[0];
          
          // Format runners with their prices
          const formattedOdds = {
            marketId: market.marketId,
            status: market.status,
            runners: market.runners.map((runner: any) => {
              const availableToBack = runner.ex?.availableToBack || [];
              const availableToLay = runner.ex?.availableToLay || [];
              
              return {
                selectionId: runner.selectionId,
                status: runner.status,
                lastPriceTraded: runner.lastPriceTraded,
                bestBackPrice: availableToBack.length > 0 ? availableToBack[0].price : null,
                bestBackSize: availableToBack.length > 0 ? availableToBack[0].size : null,
                bestLayPrice: availableToLay.length > 0 ? availableToLay[0].price : null,
                bestLaySize: availableToLay.length > 0 ? availableToLay[0].size : null
              };
            })
          };
          
          return { success: true, odds: formattedOdds };
        }
        
        return { success: false, message: 'No odds data found for this market' };
        
      case 'pinnacle':
      case 'draftkings':
      case 'fanduel':
      case 'betmgm':
        // Mock implementation for other providers
        return { 
          success: true, 
          odds: {
            marketId,
            status: 'OPEN',
            runners: [
              {
                selectionId: 'mock-selection-1',
                status: 'ACTIVE',
                lastPriceTraded: 1.95,
                bestBackPrice: 1.94,
                bestBackSize: 500,
                bestLayPrice: 1.96,
                bestLaySize: 400
              },
              {
                selectionId: 'mock-selection-2',
                status: 'ACTIVE',
                lastPriceTraded: 2.05,
                bestBackPrice: 2.04,
                bestBackSize: 450,
                bestLayPrice: 2.06,
                bestLaySize: 350
              }
            ]
          }
        };
        
      default:
        return { success: false, message: 'Unsupported betting exchange provider' };
    }
  } catch (error) {
    console.error(`Error getting odds from ${provider}:`, error);
    return { success: false, message: `Error fetching odds: ${error instanceof Error ? error.message : 'Unknown error'}` };
  }
}

/**
 * Place a bet on a betting exchange
 * @param provider Betting exchange provider
 * @param token Authentication token
 * @param params Bet parameters
 * @returns Bet placement result
 */
export async function placeBet(
  provider: BetExchangeProvider,
  token: string,
  params: PlaceBetRequest
): Promise<PlaceBetResponse> {
  try {
    const config = exchangeConfigs[provider](token);
    
    // Different exchanges have different endpoints and data structures
    switch (provider) {
      case 'betfair':
        // Convert params to Betfair format
        const betfairRequest = {
          marketId: params.marketId,
          instructions: [
            {
              selectionId: params.selectionId,
              handicap: 0,
              side: params.betType.toUpperCase() === 'BACK' ? 'BACK' : 'LAY',
              orderType: 'LIMIT',
              limitOrder: {
                size: parseFloat(params.stake),
                price: parseFloat(params.requestedPrice),
                persistenceType: 'LAPSE'
              }
            }
          ]
        };
        
        const response = await axios.post(
          `${config.baseUrl}/placeOrders`,
          betfairRequest,
          { headers: config.headers }
        );
        
        if (response.data.status === 'SUCCESS') {
          // Get the bet ID from the response
          const betId = response.data.instructionReports[0]?.betId;
          const matchedPrice = response.data.instructionReports[0]?.averagePriceMatched;
          
          return { 
            success: true, 
            betId, 
            matchedPrice,
            message: 'Bet placed successfully' 
          };
        } else {
          return { 
            success: false, 
            error: response.data.errorCode || 'Failed to place bet' 
          };
        }
        
      case 'pinnacle':
      case 'draftkings':
      case 'fanduel':
      case 'betmgm':
        // Mock implementation for other providers
        return {
          success: true,
          betId: `mock-bet-${provider}-${Date.now()}`,
          matchedPrice: parseFloat(params.requestedPrice),
          message: `Bet placed successfully on ${provider} (mock implementation)`
        };
        
      default:
        return { success: false, error: 'Unsupported betting exchange provider' };
    }
  } catch (error) {
    console.error(`Error placing bet on ${provider}:`, error);
    return { 
      success: false, 
      error: `Error placing bet: ${error instanceof Error ? error.message : 'Unknown error'}` 
    };
  }
}

/**
 * Get account balance from a betting exchange
 * @param provider Betting exchange provider
 * @param token Authentication token
 * @returns Account balance or error
 */
export async function getAccountBalance(
  provider: BetExchangeProvider,
  token: string
): Promise<{ success: boolean; balance?: AccountBalance; message?: string }> {
  try {
    const config = exchangeConfigs[provider](token);
    
    // Different exchanges have different endpoints and data structures
    switch (provider) {
      case 'betfair':
        const response = await axios.post(
          `${config.baseUrl.replace('/betting/rest/v1.0', '/account/rest/v1.0')}/getAccountFunds`,
          {},
          { headers: config.headers }
        );
        
        if (response.data) {
          return { 
            success: true, 
            balance: {
              available: response.data.availableToBetBalance,
              exposure: response.data.exposure,
              total: response.data.availableToBetBalance - response.data.exposure,
              currency: response.data.currencyCode
            }
          };
        }
        
        return { success: false, message: 'Failed to retrieve account balance' };
        
      case 'pinnacle':
      case 'draftkings':
      case 'fanduel':
      case 'betmgm':
        // Mock implementation for other providers
        return { 
          success: true, 
          balance: {
            available: 5000,
            exposure: 1000,
            total: 4000,
            currency: 'USD'
          }
        };
        
      default:
        return { success: false, message: 'Unsupported betting exchange provider' };
    }
  } catch (error) {
    console.error(`Error getting balance from ${provider}:`, error);
    return { 
      success: false, 
      message: `Error fetching balance: ${error instanceof Error ? error.message : 'Unknown error'}` 
    };
  }
}

/**
 * Place a bet through our platform and record it
 * @param params Bet parameters
 * @returns Bet placement result
 */
export async function executeAutomatedBet(params: PlaceBetRequest): Promise<{ success: boolean; message: string; betId?: number }> {
  try {
    // Get the account for the user
    const accounts = await storage.getBetExchangeAccountsByUserId(params.userId);
    const account = accounts.find(a => a.provider === params.exchangeProvider && a.active);
    
    if (!account) {
      return { success: false, message: `No active ${params.exchangeProvider} account found for this user` };
    }
    
    // Create a record of the bet attempt
    const betRecord = await storage.createAutomatedBet({
      userId: params.userId,
      exchangeProvider: params.exchangeProvider as BetExchangeProvider,
      betType: params.betType,
      marketId: params.marketId,
      selectionId: params.selectionId,
      stake: params.stake,
      requestedPrice: params.requestedPrice,
      betId: params.betId,
      status: 'pending',
      exchangeBetId: null,
      matchedPrice: null,
      errorMessage: null,
      executedAt: null
    });
    
    // Place the bet on the exchange
    const betResult = await placeBet(
      params.exchangeProvider as BetExchangeProvider,
      account.token,
      params
    );
    
    // Update the bet record with the result
    if (betResult.success) {
      await storage.updateAutomatedBet(betRecord.id, {
        status: 'executed',
        exchangeBetId: betResult.betId || null,
        matchedPrice: betResult.matchedPrice?.toString() || null,
        executedAt: new Date()
      });
      
      return { 
        success: true, 
        message: 'Bet executed successfully', 
        betId: betRecord.id 
      };
    } else {
      await storage.updateAutomatedBet(betRecord.id, {
        status: 'failed',
        errorMessage: betResult.error || 'Unknown error',
        executedAt: new Date()
      });
      
      return { 
        success: false, 
        message: betResult.error || 'Failed to execute bet', 
        betId: betRecord.id 
      };
    }
  } catch (error) {
    console.error('Error executing automated bet:', error);
    return { 
      success: false, 
      message: `Error executing bet: ${error instanceof Error ? error.message : 'Unknown error'}` 
    };
  }
}

/**
 * Find matching markets between our internal events and exchange markets
 * @param provider Betting exchange provider
 * @param token Authentication token
 * @param internalEventId Internal event ID
 * @returns Mapping between internal and exchange markets
 */
export async function findMatchingMarkets(
  provider: BetExchangeProvider,
  token: string,
  internalEventId: number
): Promise<{ success: boolean; mappings?: any[]; message?: string }> {
  try {
    // Get our internal event
    const event = await storage.getEvent(internalEventId);
    if (!event) {
      return { success: false, message: 'Internal event not found' };
    }
    
    // Search for matching events on the exchange
    // This is a simplified approach - in production, more sophisticated matching would be used
    const searchTerm = `${event.homeTeam} ${event.awayTeam}`;
    
    const config = exchangeConfigs[provider](token);
    
    switch (provider) {
      case 'betfair':
        // Search for events by name
        const response = await axios.post(
          `${config.baseUrl}/listEvents`,
          {
            filter: {
              textQuery: searchTerm
            }
          },
          { headers: config.headers }
        );
        
        if (response.data && response.data.length > 0) {
          // Return the potential mappings
          const mappings = response.data.map((exchangeEvent: any) => ({
            internalEventId,
            exchangeEventId: exchangeEvent.event.id,
            exchangeEventName: exchangeEvent.event.name,
            confidence: calculateMatchConfidence(event, exchangeEvent.event.name)
          }));
          
          return { success: true, mappings };
        }
        
        return { success: false, message: 'No matching events found on the exchange' };
        
      case 'pinnacle':
      case 'draftkings':
      case 'fanduel':
      case 'betmgm':
        // Mock implementation for other providers
        return { 
          success: true, 
          mappings: [
            {
              internalEventId,
              exchangeEventId: `mock-event-${provider}-1`,
              exchangeEventName: `${event.homeTeam} vs ${event.awayTeam}`,
              confidence: 0.9
            }
          ]
        };
        
      default:
        return { success: false, message: 'Unsupported betting exchange provider for market mapping' };
    }
  } catch (error) {
    console.error(`Error finding matching markets on ${provider}:`, error);
    return { 
      success: false, 
      message: `Error finding matching markets: ${error instanceof Error ? error.message : 'Unknown error'}` 
    };
  }
}

/**
 * Calculate a confidence score for event name matching
 * @param internalEvent Our internal event
 * @param exchangeEventName Event name from the exchange
 * @returns Confidence score (0-1)
 */
function calculateMatchConfidence(internalEvent: any, exchangeEventName: string): number {
  const internalName = `${internalEvent.homeTeam} vs ${internalEvent.awayTeam}`.toLowerCase();
  const exchangeName = exchangeEventName.toLowerCase();
  
  // Check if both team names are in the exchange event name
  const homeTeamIncluded = exchangeName.includes(internalEvent.homeTeam.toLowerCase());
  const awayTeamIncluded = exchangeName.includes(internalEvent.awayTeam.toLowerCase());
  
  if (homeTeamIncluded && awayTeamIncluded) {
    return 0.9; // High confidence if both teams are included
  } else if (homeTeamIncluded || awayTeamIncluded) {
    return 0.6; // Medium confidence if only one team is included
  }
  
  // Fallback to simple string similarity
  let similarity = 0;
  const words1 = internalName.split(/\s+/);
  const words2 = exchangeName.split(/\s+/);
  
  for (const word1 of words1) {
    if (word1.length <= 2) continue; // Skip short words
    if (words2.some(word2 => word2.includes(word1) || word1.includes(word2))) {
      similarity += 1;
    }
  }
  
  return Math.min(0.8, similarity / Math.max(words1.length, words2.length));
}
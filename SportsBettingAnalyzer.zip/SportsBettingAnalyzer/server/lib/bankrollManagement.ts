/**
 * Advanced Bankroll Management Strategies
 * 
 * This file contains various bankroll management algorithms:
 * 1. Kelly Criterion - Optimizes bet sizes based on edge and odds
 * 2. Fixed Unit - Simple flat betting approach with different unit sizes
 * 3. Percentage Model - Variable bet sizes based on bankroll percentage
 * 4. Confidence-Weighted - Adjusts bet sizes based on confidence level
 * 5. Proportional Betting - Adjusts bet sizes based on value identification
 */

/**
 * Kelly Criterion calculation
 * Optimizes bankroll growth by calculating ideal bet size based on odds and win probability
 * 
 * @param probability - Estimated win probability (0-1)
 * @param odds - American format odds (e.g., +150, -200)
 * @param bankroll - Total bankroll amount
 * @param fraction - Fraction of Kelly to use (0-1), default 0.25 (quarter Kelly)
 * @returns The recommended bet amount
 */
export function kellyFormula(
  probability: number,
  odds: number,
  bankroll: number,
  fraction: number = 0.25
): number {
  // Convert probability to 0-1 scale if needed
  if (probability > 1) {
    probability = probability / 100;
  }
  
  // Convert American odds to decimal odds
  let decimalOdds: number;
  if (odds > 0) {
    decimalOdds = (odds / 100) + 1;
  } else {
    decimalOdds = (100 / Math.abs(odds)) + 1;
  }
  
  // Calculate full Kelly stake
  const q = 1 - probability;
  const b = decimalOdds - 1; // The odds received minus 1
  
  // Kelly formula: f* = (bp - q) / b
  // where f* is the optimal fraction of the bankroll to bet
  const kellyPercentage = (b * probability - q) / b;
  
  // Apply fraction to reduce volatility (most pros use quarter or half Kelly)
  const adjustedKellyPercentage = Math.max(0, kellyPercentage * fraction);
  
  // Calculate bet amount and round to 2 decimal places
  return Math.round(bankroll * adjustedKellyPercentage * 100) / 100;
}

/**
 * Fixed Unit Betting
 * Simple approach where each bet is a fixed unit size
 * 
 * @param bankroll - Total bankroll amount
 * @param unitSizePercent - Unit size as a percentage of bankroll (default: 2%)
 * @param riskLevel - Risk level modifier ('low', 'medium', 'high')
 * @returns The recommended bet amount
 */
export function fixedUnitBetting(
  bankroll: number,
  unitSizePercent: number = 2,
  riskLevel: string = 'medium'
): number {
  // Adjust unit size based on risk level
  let riskMultiplier = 1;
  switch (riskLevel.toLowerCase()) {
    case 'low':
      riskMultiplier = 0.5;
      break;
    case 'medium':
      riskMultiplier = 1;
      break;
    case 'high':
      riskMultiplier = 2;
      break;
    default:
      riskMultiplier = 1;
  }
  
  // Calculate unit size with risk adjustment
  const effectiveUnitSizePercent = unitSizePercent * riskMultiplier;
  
  // Calculate bet amount and round to 2 decimal places
  return Math.round(bankroll * (effectiveUnitSizePercent / 100) * 100) / 100;
}

/**
 * Percentage Model
 * Bet a specified percentage of current bankroll
 * 
 * @param bankroll - Total bankroll amount
 * @param percentage - Percentage of bankroll to bet (default: 1%)
 * @param confidence - Confidence in the bet (1-10)
 * @returns The recommended bet amount
 */
export function percentageModel(
  bankroll: number,
  percentage: number = 1,
  confidence: number = 5
): number {
  // Adjust percentage based on confidence (scale from 0.5x to 2x)
  const confidenceMultiplier = 0.5 + (confidence / 10 * 1.5);
  
  // Calculate effective percentage
  const effectivePercentage = percentage * confidenceMultiplier;
  
  // Calculate bet amount and round to 2 decimal places
  return Math.round(bankroll * (effectivePercentage / 100) * 100) / 100;
}

/**
 * Confidence-Weighted Betting
 * Adjusts bet sizes based on confidence level
 * 
 * @param bankroll - Total bankroll amount
 * @param baseUnitPercent - Base unit size as percentage of bankroll (default: 1%)
 * @param confidence - Confidence score (1-10)
 * @returns The recommended bet amount
 */
export function confidenceWeightedBetting(
  bankroll: number,
  baseUnitPercent: number = 1,
  confidence: number = 5
): number {
  // Normalize confidence to 0-1 scale
  const normalizedConfidence = confidence / 10;
  
  // Exponential scaling to emphasize high confidence bets
  // Squared function gives more weight to higher confidence values
  const confidenceScale = normalizedConfidence * normalizedConfidence;
  
  // Calculate unit size with confidence weighting (up to 3x base for max confidence)
  const effectiveUnitPercent = baseUnitPercent * (1 + 2 * confidenceScale);
  
  // Calculate bet amount and round to 2 decimal places
  return Math.round(bankroll * (effectiveUnitPercent / 100) * 100) / 100;
}

/**
 * Proportional Betting (Value Betting)
 * Bet sizes proportional to perceived edge/value
 * 
 * @param bankroll - Total bankroll amount
 * @param fairOdds - Your calculated fair odds (decimal)
 * @param marketOdds - The market odds offered (decimal) 
 * @param baseUnitPercent - Base unit size as percentage of bankroll (default: 1%)
 * @returns The recommended bet amount or 0 if no edge exists
 */
export function proportionalValueBetting(
  bankroll: number,
  fairOdds: number,
  marketOdds: number,
  baseUnitPercent: number = 1
): number {
  // Calculate edge as a percentage
  const edge = (marketOdds / fairOdds) - 1;
  
  // Only bet if there's positive expected value
  if (edge <= 0) {
    return 0;
  }
  
  // Scale bet size based on the edge (cap at 3x base unit)
  const edgeMultiplier = Math.min(3, 1 + (edge * 10));
  
  // Calculate unit size with edge weighting
  const effectiveUnitPercent = baseUnitPercent * edgeMultiplier;
  
  // Calculate bet amount and round to 2 decimal places
  return Math.round(bankroll * (effectiveUnitPercent / 100) * 100) / 100;
}

/**
 * Dynamic Drawdown Protection System
 * Automatically reduces bet sizes after losses and gradually increases after wins
 * 
 * @param bankroll - Current bankroll amount
 * @param startingBankroll - Starting bankroll amount
 * @param baseUnitPercent - Base unit size as percentage of bankroll
 * @param recentResults - Array of recent bet results (1 for win, -1 for loss)
 * @returns The adjusted bet amount
 */
export function drawdownProtection(
  bankroll: number,
  startingBankroll: number,
  baseUnitPercent: number = 1,
  recentResults: number[] = []
): number {
  // Calculate drawdown as a percentage
  const drawdownPercent = Math.max(0, (startingBankroll - bankroll) / startingBankroll * 100);
  
  // Calculate recent form (sum of last 5 results, weighted toward more recent)
  const recentForm = recentResults.slice(-5).reduce((sum, result, index) => {
    const weight = 1 + (index * 0.2); // More recent results get higher weight
    return sum + (result * weight);
  }, 0);
  
  // Determine adjustment factor based on drawdown and form
  let adjustmentFactor = 1;
  
  // Significant drawdown protection (reduce sizing)
  if (drawdownPercent > 15) {
    adjustmentFactor = 0.5;
  } else if (drawdownPercent > 10) {
    adjustmentFactor = 0.75;
  } else if (drawdownPercent > 5) {
    adjustmentFactor = 0.9;
  }
  
  // Further adjust based on recent form
  if (recentForm < -3) {
    adjustmentFactor *= 0.8; // Further reduce if in bad form
  } else if (recentForm > 3) {
    adjustmentFactor *= 1.2; // Increase if in good form, but cap at 1.2x
  }
  
  // Calculate protected unit size
  const effectiveUnitPercent = baseUnitPercent * adjustmentFactor;
  
  // Calculate bet amount and round to 2 decimal places
  return Math.round(bankroll * (effectiveUnitPercent / 100) * 100) / 100;
}

/**
 * Calculate optimal bet size using multiple algorithms and weighting
 * 
 * @param bankroll - Total bankroll amount
 * @param riskLevel - User's risk tolerance ('low', 'medium', 'high')
 * @param confidence - Confidence in the bet (1-10)
 * @param winProbability - Estimated win probability (0-1)
 * @param odds - American format odds
 * @param startingBankroll - Starting bankroll amount
 * @param recentResults - Array of recent bet results (1 for win, -1 for loss)
 * @param unitSizePercent - Base unit size percentage
 * @returns The recommended bet amount and breakdown of how it was calculated
 */
export function calculateOptimalBetSize(
  bankroll: number,
  riskLevel: string = 'medium',
  confidence: number = 5,
  winProbability: number = 0.5,
  odds: number = -110,
  startingBankroll: number = bankroll,
  recentResults: number[] = [],
  unitSizePercent: number = 2
): { amount: number, breakdown: any } {
  // Calculate bet size using different algorithms
  const kellyAmount = kellyFormula(winProbability, odds, bankroll, 0.25);
  const fixedUnitAmount = fixedUnitBetting(bankroll, unitSizePercent, riskLevel);
  const percentageAmount = percentageModel(bankroll, unitSizePercent / 2, confidence);
  const confidenceAmount = confidenceWeightedBetting(bankroll, unitSizePercent / 2, confidence);
  
  // Calculate fair odds and market odds for proportional betting
  const fairImpliedProbability = winProbability;
  const fairOdds = 1 / fairImpliedProbability;
  
  // Convert American odds to decimal
  let marketOdds: number;
  if (odds > 0) {
    marketOdds = (odds / 100) + 1;
  } else {
    marketOdds = (100 / Math.abs(odds)) + 1;
  }
  
  const proportionalAmount = proportionalValueBetting(bankroll, fairOdds, marketOdds, unitSizePercent / 2);
  const drawdownAmount = drawdownProtection(bankroll, startingBankroll, unitSizePercent, recentResults);
  
  // Determine weights based on risk level
  let weights: { [key: string]: number } = {};
  
  switch (riskLevel.toLowerCase()) {
    case 'low':
      weights = {
        kelly: 0.1,
        fixedUnit: 0.3,
        percentage: 0.1,
        confidence: 0.2,
        proportional: 0.1,
        drawdown: 0.2
      };
      break;
    case 'medium':
      weights = {
        kelly: 0.2,
        fixedUnit: 0.2,
        percentage: 0.15,
        confidence: 0.2,
        proportional: 0.15,
        drawdown: 0.1
      };
      break;
    case 'high':
      weights = {
        kelly: 0.3,
        fixedUnit: 0.1,
        percentage: 0.15,
        confidence: 0.25,
        proportional: 0.15,
        drawdown: 0.05
      };
      break;
    default:
      weights = {
        kelly: 0.2,
        fixedUnit: 0.2,
        percentage: 0.15,
        confidence: 0.2,
        proportional: 0.15,
        drawdown: 0.1
      };
  }
  
  // Calculate weighted average bet size
  const weightedAmount = 
    (kellyAmount * weights.kelly) +
    (fixedUnitAmount * weights.fixedUnit) +
    (percentageAmount * weights.percentage) +
    (confidenceAmount * weights.confidence) +
    (proportionalAmount * weights.proportional) +
    (drawdownAmount * weights.drawdown);
  
  // Round to 2 decimal places
  const finalAmount = Math.round(weightedAmount * 100) / 100;
  
  // Create breakdown for explanation
  const breakdown = {
    algorithms: {
      kelly: {
        amount: kellyAmount,
        weight: weights.kelly,
        contribution: Math.round(kellyAmount * weights.kelly * 100) / 100
      },
      fixedUnit: {
        amount: fixedUnitAmount,
        weight: weights.fixedUnit,
        contribution: Math.round(fixedUnitAmount * weights.fixedUnit * 100) / 100
      },
      percentage: {
        amount: percentageAmount,
        weight: weights.percentage,
        contribution: Math.round(percentageAmount * weights.percentage * 100) / 100
      },
      confidence: {
        amount: confidenceAmount,
        weight: weights.confidence,
        contribution: Math.round(confidenceAmount * weights.confidence * 100) / 100
      },
      proportional: {
        amount: proportionalAmount,
        weight: weights.proportional,
        contribution: Math.round(proportionalAmount * weights.proportional * 100) / 100
      },
      drawdown: {
        amount: drawdownAmount,
        weight: weights.drawdown,
        contribution: Math.round(drawdownAmount * weights.drawdown * 100) / 100
      }
    },
    inputs: {
      bankroll,
      riskLevel,
      confidence,
      winProbability,
      odds,
      unitSizePercent
    },
    finalAmount
  };
  
  return { amount: finalAmount, breakdown };
}
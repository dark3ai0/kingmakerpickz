import { BettingRecommendation, InsertBettingRecommendation, SportsEvent } from "@shared/schema";
import { storage } from "../storage";
import { calculateImpliedProbability } from "./sportsData";

// Initialize sample betting recommendations
export async function initializeRecommendations() {
  try {
    const events = await storage.getEvents();
    
    // Generate recommendations for each event
    for (const event of events) {
      await generateRecommendations(event);
    }
    
    console.log("Sample recommendations initialized");
  } catch (error) {
    console.error("Error initializing recommendations:", error);
  }
}

// Generate recommendations for a specific event
export async function generateRecommendations(event: SportsEvent) {
  try {
    // Moneyline strategy
    if (event.homeMoneyline !== null && event.awayMoneyline !== null) {
      const homeImpliedProb = calculateImpliedProbability(event.homeMoneyline);
      const awayImpliedProb = calculateImpliedProbability(event.awayMoneyline);
      
      // Our "model" adjusts implied probabilities by a factor
      // In a real app, this would be based on sophisticated algorithms
      let homeOurProb, awayOurProb;
      let homePick = false, awayPick = false;
      
      if (event.sport === "NFL" && event.homeTeam === "Kansas City Chiefs") {
        homeOurProb = homeImpliedProb * 1.15; // We think Chiefs are 15% better than the odds suggest
        awayOurProb = awayImpliedProb * 0.9;
        homePick = true;
      } else if (event.sport === "NBA" && event.homeTeam === "Boston Celtics") {
        homeOurProb = homeImpliedProb * 1.05;
        awayOurProb = awayImpliedProb * 0.95;
        homePick = true;
      } else if (event.sport === "MLB" && event.homeTeam === "New York Yankees") {
        homeOurProb = homeImpliedProb * 0.95;
        awayOurProb = awayImpliedProb * 1.05;
        awayPick = true;
      } else {
        homeOurProb = homeImpliedProb * 1.0;
        awayOurProb = awayImpliedProb * 1.0;
      }
      
      // Create moneyline recommendation
      if (homePick) {
        await createMoneylineRecommendation(
          event.id, 
          "home", 
          event.homeMoneyline, 
          homeImpliedProb * 100, 
          homeOurProb * 100,
          event.sport
        );
      } else if (awayPick) {
        await createMoneylineRecommendation(
          event.id, 
          "away", 
          event.awayMoneyline, 
          awayImpliedProb * 100, 
          awayOurProb * 100,
          event.sport
        );
      }
    }
    
    // Spread strategy
    if (event.homeSpread !== null && event.homeSpreadOdds !== null) {
      let spreadPick = false;
      let spreadConfidence = 0;
      
      if (event.sport === "NBA" && event.homeTeam === "Boston Celtics") {
        // Our "model" predicts Boston to cover the spread
        spreadPick = true;
        spreadConfidence = 64;
      } else if (event.sport === "NFL" && event.awayTeam === "Baltimore Ravens") {
        // Our "model" predicts Ravens to cover
        spreadPick = false;
        spreadConfidence = 55;
      }
      
      if (spreadPick || spreadConfidence > 0) {
        const spreadOdds = spreadPick ? event.homeSpreadOdds : event.awaySpreadOdds;
        const impliedProb = calculateImpliedProbability(spreadOdds || -110) * 100;
        const ourProjection = spreadPick ? (event.homeSpread || 0) - 1.7 : (event.homeSpread || 0) + 1.2;
        
        await createSpreadRecommendation(
          event.id,
          spreadPick ? "home" : "away",
          spreadOdds || -110,
          impliedProb,
          spreadConfidence > 0 ? spreadConfidence : 52,
          event.homeSpread || 0,
          ourProjection,
          event.sport
        );
      }
    }
    
    // Over/Under strategy
    if (event.overUnder !== null && event.underOdds !== null) {
      let overUnderPick = "";
      let confidence = 0;
      let projectedTotal = 0;
      
      if (event.sport === "MLB" && event.homeTeam === "New York Yankees") {
        overUnderPick = "under";
        confidence = 82;
        projectedTotal = 7.2;
      } else if (event.sport === "NFL" && event.homeTeam === "Kansas City Chiefs") {
        overUnderPick = "over";
        confidence = 68;
        projectedTotal = 49.5;
      }
      
      if (overUnderPick && confidence > 0) {
        const odds = overUnderPick === "over" ? event.overOdds : event.underOdds;
        const impliedProb = calculateImpliedProbability(odds || -110) * 100;
        
        await createOverUnderRecommendation(
          event.id,
          overUnderPick,
          odds || -110,
          impliedProb,
          confidence,
          event.overUnder || 0,
          projectedTotal,
          event.sport
        );
      }
    }
    
    return true;
  } catch (error) {
    console.error("Error generating recommendations:", error);
    return false;
  }
}

// Helper functions to create recommendations
async function createMoneylineRecommendation(
  eventId: number,
  pick: string,
  odds: number,
  impliedProbability: number,
  ourProbability: number,
  sport: string
) {
  const confidence = Math.min(99, Math.max(50, Math.round(ourProbability)));
  
  let value = 'medium';
  if (confidence > 75) value = 'high';
  if (confidence < 60) value = 'low';
  
  const analysis = `${pick === 'home' ? 'Home' : 'Away'} team has a ${ourProbability.toFixed(1)}% chance to win according to our model.`;
  
  const recommendation: InsertBettingRecommendation = {
    eventId,
    strategy: 'moneyline',
    pick,
    odds,
    confidence,
    impliedProbability,
    ourProbability,
    value,
    analysis
  };
  
  // Check if we already have a moneyline recommendation for this event
  const existingRecs = await storage.getRecommendationsByEvent(eventId);
  const existingMoneyline = existingRecs.find(rec => rec.strategy === 'moneyline');
  
  if (!existingMoneyline) {
    await storage.createRecommendation(recommendation);
  }
}

async function createSpreadRecommendation(
  eventId: number,
  pick: string,
  odds: number,
  impliedProbability: number,
  confidence: number,
  marketLine: number,
  ourProjection: number,
  sport: string
) {
  let value = 'medium';
  if (confidence > 75) value = 'high';
  if (confidence < 60) value = 'low';
  
  const analysis = `Our model projects a ${Math.abs(marketLine - ourProjection).toFixed(1)} point difference from the market line.`;
  
  const recommendation: InsertBettingRecommendation = {
    eventId,
    strategy: 'spread',
    pick,
    odds,
    confidence,
    impliedProbability,
    ourProbability: confidence,
    value,
    analysis
  };
  
  // Check if we already have a spread recommendation for this event
  const existingRecs = await storage.getRecommendationsByEvent(eventId);
  const existingSpread = existingRecs.find(rec => rec.strategy === 'spread');
  
  if (!existingSpread) {
    await storage.createRecommendation(recommendation);
  }
}

async function createOverUnderRecommendation(
  eventId: number,
  pick: string,
  odds: number,
  impliedProbability: number,
  confidence: number,
  marketTotal: number,
  ourProjection: number,
  sport: string
) {
  let value = 'medium';
  if (confidence > 75) value = 'high';
  if (confidence < 60) value = 'low';
  
  const analysis = `Our model projects ${ourProjection} total points compared to the market total of ${marketTotal}.`;
  
  const recommendation: InsertBettingRecommendation = {
    eventId,
    strategy: 'overUnder',
    pick,
    odds,
    confidence,
    impliedProbability,
    ourProbability: confidence,
    value,
    analysis
  };
  
  // Check if we already have an over/under recommendation for this event
  const existingRecs = await storage.getRecommendationsByEvent(eventId);
  const existingOverUnder = existingRecs.find(rec => rec.strategy === 'overUnder');
  
  if (!existingOverUnder) {
    await storage.createRecommendation(recommendation);
  }
}

// Generate performance data for a user
export async function generatePerformance(userId: number) {
  try {
    // Create sample performance data
    await storage.createPerformance({
      userId,
      period: "month",
      totalBets: 24,
      winBets: 14,
      lossBets: 10,
      pushBets: 0,
      profitLoss: 432.10,
      roi: 12.4,
      moneylineWinRate: 62.5,
      spreadWinRate: 55.6,
      overUnderWinRate: 80.0,
      updatedAt: new Date()
    });
    
    console.log("Sample performance data generated");
    return true;
  } catch (error) {
    console.error("Error generating performance data:", error);
    return false;
  }
}

import { SportsEvent, InsertSportsEvent } from "@shared/schema";
import { storage } from "../storage";
import axios from "axios";

// Initialize sample data for MVP
export async function initializeSampleData() {
  try {
    // Sample NFL Events
    await storage.createEvent({
      sport: "NFL",
      league: "NFL",
      homeTeam: "Kansas City Chiefs",
      awayTeam: "Baltimore Ravens",
      startTime: new Date(Date.now() + 8 * 60 * 60 * 1000), // 8 hours from now
      homeMoneyline: -135,
      awayMoneyline: 115,
      homeSpread: -3,
      homeSpreadOdds: -110,
      awaySpreadOdds: -110,
      overUnder: 47.5,
      overOdds: -110,
      underOdds: -110,
      status: "scheduled"
    });

    // Sample NBA Events
    await storage.createEvent({
      sport: "NBA",
      league: "NBA",
      homeTeam: "Boston Celtics",
      awayTeam: "Miami Heat",
      startTime: new Date(Date.now() + 7.5 * 60 * 60 * 1000), // 7.5 hours from now
      homeMoneyline: -180,
      awayMoneyline: 150,
      homeSpread: -4.5,
      homeSpreadOdds: -110,
      awaySpreadOdds: -110,
      overUnder: 218.5,
      overOdds: -110,
      underOdds: -110,
      status: "scheduled"
    });

    // Sample MLB Events
    await storage.createEvent({
      sport: "MLB",
      league: "MLB",
      homeTeam: "New York Yankees",
      awayTeam: "Boston Red Sox",
      startTime: new Date(Date.now() + 1 * 60 * 60 * 1000), // 1 hour from now
      homeMoneyline: -125,
      awayMoneyline: 105,
      homeSpread: -1.5,
      homeSpreadOdds: 125,
      awaySpreadOdds: -145,
      overUnder: 8.5,
      overOdds: -115,
      underOdds: -105,
      status: "scheduled"
    });

    // Sample NBA Events - Tomorrow
    await storage.createEvent({
      sport: "NBA",
      league: "NBA",
      homeTeam: "Denver Nuggets",
      awayTeam: "Los Angeles Lakers",
      startTime: new Date(Date.now() + 34 * 60 * 60 * 1000), // Tomorrow
      homeMoneyline: -195,
      awayMoneyline: 165,
      homeSpread: -5,
      homeSpreadOdds: -110,
      awaySpreadOdds: -110,
      overUnder: 224.5,
      overOdds: -110,
      underOdds: -110,
      status: "scheduled"
    });

    console.log("Sample sports data initialized");
  } catch (error) {
    console.error("Error initializing sample data:", error);
  }
}

// For a real implementation, this would connect to a sports data API
export async function fetchSportsData(sport: string) {
  // In a real implementation, we would fetch from a sports data API
  // For this MVP, we'll use the sample data
  try {
    return await storage.getEvents(sport);
  } catch (error) {
    console.error(`Error fetching ${sport} data:`, error);
    throw error;
  }
}

// Calculate implied probability from American odds
export function calculateImpliedProbability(odds: number): number {
  if (odds > 0) {
    return 100 / (odds + 100);
  } else {
    return Math.abs(odds) / (Math.abs(odds) + 100);
  }
}

// In a real implementation, this would update odds from a sports data API
export async function updateOdds() {
  try {
    // Simulate odds movement for demo purposes
    const events = await storage.getEvents();
    
    for (const event of events) {
      // Random small changes to odds
      const homeMoneylineChange = Math.random() > 0.5 ? Math.floor(Math.random() * 5) + 1 : -(Math.floor(Math.random() * 5) + 1);
      const awayMoneylineChange = -homeMoneylineChange;
      
      if (event.homeMoneyline) {
        await storage.updateEvent(event.id, {
          homeMoneyline: event.homeMoneyline + homeMoneylineChange,
          awayMoneyline: event.awayMoneyline ? event.awayMoneyline + awayMoneylineChange : undefined
        });
      }
    }
    
    return true;
  } catch (error) {
    console.error("Error updating odds:", error);
    return false;
  }
}

import { pgTable, text, serial, integer, boolean, timestamp, real, numeric, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User Schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  bankroll: numeric("bankroll").notNull().default("1000.00"),
  riskLevel: text("risk_level").notNull().default("moderate"),
  unitSizePercent: real("unit_size_percent").notNull().default(2),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  bankroll: true,
  riskLevel: true,
  unitSizePercent: true,
});

// Sports Schema
export const sports = pgTable("sports", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  enabled: boolean("enabled").notNull().default(true),
});

export const insertSportSchema = createInsertSchema(sports).pick({
  name: true,
  enabled: true,
});

// Events Schema (Games)
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  sportId: integer("sport_id").notNull(),
  homeTeam: text("home_team").notNull(),
  awayTeam: text("away_team").notNull(),
  startTime: timestamp("start_time").notNull(),
  location: text("location"),
  status: text("status").notNull().default("scheduled"), // scheduled, live, final, cancelled
  homeScore: integer("home_score"),
  awayScore: integer("away_score"),
  externalId: text("external_id").unique(), // ID from the external API
});

export const insertEventSchema = createInsertSchema(events).pick({
  sportId: true,
  homeTeam: true,
  awayTeam: true,
  startTime: true,
  location: true,
  status: true,
  externalId: true,
});

// Odds Schema
export const odds = pgTable("odds", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").notNull(),
  moneylineHome: integer("moneyline_home"),
  moneylineAway: integer("moneyline_away"),
  spreadHome: real("spread_home"),
  spreadHomeOdds: integer("spread_home_odds"),
  spreadAway: real("spread_away"),
  spreadAwayOdds: integer("spread_away_odds"),
  totalPoints: real("total_points"),
  totalOverOdds: integer("total_over_odds"),
  totalUnderOdds: integer("total_under_odds"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertOddsSchema = createInsertSchema(odds).pick({
  eventId: true,
  moneylineHome: true,
  moneylineAway: true,
  spreadHome: true,
  spreadHomeOdds: true,
  spreadAway: true,
  spreadAwayOdds: true,
  totalPoints: true,
  totalOverOdds: true,
  totalUnderOdds: true,
});

// Strategy Recommendations Schema
export const recommendations = pgTable("recommendations", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").notNull(),
  strategyType: text("strategy_type").notNull(), // moneyline, spread, total
  recommendation: text("recommendation").notNull(), // team or over/under
  odds: integer("odds").notNull(),
  confidence: real("confidence").notNull(),
  value: real("value").notNull(),
  reasoning: text("reasoning"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertRecommendationSchema = createInsertSchema(recommendations).pick({
  eventId: true,
  strategyType: true,
  recommendation: true,
  odds: true,
  confidence: true,
  value: true,
  reasoning: true,
});

// Bets Schema
export const bets = pgTable("bets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  recommendationId: integer("recommendation_id").notNull(),
  amount: numeric("amount").notNull(),
  placedOdds: integer("placed_odds").notNull(),
  potentialWin: numeric("potential_win").notNull(),
  status: text("status").notNull().default("pending"), // pending, won, lost, pushed, void
  settled: boolean("settled").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  settledAt: timestamp("settled_at"),
});

export const insertBetSchema = createInsertSchema(bets).pick({
  userId: true,
  recommendationId: true,
  amount: true,
  placedOdds: true,
  potentialWin: true,
});

// User Preferences Schema
export const userPreferences = pgTable("user_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique(),
  enabledSports: jsonb("enabled_sports").notNull().default([]),
  enabledStrategies: jsonb("enabled_strategies").notNull().default([]),
  minimumConfidence: real("minimum_confidence").notNull().default(60),
  notificationsEnabled: boolean("notifications_enabled").notNull().default(true),
  cryptoEnabled: boolean("crypto_enabled").notNull().default(false),
  preferredCurrency: text("preferred_currency").default("USD"),
  dashboardLayout: jsonb("dashboard_layout").default([]),
});

export const insertUserPreferenceSchema = createInsertSchema(userPreferences).pick({
  userId: true,
  enabledSports: true,
  enabledStrategies: true,
  minimumConfidence: true,
  notificationsEnabled: true,
  cryptoEnabled: true,
  preferredCurrency: true,
  dashboardLayout: true,
});

// Crypto Wallet Schema
export const cryptoWallets = pgTable("crypto_wallets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  currency: text("currency").notNull(), // BTC, ETH, etc.
  address: text("address").notNull(),
  balance: numeric("balance").notNull().default("0"),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const insertCryptoWalletSchema = createInsertSchema(cryptoWallets).pick({
  userId: true,
  currency: true,
  address: true,
  balance: true,
});

// AI Analysis Schema
export const aiAnalyses = pgTable("ai_analyses", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id"),
  userId: integer("user_id").notNull(),
  query: text("query").notNull(),
  response: text("response").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  analysisType: text("analysis_type").notNull(), // event, strategy, crypto, etc.
});

export const insertAiAnalysisSchema = createInsertSchema(aiAnalyses).pick({
  eventId: true,
  userId: true,
  query: true,
  response: true,
  analysisType: true,
});

// Custom Dashboard Widget Schema
export const dashboardWidgets = pgTable("dashboard_widgets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  widgetType: text("widget_type").notNull(), // strategy, event, crypto, performance, etc.
  title: text("title").notNull(),
  configuration: jsonb("configuration").default({}),
  position: integer("position").notNull(),
  enabled: boolean("enabled").notNull().default(true),
});

export const insertDashboardWidgetSchema = createInsertSchema(dashboardWidgets).pick({
  userId: true,
  widgetType: true,
  title: true,
  configuration: true,
  position: true,
  enabled: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Sport = typeof sports.$inferSelect;
export type InsertSport = z.infer<typeof insertSportSchema>;

export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;

export type Odds = typeof odds.$inferSelect;
export type InsertOdds = z.infer<typeof insertOddsSchema>;

export type Recommendation = typeof recommendations.$inferSelect;
export type InsertRecommendation = z.infer<typeof insertRecommendationSchema>;

export type Bet = typeof bets.$inferSelect;
export type InsertBet = z.infer<typeof insertBetSchema>;

export type UserPreference = typeof userPreferences.$inferSelect;
export type InsertUserPreference = z.infer<typeof insertUserPreferenceSchema>;

export type CryptoWallet = typeof cryptoWallets.$inferSelect;
export type InsertCryptoWallet = z.infer<typeof insertCryptoWalletSchema>;

export type AiAnalysis = typeof aiAnalyses.$inferSelect;
export type InsertAiAnalysis = z.infer<typeof insertAiAnalysisSchema>;

export type DashboardWidget = typeof dashboardWidgets.$inferSelect;
export type InsertDashboardWidget = z.infer<typeof insertDashboardWidgetSchema>;

// Extended types for frontend
export type EventWithOdds = Event & {
  odds?: Odds;
};

export type RecommendationWithEvent = Recommendation & {
  event: EventWithOdds;
};

export type BetWithDetails = Bet & {
  recommendation: RecommendationWithEvent;
};

export type CryptoWalletWithDetails = CryptoWallet & {
  marketValue?: number;
  dailyChange?: number;
};

export type WidgetWithData = DashboardWidget & {
  data?: any;
};

// Betting Exchange Types
export type BetExchangeProvider = 'betfair' | 'pinnacle' | 'draftkings' | 'fanduel' | 'betmgm';

export interface ExchangeMarketSelection {
  selectionId: string;
  name: string;
  price: number;
  available: boolean;
}

export interface ExchangeMarket {
  marketId: string;
  marketType: string;
  selections: ExchangeMarketSelection[];
}

export interface ExchangeOdds {
  eventId: string;
  provider: BetExchangeProvider;
  timestamp: Date;
  markets: ExchangeMarket[];
}

export interface PlaceBetRequest {
  provider: BetExchangeProvider;
  eventId: string;
  marketId: string;
  selectionId: string;
  betType: 'back' | 'lay'; // back = betting on outcome, lay = betting against outcome
  stake: number;
  price: number;
  persistenceType?: 'LAPSE' | 'PERSIST'; // What happens to the bet if unmatched at in-play
}

export interface PlaceBetResponse {
  betId: string;
  status: 'success' | 'failed' | 'pending';
  placedAt: Date;
  message: string;
}

// Betting Exchange Account Schema
export const betExchangeAccounts = pgTable("bet_exchange_accounts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  provider: text("provider").notNull(), // betfair, pinnacle, etc.
  username: text("username").notNull(),
  token: text("token").notNull(), // encrypted token or session ID
  active: boolean("active").notNull().default(true),
  lastAuthenticated: timestamp("last_authenticated").notNull().defaultNow(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertBetExchangeAccountSchema = createInsertSchema(betExchangeAccounts).pick({
  userId: true,
  provider: true,
  username: true,
  token: true,
  active: true,
});

// Automated Bet Execution Schema
export const automatedBets = pgTable("automated_bets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  betId: integer("bet_id"), // Linked to internal bet
  exchangeProvider: text("exchange_provider").notNull(),
  exchangeBetId: text("exchange_bet_id"),
  marketId: text("market_id").notNull(),
  selectionId: text("selection_id").notNull(),
  betType: text("bet_type").notNull(), // back, lay
  stake: numeric("stake").notNull(),
  requestedPrice: numeric("requested_price").notNull(),
  matchedPrice: numeric("matched_price"),
  status: text("status").notNull().default("pending"), // pending, placed, matched, canceled, error
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  executedAt: timestamp("executed_at"),
});

export const insertAutomatedBetSchema = createInsertSchema(automatedBets).pick({
  userId: true,
  betId: true,
  exchangeProvider: true,
  marketId: true,
  selectionId: true,
  betType: true,
  stake: true,
  requestedPrice: true,
  status: true,
  exchangeBetId: true,
  matchedPrice: true,
  errorMessage: true,
  executedAt: true,
});

// Exchange Event Mapping Schema (maps our internal event IDs to exchange event IDs)
export const exchangeEventMappings = pgTable("exchange_event_mappings", {
  id: serial("id").primaryKey(),
  internalEventId: integer("internal_event_id").notNull(),
  provider: text("provider").notNull(),
  exchangeEventId: text("exchange_event_id").notNull(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const insertExchangeEventMappingSchema = createInsertSchema(exchangeEventMappings).pick({
  internalEventId: true,
  provider: true,
  exchangeEventId: true,
});

// New types for betting exchange
export type BetExchangeAccount = typeof betExchangeAccounts.$inferSelect;
export type InsertBetExchangeAccount = z.infer<typeof insertBetExchangeAccountSchema>;

export type AutomatedBet = typeof automatedBets.$inferSelect;
export type InsertAutomatedBet = z.infer<typeof insertAutomatedBetSchema>;

export type ExchangeEventMapping = typeof exchangeEventMappings.$inferSelect;
export type InsertExchangeEventMapping = z.infer<typeof insertExchangeEventMappingSchema>;

export type AutomatedBetWithDetails = AutomatedBet & {
  internalBet?: Bet;
  exchangeDetails?: {
    eventName: string;
    marketName: string;
    selectionName: string;
  };
};

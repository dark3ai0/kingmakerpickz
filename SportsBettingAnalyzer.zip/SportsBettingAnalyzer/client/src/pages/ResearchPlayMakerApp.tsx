import { useState, useEffect } from 'react';
import RetroDesktop from '@/components/ui/retro/RetroDesktop';
import RetroWindow from '@/components/ui/retro/RetroWindow';
import StrategyCard from '@/components/dashboard/StrategyCard';
import UpcomingEvents from '@/components/dashboard/UpcomingEvents';
import BankrollCard from '@/components/dashboard/BankrollCard';
import PerformanceCard from '@/components/dashboard/PerformanceCard';
import GeniusAnalysisCard from '@/components/dashboard/GeniusAnalysisCard';
import CryptoWalletCard from '@/components/dashboard/CryptoWalletCard';
import SelfLearningModelCard from '@/components/dashboard/SelfLearningModelCard';
import { useSportsData } from '@/hooks/useSportsData';
import { 
  Bot, 
  Activity, 
  DollarSign, 
  Calendar, 
  Coins, 
  BarChart, 
  Brain, 
  Sparkles,
  Zap,
  Database,
  LineChart
} from 'lucide-react';

export default function ResearchPlayMakerApp() {
  const { 
    topRecommendations, 
    upcomingEvents, 
    isLoading, 
    refreshData, 
    generateRecommendations 
  } = useSportsData();
  
  const [windows, setWindows] = useState([
    { id: 'genius', title: 'Genius Answer Bot', isOpen: true, isMinimized: false, zIndex: 1, width: 600, height: 500, position: { x: 50, y: 50 } },
    { id: 'strategy', title: 'Strategy Analysis', isOpen: true, isMinimized: false, zIndex: 2, width: 400, height: 300, position: { x: 100, y: 150 } },
    { id: 'events', title: 'Upcoming Events', isOpen: true, isMinimized: false, zIndex: 3, width: 700, height: 400, position: { x: 150, y: 250 } },
    { id: 'bankroll', title: 'Bankroll Manager', isOpen: false, isMinimized: false, zIndex: 4, width: 400, height: 350, position: { x: 200, y: 200 } },
    { id: 'performance', title: 'Performance Tracker', isOpen: false, isMinimized: false, zIndex: 5, width: 500, height: 400, position: { x: 250, y: 150 } },
    { id: 'crypto', title: 'Crypto Wallets', isOpen: false, isMinimized: false, zIndex: 6, width: 500, height: 400, position: { x: 300, y: 100 } },
    { id: 'aimodel', title: 'AI Prediction Model', isOpen: false, isMinimized: false, zIndex: 7, width: 700, height: 550, position: { x: 120, y: 80 } },
    { id: 'research', title: 'Research Center', isOpen: false, isMinimized: false, zIndex: 8, width: 650, height: 500, position: { x: 180, y: 120 } },
    { id: 'datalab', title: 'Data Lab', isOpen: false, isMinimized: false, zIndex: 9, width: 600, height: 450, position: { x: 220, y: 180 } },
  ]);
  
  const [activeWindowId, setActiveWindowId] = useState('genius');
  
  // Automatically refresh data on component mount
  useEffect(() => {
    refreshData();
    
    // Set up polling interval
    const refreshInterval = setInterval(() => {
      refreshData();
    }, 60000); // Refresh every minute
    
    return () => clearInterval(refreshInterval);
  }, [refreshData]);
  
  const handleWindowClose = (id: string) => {
    setWindows(windows.map(window => 
      window.id === id 
        ? { ...window, isOpen: false } 
        : window
    ));
  };
  
  const handleWindowMinimize = (id: string) => {
    setWindows(windows.map(window => 
      window.id === id 
        ? { ...window, isMinimized: true } 
        : window
    ));
  };
  
  const handleWindowMaximize = (id: string) => {
    // This is handled inside the RetroWindow component itself
  };
  
  const handleWindowActivate = (id: string) => {
    if (id === activeWindowId) return;
    
    // Find current max zIndex
    const maxZIndex = Math.max(...windows.map(w => w.zIndex));
    
    setActiveWindowId(id);
    setWindows(windows.map(window => 
      window.id === id 
        ? { ...window, zIndex: maxZIndex + 1 } 
        : window
    ));
  };
  
  const handleTaskbarClick = (id: string) => {
    const windowToToggle = windows.find(w => w.id === id);
    
    if (!windowToToggle) return;
    
    if (windowToToggle.isOpen && !windowToToggle.isMinimized) {
      // Window is already open and not minimized, just activate it
      handleWindowActivate(id);
    } else if (windowToToggle.isOpen && windowToToggle.isMinimized) {
      // Window is open but minimized, restore it
      setWindows(windows.map(window => 
        window.id === id 
          ? { ...window, isMinimized: false } 
          : window
      ));
      handleWindowActivate(id);
    } else {
      // Window is closed, open it
      setWindows(windows.map(window => 
        window.id === id 
          ? { ...window, isOpen: true, isMinimized: false } 
          : window
      ));
      handleWindowActivate(id);
    }
  };
  
  // Desktop Icons
  const DesktopIcons = () => (
    <div className="grid grid-cols-3 gap-8 p-4">
      {windows.map((window) => (
        <button 
          key={window.id}
          className="flex flex-col items-center justify-center text-white"
          onClick={() => handleTaskbarClick(window.id)}
        >
          <div className={`${getIconBgColor(window.id)} w-12 h-12 flex items-center justify-center rounded-sm mb-1 border-2 border-gray-300 shadow-[2px_2px_0px_0px_rgba(0,0,0,0.8)]`}>
            {window.id === 'genius' && <Bot size={24} />}
            {window.id === 'strategy' && <Activity size={24} />}
            {window.id === 'events' && <Calendar size={24} />}
            {window.id === 'bankroll' && <DollarSign size={24} />}
            {window.id === 'performance' && <BarChart size={24} />}
            {window.id === 'crypto' && <Coins size={24} />}
            {window.id === 'aimodel' && <Brain size={24} />}
            {window.id === 'research' && <Sparkles size={24} />}
            {window.id === 'datalab' && <Database size={24} />}
          </div>
          <span className="text-xs font-pixel bg-blue-900 bg-opacity-70 px-1">{window.title}</span>
        </button>
      ))}
    </div>
  );
  
  const getIconBgColor = (id: string) => {
    switch(id) {
      case 'aimodel':
        return 'bg-gradient-to-br from-purple-600 to-cyan-500';
      case 'research':
        return 'bg-gradient-to-br from-green-500 to-blue-600';
      case 'datalab':
        return 'bg-gradient-to-br from-amber-500 to-red-500';
      default:
        return 'bg-blue-700';
    }
  };
  
  return (
    <RetroDesktop>
      <DesktopIcons />
      
      {/* Genius Answer Bot Window */}
      {windows.find(w => w.id === 'genius')?.isOpen && !windows.find(w => w.id === 'genius')?.isMinimized && (
        <RetroWindow
          title="Genius Answer Bot v1.0"
          width={windows.find(w => w.id === 'genius')?.width}
          height={windows.find(w => w.id === 'genius')?.height}
          initialPosition={windows.find(w => w.id === 'genius')?.position}
          zIndex={windows.find(w => w.id === 'genius')?.zIndex}
          onClose={() => handleWindowClose('genius')}
          onMinimize={() => handleWindowMinimize('genius')}
          onMaximize={() => handleWindowMaximize('genius')}
          isActive={activeWindowId === 'genius'}
          onActivate={() => handleWindowActivate('genius')}
        >
          <GeniusAnalysisCard />
        </RetroWindow>
      )}
      
      {/* Strategy Analysis Window */}
      {windows.find(w => w.id === 'strategy')?.isOpen && !windows.find(w => w.id === 'strategy')?.isMinimized && (
        <RetroWindow
          title="Strategy Analysis v2.1"
          width={windows.find(w => w.id === 'strategy')?.width}
          height={windows.find(w => w.id === 'strategy')?.height}
          initialPosition={windows.find(w => w.id === 'strategy')?.position}
          zIndex={windows.find(w => w.id === 'strategy')?.zIndex}
          onClose={() => handleWindowClose('strategy')}
          onMinimize={() => handleWindowMinimize('strategy')}
          onMaximize={() => handleWindowMaximize('strategy')}
          isActive={activeWindowId === 'strategy'}
          onActivate={() => handleWindowActivate('strategy')}
        >
          <div className="p-2 h-full overflow-auto">
            <h3 className="font-pixel text-sm mb-4">Top Strategy Recommendations</h3>
            {isLoading ? (
              <div className="animate-pulse space-y-4">
                <div className="h-24 bg-gray-300 rounded"></div>
                <div className="h-24 bg-gray-300 rounded"></div>
              </div>
            ) : (
              <div className="space-y-2">
                {(topRecommendations || []).slice(0, 3).map((recommendation: any) => (
                  <div key={recommendation.id} className="border border-gray-400 p-2 rounded bg-white">
                    <StrategyCard recommendation={recommendation} />
                  </div>
                ))}
              </div>
            )}
          </div>
        </RetroWindow>
      )}
      
      {/* Upcoming Events Window */}
      {windows.find(w => w.id === 'events')?.isOpen && !windows.find(w => w.id === 'events')?.isMinimized && (
        <RetroWindow
          title="Events Browser v1.2"
          width={windows.find(w => w.id === 'events')?.width}
          height={windows.find(w => w.id === 'events')?.height}
          initialPosition={windows.find(w => w.id === 'events')?.position}
          zIndex={windows.find(w => w.id === 'events')?.zIndex}
          onClose={() => handleWindowClose('events')}
          onMinimize={() => handleWindowMinimize('events')}
          onMaximize={() => handleWindowMaximize('events')}
          isActive={activeWindowId === 'events'}
          onActivate={() => handleWindowActivate('events')}
        >
          <div className="p-2 h-full overflow-auto">
            <h3 className="font-pixel text-sm mb-4">Upcoming Betting Opportunities</h3>
            <UpcomingEvents events={upcomingEvents || []} loading={isLoading} />
          </div>
        </RetroWindow>
      )}
      
      {/* Bankroll Manager Window */}
      {windows.find(w => w.id === 'bankroll')?.isOpen && !windows.find(w => w.id === 'bankroll')?.isMinimized && (
        <RetroWindow
          title="Bankroll Manager v1.0"
          width={windows.find(w => w.id === 'bankroll')?.width}
          height={windows.find(w => w.id === 'bankroll')?.height}
          initialPosition={windows.find(w => w.id === 'bankroll')?.position}
          zIndex={windows.find(w => w.id === 'bankroll')?.zIndex}
          onClose={() => handleWindowClose('bankroll')}
          onMinimize={() => handleWindowMinimize('bankroll')}
          onMaximize={() => handleWindowMaximize('bankroll')}
          isActive={activeWindowId === 'bankroll'}
          onActivate={() => handleWindowActivate('bankroll')}
        >
          <BankrollCard />
        </RetroWindow>
      )}
      
      {/* Performance Tracker Window */}
      {windows.find(w => w.id === 'performance')?.isOpen && !windows.find(w => w.id === 'performance')?.isMinimized && (
        <RetroWindow
          title="Performance Tracker v3.2"
          width={windows.find(w => w.id === 'performance')?.width}
          height={windows.find(w => w.id === 'performance')?.height}
          initialPosition={windows.find(w => w.id === 'performance')?.position}
          zIndex={windows.find(w => w.id === 'performance')?.zIndex}
          onClose={() => handleWindowClose('performance')}
          onMinimize={() => handleWindowMinimize('performance')}
          onMaximize={() => handleWindowMaximize('performance')}
          isActive={activeWindowId === 'performance'}
          onActivate={() => handleWindowActivate('performance')}
        >
          <PerformanceCard />
        </RetroWindow>
      )}
      
      {/* Crypto Wallets Window */}
      {windows.find(w => w.id === 'crypto')?.isOpen && !windows.find(w => w.id === 'crypto')?.isMinimized && (
        <RetroWindow
          title="Crypto Wallet v2.5"
          width={windows.find(w => w.id === 'crypto')?.width}
          height={windows.find(w => w.id === 'crypto')?.height}
          initialPosition={windows.find(w => w.id === 'crypto')?.position}
          zIndex={windows.find(w => w.id === 'crypto')?.zIndex}
          onClose={() => handleWindowClose('crypto')}
          onMinimize={() => handleWindowMinimize('crypto')}
          onMaximize={() => handleWindowMaximize('crypto')}
          isActive={activeWindowId === 'crypto'}
          onActivate={() => handleWindowActivate('crypto')}
        >
          <CryptoWalletCard />
        </RetroWindow>
      )}
      
      {/* AI Prediction Model Window */}
      {windows.find(w => w.id === 'aimodel')?.isOpen && !windows.find(w => w.id === 'aimodel')?.isMinimized && (
        <RetroWindow
          title="AI Prediction Model v3.0"
          width={windows.find(w => w.id === 'aimodel')?.width}
          height={windows.find(w => w.id === 'aimodel')?.height}
          initialPosition={windows.find(w => w.id === 'aimodel')?.position}
          zIndex={windows.find(w => w.id === 'aimodel')?.zIndex}
          onClose={() => handleWindowClose('aimodel')}
          onMinimize={() => handleWindowMinimize('aimodel')}
          onMaximize={() => handleWindowMaximize('aimodel')}
          isActive={activeWindowId === 'aimodel'}
          onActivate={() => handleWindowActivate('aimodel')}
        >
          <SelfLearningModelCard />
        </RetroWindow>
      )}
      
      {/* Research Center Window */}
      {windows.find(w => w.id === 'research')?.isOpen && !windows.find(w => w.id === 'research')?.isMinimized && (
        <RetroWindow
          title="Research Center v2.1"
          width={windows.find(w => w.id === 'research')?.width}
          height={windows.find(w => w.id === 'research')?.height}
          initialPosition={windows.find(w => w.id === 'research')?.position}
          zIndex={windows.find(w => w.id === 'research')?.zIndex}
          onClose={() => handleWindowClose('research')}
          onMinimize={() => handleWindowMinimize('research')}
          onMaximize={() => handleWindowMaximize('research')}
          isActive={activeWindowId === 'research'}
          onActivate={() => handleWindowActivate('research')}
        >
          <div className="p-2 h-full overflow-auto">
            <h3 className="font-pixel text-sm mb-4">Research Center</h3>
            <div className="border border-gray-500 p-3 mb-3 bg-white">
              <h4 className="font-bold mb-2 text-blue-800">Advanced Sports Analysis</h4>
              <p className="text-sm mb-2">Access deep statistical insights and AI-powered strategy recommendations.</p>
              <div className="flex space-x-2 mt-3">
                <button className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs py-1 px-2 rounded">
                  Generate Analysis
                </button>
                <button className="bg-gray-200 hover:bg-gray-300 text-xs py-1 px-2 rounded">
                  Historical Data
                </button>
              </div>
            </div>
            
            <div className="border border-gray-500 p-3 mb-3 bg-white">
              <h4 className="font-bold mb-2 text-purple-800">Injury Impact Predictor</h4>
              <p className="text-sm mb-2">Calculate how team injuries will affect performance and betting odds.</p>
              <div className="flex space-x-2 mt-3">
                <button className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white text-xs py-1 px-2 rounded">
                  Run Prediction
                </button>
                <button className="bg-gray-200 hover:bg-gray-300 text-xs py-1 px-2 rounded">
                  View Reports
                </button>
              </div>
            </div>
            
            <div className="border border-gray-500 p-3 bg-white">
              <h4 className="font-bold mb-2 text-green-800">Expert Consensus Tracker</h4>
              <p className="text-sm mb-2">Track and analyze predictions from experts across multiple platforms.</p>
              <div className="flex space-x-2 mt-3">
                <button className="bg-gradient-to-r from-green-500 to-teal-600 text-white text-xs py-1 px-2 rounded">
                  Update Data
                </button>
                <button className="bg-gray-200 hover:bg-gray-300 text-xs py-1 px-2 rounded">
                  Compare Sources
                </button>
              </div>
            </div>
          </div>
        </RetroWindow>
      )}
      
      {/* Data Lab Window */}
      {windows.find(w => w.id === 'datalab')?.isOpen && !windows.find(w => w.id === 'datalab')?.isMinimized && (
        <RetroWindow
          title="Data Lab v1.5"
          width={windows.find(w => w.id === 'datalab')?.width}
          height={windows.find(w => w.id === 'datalab')?.height}
          initialPosition={windows.find(w => w.id === 'datalab')?.position}
          zIndex={windows.find(w => w.id === 'datalab')?.zIndex}
          onClose={() => handleWindowClose('datalab')}
          onMinimize={() => handleWindowMinimize('datalab')}
          onMaximize={() => handleWindowMaximize('datalab')}
          isActive={activeWindowId === 'datalab'}
          onActivate={() => handleWindowActivate('datalab')}
        >
          <div className="p-2 h-full overflow-auto">
            <h3 className="font-pixel text-sm mb-4">Advanced Data Laboratory</h3>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div className="border border-gray-500 p-2 bg-white">
                <h4 className="font-bold text-xs text-red-800 mb-1">Historical Trends</h4>
                <div className="h-24 bg-gray-100 flex items-center justify-center">
                  <LineChart className="h-16 w-16 text-gray-500" />
                </div>
              </div>
              <div className="border border-gray-500 p-2 bg-white">
                <h4 className="font-bold text-xs text-blue-800 mb-1">Weather Impact</h4>
                <div className="h-24 bg-gray-100 flex items-center justify-center">
                  <BarChart className="h-16 w-16 text-gray-500" />
                </div>
              </div>
            </div>
            
            <div className="border border-gray-500 p-3 mb-3 bg-white">
              <h4 className="font-bold mb-1 text-purple-800 text-sm">AI Prediction Model</h4>
              <p className="text-xs mb-2">Train custom machine learning models on specific sports or leagues.</p>
              <div className="grid grid-cols-2 gap-2 mt-2">
                <button className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white text-xs py-1 px-2 rounded">
                  NBA Model
                </button>
                <button className="bg-gradient-to-r from-blue-500 to-cyan-600 text-white text-xs py-1 px-2 rounded">
                  NFL Model
                </button>
                <button className="bg-gradient-to-r from-red-500 to-orange-600 text-white text-xs py-1 px-2 rounded">
                  MLB Model
                </button>
                <button className="bg-gradient-to-r from-green-500 to-emerald-600 text-white text-xs py-1 px-2 rounded">
                  Soccer Model
                </button>
              </div>
            </div>
            
            <div className="border border-gray-500 p-3 bg-white">
              <h4 className="font-bold mb-1 text-amber-800 text-sm">Data Sources</h4>
              <div className="space-y-1 text-xs">
                <div className="flex justify-between">
                  <span>Sports API</span>
                  <span className="text-green-600">Connected</span>
                </div>
                <div className="flex justify-between">
                  <span>Historical Database</span>
                  <span className="text-green-600">Connected</span>
                </div>
                <div className="flex justify-between">
                  <span>Odds Provider</span>
                  <span className="text-green-600">Connected</span>
                </div>
                <div className="flex justify-between">
                  <span>Weather API</span>
                  <span className="text-yellow-600">Pending</span>
                </div>
              </div>
            </div>
          </div>
        </RetroWindow>
      )}
    </RetroDesktop>
  );
}
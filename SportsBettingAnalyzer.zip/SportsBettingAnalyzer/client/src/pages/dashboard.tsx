import { useEffect, useState } from "react";
import { useSportsData } from "@/hooks/useSportsData";
import StrategyCard from "@/components/dashboard/StrategyCard";
import UpcomingEvents from "@/components/dashboard/UpcomingEvents";
import BankrollCard from "@/components/dashboard/BankrollCard";
import PerformanceCard from "@/components/dashboard/PerformanceCard";
import GeniusAnalysisCard from "@/components/dashboard/GeniusAnalysisCard";
import CryptoWalletCard from "@/components/dashboard/CryptoWalletCard";
import PodcastPlayerCard from "@/components/dashboard/PodcastPlayerCard";
import CustomizeWidget from "@/components/dashboard/CustomizeWidget";
import CurrentBetsCard from "@/components/dashboard/CurrentBetsCard";
import QuickPickGame from "@/components/dashboard/QuickPickGame";
import MarketTickerBar from "@/components/dashboard/MarketTickerBar";
import MarketStatsCard from "@/components/dashboard/MarketStatsCard";
import EnhancedBetForm from "@/components/dashboard/EnhancedBetForm";
import { Button } from "@/components/ui/button";
import { 
  ChevronDown, 
  Plus, 
  LayoutDashboard, 
  Zap, 
  Target, 
  BarChart3, 
  Brain, 
  Calculator, 
  LucideIcon, 
  Headphones, 
  Wallet, 
  History,
  Bot,
  BookOpen,
  LineChart,
  AreaChart,
  PencilRuler,
  Share2,
  Webhook
} from "lucide-react";
import { 
  Dialog,
  DialogTrigger,
  DialogContent
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  useQuery
} from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";

interface DashboardProps {
  sportId?: number;
}

// Format odds to American format
const formatOdds = (odds: number): string => {
  if (!odds) return "N/A";
  
  if (odds >= 2) {
    // Positive odds (underdog)
    return `+${Math.round((odds - 1) * 100)}`;
  } else {
    // Negative odds (favorite)
    return `-${Math.round(100 / (odds - 1))}`;
  }
};

export default function Dashboard({ sportId }: DashboardProps) {
  const { 
    topRecommendations, 
    upcomingEvents, 
    isLoading, 
    refreshData, 
    generateRecommendations 
  } = useSportsData();
  
  const [isCustomizing, setIsCustomizing] = useState(false);
  const [showCrypto, setShowCrypto] = useState(false);
  const [selectedEventId, setSelectedEventId] = useState<number | null>(null);
  const [betDialogOpen, setBetDialogOpen] = useState(false);
  
  // Fetch edge bets
  const { data: edgeBets } = useQuery({
    queryKey: ['/api/edge-bets'],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/edge-bets?count=3");
      return res.json();
    }
  });

  // Filter by sport ID if provided
  const filteredEvents = sportId 
    ? upcomingEvents.filter(event => event.sportId === sportId)
    : upcomingEvents;

  const filteredRecommendations = sportId
    ? topRecommendations.filter(rec => rec.event.sportId === sportId)
    : topRecommendations;

  // Automatically refresh data on component mount
  useEffect(() => {
    refreshData();
    
    // Set up polling interval
    const refreshInterval = setInterval(() => {
      refreshData();
    }, 60000); // Refresh every minute
    
    return () => clearInterval(refreshInterval);
  }, [refreshData]);

  return (
    <div className="bg-zinc-900 min-h-screen text-zinc-200">
      {/* Market Ticker Bar */}
      <div className="sticky top-0 z-10 w-full">
        <MarketTickerBar />
      </div>
      
      <div className="container mx-auto py-6 px-4">
        {/* Page Header */}
        <div className="mb-6 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-blue-500">DK's KingMakerPickz Dashboard</h1>
            <p className="text-sm text-zinc-400">The Edge You Need to Beat the Books</p>
          </div>
          
          <div className="flex items-center space-x-2">
            {/* Tools Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="flex items-center space-x-1 border-zinc-700 text-cyan-400 hover:bg-zinc-800"
                >
                  <Brain className="h-4 w-4" />
                  <span>Tools</span>
                  <ChevronDown className="h-3 w-3 ml-1" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-64 bg-zinc-900 border border-zinc-700">
                <DropdownMenuLabel className="text-xs text-zinc-400">ANALYSIS TOOLS</DropdownMenuLabel>
                <DropdownMenuItem 
                  className="flex items-center cursor-pointer hover:bg-zinc-800 focus:bg-zinc-800"
                  onClick={() => {
                    toast({
                      title: "AI Edge Finder",
                      description: "Launching the AI Edge Finder tool...",
                    });
                    // Handle the Edge Finder launch here
                  }}
                >
                  <Target className="h-4 w-4 mr-2 text-cyan-400" />
                  <span>AI Edge Finder</span>
                </DropdownMenuItem>
                <DropdownMenuItem 
                  className="flex items-center cursor-pointer hover:bg-zinc-800 focus:bg-zinc-800"
                  onClick={() => {
                    toast({
                      title: "Match Analysis",
                      description: "Launching the advanced match analysis tool...",
                    });
                    // Handle the Match Analysis launch here
                  }}
                >
                  <BarChart3 className="h-4 w-4 mr-2 text-emerald-400" />
                  <span>Advanced Match Analysis</span>
                </DropdownMenuItem>
                <DropdownMenuItem 
                  className="flex items-center cursor-pointer hover:bg-zinc-800 focus:bg-zinc-800"
                  onClick={() => {
                    toast({
                      title: "Self-Learning Model",
                      description: "Launching the self-learning prediction model...",
                    });
                    // Launch the self-learning model dialog/interface
                  }}
                >
                  <Bot className="h-4 w-4 mr-2 text-purple-400" />
                  <span>Self-Learning Model</span>
                </DropdownMenuItem>
                
                <DropdownMenuSeparator className="bg-zinc-700" />
                <DropdownMenuLabel className="text-xs text-zinc-400">BETTING TOOLS</DropdownMenuLabel>
                
                <DropdownMenuItem 
                  className="flex items-center cursor-pointer hover:bg-zinc-800 focus:bg-zinc-800"
                  onClick={() => {
                    toast({
                      title: "Bankroll Calculator",
                      description: "Launching the bankroll management calculator...",
                    });
                    // Handle bankroll calculator launch
                  }}
                >
                  <Calculator className="h-4 w-4 mr-2 text-green-400" />
                  <span>Bankroll Calculator</span>
                </DropdownMenuItem>
                <DropdownMenuItem 
                  className="flex items-center cursor-pointer hover:bg-zinc-800 focus:bg-zinc-800"
                  onClick={() => {
                    toast({
                      title: "Betting Exchange",
                      description: "Connecting to betting exchange accounts...",
                    });
                    // Handle exchange connect
                  }}
                >
                  <Webhook className="h-4 w-4 mr-2 text-orange-400" />
                  <span>Exchange Connection</span>
                </DropdownMenuItem>
                
                <DropdownMenuSeparator className="bg-zinc-700" />
                <DropdownMenuLabel className="text-xs text-zinc-400">CONTENT TOOLS</DropdownMenuLabel>
                
                <DropdownMenuItem 
                  className="flex items-center cursor-pointer hover:bg-zinc-800 focus:bg-zinc-800"
                  onClick={() => {
                    toast({
                      title: "AI Podcast Generator",
                      description: "Launching the AI podcast generator...",
                    });
                    // Handle podcast generator
                  }}
                >
                  <Headphones className="h-4 w-4 mr-2 text-pink-400" />
                  <span>AI Podcast Generator</span>
                </DropdownMenuItem>
                <DropdownMenuItem 
                  className="flex items-center cursor-pointer hover:bg-zinc-800 focus:bg-zinc-800"
                  onClick={() => {
                    toast({
                      title: "Strategy Library",
                      description: "Opening the strategy library...",
                    });
                    // Handle strategy library
                  }}
                >
                  <BookOpen className="h-4 w-4 mr-2 text-blue-400" />
                  <span>Strategy Library</span>
                </DropdownMenuItem>
                <DropdownMenuItem 
                  className="flex items-center cursor-pointer hover:bg-zinc-800 focus:bg-zinc-800"
                  onClick={() => {
                    setShowCrypto(true);
                    toast({
                      title: "Crypto Integration",
                      description: "Setting up crypto wallet integration...",
                    });
                  }}
                >
                  <Wallet className="h-4 w-4 mr-2 text-yellow-400" />
                  <span>Crypto Integration</span>
                </DropdownMenuItem>
                
                <DropdownMenuSeparator className="bg-zinc-700" />
                
                <DropdownMenuItem 
                  className="flex items-center cursor-pointer hover:bg-zinc-800 focus:bg-zinc-800"
                  onClick={() => setIsCustomizing(true)}
                >
                  <LayoutDashboard className="h-4 w-4 mr-2 text-emerald-400" />
                  <span>Customize Dashboard</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center space-x-1 border-zinc-700 text-emerald-400 hover:bg-zinc-800"
              onClick={() => setIsCustomizing(true)}
            >
              <LayoutDashboard className="h-4 w-4" />
              <span>Customize</span>
            </Button>
            <span className="text-xs text-zinc-400">LIVE DATA</span>
            <span className="flex h-3 w-3">
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500 pulse"></span>
            </span>
          </div>
        </div>
        
        {/* Live Market Stats */}
        <div className="mb-6">
          <MarketStatsCard />
        </div>
        
        {/* Main Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Quick Pick Game */}
            <QuickPickGame />
            
            {/* Podcast Player Card */}
            <PodcastPlayerCard />
            
            {/* Genius Analysis Card */}
            <GeniusAnalysisCard />
            
            {/* Top Picks Cards */}
            <div className="bg-zinc-900/60 p-4 rounded-lg border border-zinc-800">
              <h2 className="text-xl font-bold mb-4 text-emerald-400 flex items-center">
                <span className="bg-emerald-500/20 p-1.5 rounded mr-2">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                    <path fillRule="evenodd" d="M8.603 3.799A4.49 4.49 0 0112 2.25c1.357 0 2.573.6 3.397 1.549a4.49 4.49 0 013.498 1.307 4.491 4.491 0 011.307 3.497A4.49 4.49 0 0121.75 12a4.49 4.49 0 01-1.549 3.397 4.491 4.491 0 01-1.307 3.497 4.491 4.491 0 01-3.497 1.307A4.49 4.49 0 0112 21.75a4.49 4.49 0 01-3.397-1.549 4.49 4.49 0 01-3.498-1.306 4.491 4.491 0 01-1.307-3.498A4.49 4.49 0 012.25 12c0-1.357.6-2.573 1.549-3.397a4.49 4.49 0 011.307-3.497 4.49 4.49 0 013.497-1.307zm7.007 6.387a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z" clipRule="evenodd" />
                  </svg>
                </span>
                Premium Picks
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {isLoading ? (
                  Array(3).fill(0).map((_, index) => (
                    <div key={index} className="bg-zinc-800 rounded-lg h-64 animate-pulse">
                      <div className="h-12 bg-zinc-700 rounded-t-lg"></div>
                      <div className="p-4 space-y-3">
                        <div className="h-6 bg-zinc-700 rounded-md"></div>
                        <div className="h-10 bg-zinc-700 rounded-md"></div>
                        <div className="h-4 bg-zinc-700 rounded-md"></div>
                        <div className="h-8 bg-zinc-700 rounded-md"></div>
                        <div className="h-10 bg-zinc-700 rounded-md"></div>
                      </div>
                    </div>
                  ))
                ) : filteredRecommendations.length === 0 ? (
                  <div className="col-span-3 text-center py-12">
                    <p className="text-zinc-400">No recommendations available for this filter.</p>
                    <button 
                      onClick={() => generateRecommendations()}
                      className="mt-4 px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-zinc-900 rounded-md font-semibold"
                    >
                      Generate Recommendations
                    </button>
                  </div>
                ) : (
                  filteredRecommendations.map(recommendation => (
                    <StrategyCard key={recommendation.id} recommendation={recommendation} />
                  ))
                )}
              </div>
            </div>
            
            {/* Edge Bets Section */}
            <div className="bg-zinc-900/60 p-4 rounded-lg border border-zinc-800">
              <h2 className="text-xl font-bold mb-4 text-cyan-400 flex items-center">
                <span className="bg-cyan-500/20 p-1.5 rounded mr-2">
                  <Target className="w-5 h-5" />
                </span>
                Edge Finder Bets
              </h2>
              
              <div className="mb-4">
                <p className="text-sm text-zinc-400">
                  Our AI has detected positive expected value (+EV) in these betting opportunities:
                </p>
              </div>
              
              <div className="grid gap-3">
                {edgeBets ? (
                  <>
                    {edgeBets.map((bet: any, index: number) => (
                      <div key={index} className="bg-zinc-800/60 border border-zinc-700 rounded-lg p-3 hover:border-cyan-700 hover:bg-zinc-800/80 transition-colors">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="text-xs text-zinc-500 uppercase">{bet.betType}</span>
                            <h3 className="font-medium text-white">{bet.pick} ({formatOdds(bet.odds)})</h3>
                            <p className="text-xs text-zinc-400 mt-1">{bet.analysis}</p>
                          </div>
                          <div className="flex flex-col items-end">
                            <span className="text-sm font-bold text-cyan-400">{bet.edgePercentage}% Edge</span>
                            <div className="mt-2 flex items-center">
                              <span className="text-xs mr-2 text-zinc-500">Confidence</span>
                              <div className="bg-zinc-700 h-2 w-16 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full ${bet.confidence > 75 ? "bg-green-500" : bet.confidence > 65 ? "bg-cyan-500" : "bg-amber-500"}`}
                                  style={{ width: `${bet.confidence}%` }}
                                ></div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="mt-3 flex justify-end">
                          <Button
                            size="sm"
                            onClick={() => {
                              setSelectedEventId(bet.eventId);
                              setBetDialogOpen(true);
                            }}
                            className="bg-cyan-600 hover:bg-cyan-700 text-white flex items-center"
                          >
                            <Zap className="w-3 h-3 mr-1" />
                            Place Bet
                          </Button>
                        </div>
                      </div>
                    ))}
                    
                    <Button
                      variant="outline"
                      className="mt-1 border-dashed border-zinc-700 hover:border-cyan-700 text-zinc-400 hover:text-cyan-400"
                      onClick={() => {
                        // Refresh edge bets
                        // This would trigger a refetch of the edge bets through React Query
                      }}
                    >
                      Refresh Edge Analysis
                    </Button>
                  </>
                ) : (
                  <div className="space-y-3">
                    {[1, 2, 3].map((_, i) => (
                      <div key={i} className="h-24 bg-zinc-800/60 border border-zinc-700 rounded-lg animate-pulse" />
                    ))}
                  </div>
                )}
              </div>
            </div>
            
            {/* Upcoming Events Table */}
            <div className="mt-6">
              <UpcomingEvents 
                events={filteredEvents} 
                loading={isLoading} 
                onBetClick={(eventId) => {
                  setSelectedEventId(eventId);
                  setBetDialogOpen(true);
                }}
              />
            </div>
          </div>
          
          {/* Right Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Current Bets Card */}
            <CurrentBetsCard />
            
            {/* Bankroll Card */}
            <BankrollCard />
            
            {/* Performance Card */}
            <PerformanceCard />
            
            {/* Crypto Integration */}
            {showCrypto ? (
              <CryptoWalletCard />
            ) : (
              <div className="mt-4">
                <Button 
                  variant="outline" 
                  className="w-full flex items-center justify-center space-x-1 border-zinc-700 text-zinc-300 hover:text-emerald-400 hover:bg-zinc-800"
                  onClick={() => setShowCrypto(true)}
                >
                  <Plus className="h-4 w-4" />
                  <span>Add Crypto Integration</span>
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Customize Widget Dialog */}
      <CustomizeWidget 
        isOpen={isCustomizing}
        onClose={() => setIsCustomizing(false)}
      />
      
      {/* Enhanced Bet Form Dialog */}
      {betDialogOpen && selectedEventId && (
        <EnhancedBetForm 
          eventId={selectedEventId} 
          onClose={() => {
            setBetDialogOpen(false);
            setSelectedEventId(null);
          }}
        />
      )}
    </div>
  );
}

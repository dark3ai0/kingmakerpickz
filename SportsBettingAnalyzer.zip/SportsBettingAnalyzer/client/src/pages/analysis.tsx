import { useState } from "react";
import { useSportsData } from "@/hooks/useSportsData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";

export default function Analysis() {
  const { sports, isLoading } = useSportsData();
  const [activeTab, setActiveTab] = useState("moneyline");
  const [selectedSport, setSelectedSport] = useState("all");
  const [timeframe, setTimeframe] = useState("30days");

  // Mock data for charts
  const moneylinePerformanceData = [
    { name: 'Week 1', winRate: 62, roi: 8.5 },
    { name: 'Week 2', winRate: 58, roi: 7.2 },
    { name: 'Week 3', winRate: 65, roi: 9.8 },
    { name: 'Week 4', winRate: 60, roi: 8.1 },
  ];

  const spreadPerformanceData = [
    { name: 'Week 1', winRate: 55, roi: 5.2 },
    { name: 'Week 2', winRate: 58, roi: 6.1 },
    { name: 'Week 3', winRate: 51, roi: 4.5 },
    { name: 'Week 4', winRate: 59, roi: 7.2 },
  ];

  const totalPerformanceData = [
    { name: 'Week 1', winRate: 68, roi: 10.2 },
    { name: 'Week 2', winRate: 72, roi: 12.5 },
    { name: 'Week 3', winRate: 65, roi: 9.8 },
    { name: 'Week 4', winRate: 70, roi: 11.3 },
  ];

  const strategyDistributionData = [
    { name: 'Moneyline', value: 48 },
    { name: 'Spread', value: 32 },
    { name: 'Over/Under', value: 20 },
  ];

  const COLORS = ['#3b82f6', '#334155', '#16a34a'];

  // Get the active performance data based on tab
  const getActivePerformanceData = () => {
    switch (activeTab) {
      case "moneyline":
        return moneylinePerformanceData;
      case "spread":
        return spreadPerformanceData;
      case "total":
        return totalPerformanceData;
      default:
        return moneylinePerformanceData;
    }
  };

  return (
    <div className="container mx-auto py-6 px-4">
      {/* Page Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Strategy Analysis</h1>
        <p className="text-sm text-slate-500">Analyze the performance of different betting strategies</p>
      </div>

      {/* Filters */}
      <div className="mb-6 flex flex-col sm:flex-row gap-3 justify-end">
        <Select value={selectedSport} onValueChange={setSelectedSport}>
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="All Sports" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Sports</SelectItem>
            {sports.map(sport => (
              <SelectItem key={sport.id} value={sport.id.toString()}>{sport.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Select value={timeframe} onValueChange={setTimeframe}>
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="Last 30 Days" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7days">Last 7 Days</SelectItem>
            <SelectItem value="30days">Last 30 Days</SelectItem>
            <SelectItem value="90days">Last 90 Days</SelectItem>
            <SelectItem value="all">All Time</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Strategy Tabs */}
      <Tabs defaultValue="moneyline" value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList className="w-full grid grid-cols-3">
          <TabsTrigger value="moneyline">Moneyline</TabsTrigger>
          <TabsTrigger value="spread">Spread</TabsTrigger>
          <TabsTrigger value="total">Over/Under</TabsTrigger>
        </TabsList>
        
        <TabsContent value="moneyline">
          <Card>
            <CardHeader>
              <CardTitle>Moneyline Strategy Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <div className="p-4 bg-slate-50 rounded-lg">
                  <p className="text-sm text-slate-500">Win Rate</p>
                  <p className="text-2xl font-semibold">62.5%</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg">
                  <p className="text-sm text-slate-500">ROI</p>
                  <p className="text-2xl font-semibold text-success-600">+8.2%</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg">
                  <p className="text-sm text-slate-500">Record</p>
                  <p className="text-2xl font-semibold">10-6</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg">
                  <p className="text-sm text-slate-500">Avg. Odds</p>
                  <p className="text-2xl font-semibold font-mono">-135</p>
                </div>
              </div>
              
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={getActivePerformanceData()}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Legend />
                    <Line
                      yAxisId="left"
                      type="monotone"
                      dataKey="winRate"
                      stroke="#3b82f6"
                      name="Win Rate (%)"
                      activeDot={{ r: 8 }}
                    />
                    <Line 
                      yAxisId="right" 
                      type="monotone" 
                      dataKey="roi" 
                      stroke="#16a34a" 
                      name="ROI (%)" 
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="spread">
          <Card>
            <CardHeader>
              <CardTitle>Spread Strategy Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <div className="p-4 bg-slate-50 rounded-lg">
                  <p className="text-sm text-slate-500">Win Rate</p>
                  <p className="text-2xl font-semibold">55.6%</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg">
                  <p className="text-sm text-slate-500">ROI</p>
                  <p className="text-2xl font-semibold text-success-600">+5.7%</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg">
                  <p className="text-sm text-slate-500">Record</p>
                  <p className="text-2xl font-semibold">5-4</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg">
                  <p className="text-sm text-slate-500">Avg. Line Value</p>
                  <p className="text-2xl font-semibold font-mono">1.7 pts</p>
                </div>
              </div>
              
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={getActivePerformanceData()}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Legend />
                    <Line
                      yAxisId="left"
                      type="monotone"
                      dataKey="winRate"
                      stroke="#334155"
                      name="Win Rate (%)"
                      activeDot={{ r: 8 }}
                    />
                    <Line 
                      yAxisId="right" 
                      type="monotone" 
                      dataKey="roi" 
                      stroke="#16a34a" 
                      name="ROI (%)" 
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="total">
          <Card>
            <CardHeader>
              <CardTitle>Over/Under Strategy Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <div className="p-4 bg-slate-50 rounded-lg">
                  <p className="text-sm text-slate-500">Win Rate</p>
                  <p className="text-2xl font-semibold">80.0%</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg">
                  <p className="text-sm text-slate-500">ROI</p>
                  <p className="text-2xl font-semibold text-success-600">+10.9%</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg">
                  <p className="text-sm text-slate-500">Record</p>
                  <p className="text-2xl font-semibold">4-1</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg">
                  <p className="text-sm text-slate-500">Avg. Differential</p>
                  <p className="text-2xl font-semibold font-mono">1.3 pts</p>
                </div>
              </div>
              
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={getActivePerformanceData()}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Legend />
                    <Line
                      yAxisId="left"
                      type="monotone"
                      dataKey="winRate"
                      stroke="#16a34a"
                      name="Win Rate (%)"
                      activeDot={{ r: 8 }}
                    />
                    <Line 
                      yAxisId="right" 
                      type="monotone" 
                      dataKey="roi" 
                      stroke="#f59e0b" 
                      name="ROI (%)" 
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Additional Analytics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Strategy Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={strategyDistributionData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                    label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {strategyDistributionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Win Rate by Confidence</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={[
                    { confidence: '50-60%', winRate: 52 },
                    { confidence: '60-70%', winRate: 58 },
                    { confidence: '70-80%', winRate: 67 },
                    { confidence: '80-90%', winRate: 78 },
                    { confidence: '90-100%', winRate: 92 },
                  ]}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="confidence" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="winRate" name="Win Rate (%)" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 flex justify-end">
        <Button variant="outline" className="mr-2">
          Export Data
        </Button>
        <Button>
          Generate Report
        </Button>
      </div>
    </div>
  );
}

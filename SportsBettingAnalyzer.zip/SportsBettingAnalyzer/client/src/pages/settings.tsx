import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { updateUserPreferences } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useBankroll } from "@/hooks/useBankroll";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"; // Added import assumption
import { Monitor, Terminal } from "@/components/ui/icons"; // Added import assumption


// Default user preferences
const DEFAULT_USER_ID = 1;

export default function Settings() {
  const { toast } = useToast();
  const { updateRiskLevel, riskLevel } = useBankroll();

  // General settings
  const [darkMode, setDarkMode] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [minimumConfidence, setMinimumConfidence] = useState(60);
  const [isModernMode, setIsModernMode] = useState(true); // Added state for interface mode

  // Sports settings
  const [enabledSports, setEnabledSports] = useState([
    { id: 1, name: "NFL", enabled: true },
    { id: 2, name: "NBA", enabled: true },
    { id: 3, name: "MLB", enabled: true },
    { id: 4, name: "NHL", enabled: true },
  ]);

  // Strategy settings
  const [enabledStrategies, setEnabledStrategies] = useState([
    { id: "moneyline", name: "Moneyline", enabled: true },
    { id: "spread", name: "Against the Spread", enabled: true },
    { id: "total", name: "Over/Under", enabled: true },
  ]);

  // Update preferences mutation
  const updatePreferencesMutation = useMutation({
    mutationFn: (data: any) => updateUserPreferences(DEFAULT_USER_ID, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/preferences/user/${DEFAULT_USER_ID}`] });
      toast({
        title: "Settings saved",
        description: "Your preferences have been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error saving settings",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const handleSaveSettings = () => {
    const enabledSportIds = enabledSports
      .filter(sport => sport.enabled)
      .map(sport => sport.id);

    updatePreferencesMutation.mutate({
      enabledSports: enabledSportIds,
      minimumConfidence,
      notificationsEnabled,
      isModernMode // Added interface mode to saved settings
    });
  };

  const handleToggleSport = (id: number) => {
    setEnabledSports(prev => 
      prev.map(sport => 
        sport.id === id ? { ...sport, enabled: !sport.enabled } : sport
      )
    );
  };

  const handleToggleStrategy = (id: string) => {
    setEnabledStrategies(prev => 
      prev.map(strategy => 
        strategy.id === id ? { ...strategy, enabled: !strategy.enabled } : strategy
      )
    );
  };

  return (
    <div className="container mx-auto py-6 px-4">
      {/* Page Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Settings</h1>
        <p className="text-sm text-slate-500">Customize your betting preferences</p>
      </div>

      <Tabs defaultValue="general" className="mb-6">
        <TabsList className="mb-4">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="sports">Sports</TabsTrigger>
          <TabsTrigger value="strategies">Strategies</TabsTrigger>
          <TabsTrigger value="account">Account</TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>Configure your app preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="dark-mode">Dark Mode</Label>
                  <p className="text-sm text-slate-500">Switch between light and dark theme</p>
                </div>
                <Switch
                  id="dark-mode"
                  checked={darkMode}
                  onCheckedChange={setDarkMode}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="notifications">Notifications</Label>
                  <p className="text-sm text-slate-500">Receive alerts for high-value bets</p>
                </div>
                <Switch
                  id="notifications"
                  checked={notificationsEnabled}
                  onCheckedChange={setNotificationsEnabled}
                />
              </div>

              <Separator />

              <div>
                <div className="mb-2">
                  <Label>Minimum Confidence Threshold</Label>
                  <p className="text-sm text-slate-500">Only show recommendations above this confidence level</p>
                </div>
                <div className="flex items-center space-x-2">
                  <Slider
                    value={[minimumConfidence]}
                    min={50}
                    max={90}
                    step={5}
                    onValueChange={(value) => setMinimumConfidence(value[0])}
                  />
                  <span className="w-12 text-right font-medium">{minimumConfidence}%</span>
                </div>
              </div>

              <Separator />

              <div>
                <div className="mb-2">
                  <Label>Interface Mode</Label>
                  <p className="text-sm text-slate-500">Choose your preferred interface style</p>
                </div>
                <ToggleGroup type="single" value={isModernMode ? "modern" : "research"} onValueChange={(value) => setIsModernMode(value === "modern")} >
                  <ToggleGroupItem value="modern" className="flex items-center gap-2">
                    <Monitor className="w-4 h-4" />
                    Modern
                  </ToggleGroupItem>
                  <ToggleGroupItem value="research" className="flex items-center gap-2">
                    <Terminal className="w-4 h-4" />
                    Research
                  </ToggleGroupItem>
                </ToggleGroup>
              </div>

              <Separator />

              <div>
                <div className="mb-2">
                  <Label>Risk Level</Label>
                  <p className="text-sm text-slate-500">Set your preferred risk tolerance</p>
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant={riskLevel === "low" ? "default" : "outline"}
                    className={riskLevel === "low" ? "" : ""}
                    onClick={() => updateRiskLevel("low")}
                  >
                    Low
                  </Button>
                  <Button
                    variant={riskLevel === "moderate" ? "default" : "outline"}
                    className={riskLevel === "moderate" ? "" : ""}
                    onClick={() => updateRiskLevel("moderate")}
                  >
                    Moderate
                  </Button>
                  <Button
                    variant={riskLevel === "high" ? "default" : "outline"}
                    className={riskLevel === "high" ? "" : ""}
                    onClick={() => updateRiskLevel("high")}
                  >
                    High
                  </Button>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                onClick={handleSaveSettings}
                disabled={updatePreferencesMutation.isPending}
              >
                {updatePreferencesMutation.isPending ? "Saving..." : "Save Settings"}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="sports">
          <Card>
            <CardHeader>
              <CardTitle>Sports Settings</CardTitle>
              <CardDescription>Select which sports to include in recommendations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {enabledSports.map(sport => (
                <div key={sport.id} className="flex items-center space-x-2">
                  <Checkbox 
                    id={`sport-${sport.id}`} 
                    checked={sport.enabled}
                    onCheckedChange={() => handleToggleSport(sport.id)}
                  />
                  <Label htmlFor={`sport-${sport.id}`} className="flex-1">{sport.name}</Label>
                </div>
              ))}
            </CardContent>
            <CardFooter>
              <Button 
                onClick={handleSaveSettings}
                disabled={updatePreferencesMutation.isPending}
              >
                {updatePreferencesMutation.isPending ? "Saving..." : "Save Settings"}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="strategies">
          <Card>
            <CardHeader>
              <CardTitle>Strategy Settings</CardTitle>
              <CardDescription>Configure which betting strategies to use</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {enabledStrategies.map(strategy => (
                <div key={strategy.id} className="flex items-center space-x-2">
                  <Checkbox 
                    id={`strategy-${strategy.id}`} 
                    checked={strategy.enabled}
                    onCheckedChange={() => handleToggleStrategy(strategy.id)}
                  />
                  <Label htmlFor={`strategy-${strategy.id}`} className="flex-1">{strategy.name}</Label>
                </div>
              ))}

              <Separator className="my-4" />

              <div>
                <Label className="mb-2 block">Strategy Weights</Label>
                <p className="text-sm text-slate-500 mb-4">Adjust the influence of each strategy in combined recommendations</p>

                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <Label htmlFor="moneyline-weight">Moneyline</Label>
                      <span className="text-sm">40%</span>
                    </div>
                    <Slider
                      id="moneyline-weight"
                      defaultValue={[40]}
                      max={100}
                      step={5}
                      disabled={!enabledStrategies.find(s => s.id === "moneyline")?.enabled}
                    />
                  </div>

                  <div>
                    <div className="flex justify-between mb-1">
                      <Label htmlFor="spread-weight">Spread</Label>
                      <span className="text-sm">35%</span>
                    </div>
                    <Slider
                      id="spread-weight"
                      defaultValue={[35]}
                      max={100}
                      step={5}
                      disabled={!enabledStrategies.find(s => s.id === "spread")?.enabled}
                    />
                  </div>

                  <div>
                    <div className="flex justify-between mb-1">
                      <Label htmlFor="total-weight">Over/Under</Label>
                      <span className="text-sm">25%</span>
                    </div>
                    <Slider
                      id="total-weight"
                      defaultValue={[25]}
                      max={100}
                      step={5}
                      disabled={!enabledStrategies.find(s => s.id === "total")?.enabled}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                onClick={handleSaveSettings}
                disabled={updatePreferencesMutation.isPending}
              >
                {updatePreferencesMutation.isPending ? "Saving..." : "Save Settings"}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="account">
          <Card>
            <CardHeader>
              <CardTitle>Account Settings</CardTitle>
              <CardDescription>Manage your account information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="username" className="block mb-1">Username</Label>
                <div className="flex">
                  <input 
                    id="username"
                    type="text"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    value="demo"
                    disabled
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="email" className="block mb-1">Email Address</Label>
                <div className="flex">
                  <input 
                    id="email"
                    type="email"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    value="demo@example.com"
                  />
                </div>
              </div>

              <Separator className="my-4" />

              <div>
                <Label className="block mb-4">Change Password</Label>
                <div className="space-y-2">
                  <div>
                    <Label htmlFor="current-password" className="text-sm">Current Password</Label>
                    <input 
                      id="current-password"
                      type="password"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    />
                  </div>
                  <div>
                    <Label htmlFor="new-password" className="text-sm">New Password</Label>
                    <input 
                      id="new-password"
                      type="password"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    />
                  </div>
                  <div>
                    <Label htmlFor="confirm-password" className="text-sm">Confirm New Password</Label>
                    <input 
                      id="confirm-password"
                      type="password"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    />
                  </div>
                  <Button className="mt-2">Change Password</Button>
                </div>
              </div>

              <Separator className="my-4" />

              <div>
                <h3 className="text-lg font-semibold text-red-600 mb-2">Danger Zone</h3>
                <p className="text-sm text-slate-500 mb-4">Permanently delete your account and all associated data.</p>
                <Button variant="destructive">Delete Account</Button>
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                onClick={handleSaveSettings}
                disabled={updatePreferencesMutation.isPending}
              >
                {updatePreferencesMutation.isPending ? "Saving..." : "Save Account Settings"}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
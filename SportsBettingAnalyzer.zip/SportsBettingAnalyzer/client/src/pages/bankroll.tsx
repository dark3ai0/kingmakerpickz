import { useState } from "react";
import { useBankroll } from "@/hooks/useBankroll";
import { useQuery } from "@tanstack/react-query";
import { getUserBetsWithDetails } from "@/lib/api";
import { formatCurrency, formatDate } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BankrollCalculatorCard } from "@/components/dashboard/BankrollCalculatorCard";
import { BarChart3 } from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { useToast } from "@/hooks/use-toast";

// Mock data for bankroll history
const bankrollHistoryData = [
  { date: "Jan 1", amount: 1000 },
  { date: "Jan 8", amount: 1050 },
  { date: "Jan 15", amount: 1120 },
  { date: "Jan 22", amount: 980 },
  { date: "Jan 29", amount: 1150 },
  { date: "Feb 5", amount: 1220 },
  { date: "Feb 12", amount: 1320 },
  { date: "Feb 19", amount: 1280 },
  { date: "Feb 26", amount: 1420 },
  { date: "Mar 5", amount: 1380 },
  { date: "Mar 12", amount: 1510 },
  { date: "Mar 19", amount: 1650 },
  { date: "Mar 26", amount: 1720 },
  { date: "Apr 2", amount: 1840 },
  { date: "Apr 9", amount: 1790 },
  { date: "Apr 16", amount: 1950 },
  { date: "Apr 23", amount: 2130 },
  { date: "Apr 30", amount: 2250 },
  { date: "May 7", amount: 2390 },
  { date: "May 14", amount: 2260 },
  { date: "May 21", amount: 2450 },
  { date: "May 28", amount: 2580 },
  { date: "Jun 4", amount: 2720 },
  { date: "Jun 11", amount: 2890 },
  { date: "Jun 18", amount: 3050 },
  { date: "Jun 25", amount: 3210 },
  { date: "Jul 2", amount: 3380 },
  { date: "Jul 9", amount: 3280 },
  { date: "Jul 16", amount: 3450 },
  { date: "Jul 23", amount: 3590 },
  { date: "Jul 30", amount: 3750 },
  { date: "Aug 6", amount: 3920 },
  { date: "Aug 13", amount: 4100 },
  { date: "Aug 20", amount: 4250 },
  { date: "Aug 27", amount: 4430 },
  { date: "Sep 3", amount: 4380 },
  { date: "Sep 10", amount: 4520 },
  { date: "Sep 17", amount: 4680 },
  { date: "Sep 24", amount: 4850 },
  { date: "Oct 1", amount: 5000 },
  { date: "Oct 8", amount: 5180 },
  { date: "Oct 15", amount: 5320 },
  { date: "Oct 22", amount: 5250 },
  { date: "Oct 29", amount: 5432.10 },
];

export default function Bankroll() {
  const { toast } = useToast();
  const [timeframe, setTimeframe] = useState("all");
  const { bankroll, riskLevel, unitSizePercent, unitSize, updateBankroll } = useBankroll();
  
  // Get user bets
  const { data: bets = [], isLoading: isLoadingBets } = useQuery({
    queryKey: ['/api/bets/user/1/details'],
  });

  // Filter bankroll history data based on timeframe
  const getFilteredBankrollData = () => {
    switch (timeframe) {
      case "1month":
        return bankrollHistoryData.slice(-4);
      case "3months":
        return bankrollHistoryData.slice(-12);
      case "6months":
        return bankrollHistoryData.slice(-24);
      case "1year":
        return bankrollHistoryData.slice(-52);
      default:
        return bankrollHistoryData;
    }
  };

  // Calculate bankroll statistics
  const calculateStats = () => {
    const data = getFilteredBankrollData();
    
    if (data.length < 2) return { startAmount: 0, endAmount: 0, change: 0, percentChange: 0 };
    
    const startAmount = data[0].amount;
    const endAmount = data[data.length - 1].amount;
    const change = endAmount - startAmount;
    const percentChange = (change / startAmount) * 100;
    
    return { startAmount, endAmount, change, percentChange };
  };

  const stats = calculateStats();

  const handleDepositFunds = () => {
    const amount = window.prompt("Enter deposit amount:");
    if (amount && !isNaN(parseFloat(amount))) {
      const newBankroll = bankroll + parseFloat(amount);
      updateBankroll(newBankroll);
      toast({
        title: "Deposit successful",
        description: `${formatCurrency(parseFloat(amount))} has been added to your bankroll.`,
      });
    }
  };

  const handleWithdrawFunds = () => {
    const amount = window.prompt("Enter withdrawal amount:");
    if (amount && !isNaN(parseFloat(amount))) {
      const withdrawAmount = parseFloat(amount);
      
      if (withdrawAmount > bankroll) {
        toast({
          title: "Withdrawal failed",
          description: "Insufficient funds in your bankroll.",
          variant: "destructive"
        });
        return;
      }
      
      const newBankroll = bankroll - withdrawAmount;
      updateBankroll(newBankroll);
      toast({
        title: "Withdrawal successful",
        description: `${formatCurrency(withdrawAmount)} has been withdrawn from your bankroll.`,
      });
    }
  };

  return (
    <div className="container mx-auto py-6 px-4">
      {/* Page Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Bankroll Management</h1>
        <p className="text-sm text-slate-500">Track and manage your betting capital</p>
      </div>

      {/* Bankroll Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-slate-500">Current Bankroll</p>
            <p className="text-3xl font-semibold font-mono mt-1">{formatCurrency(bankroll)}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-slate-500">Profit/Loss</p>
            <p className={`text-3xl font-semibold mt-1 ${stats.change >= 0 ? 'text-success-600' : 'text-red-600'}`}>
              {stats.change >= 0 ? '+' : ''}{formatCurrency(stats.change)}
            </p>
            <p className={`text-sm ${stats.percentChange >= 0 ? 'text-success-600' : 'text-red-600'}`}>
              {stats.percentChange >= 0 ? '+' : ''}{stats.percentChange.toFixed(2)}%
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-slate-500">Unit Size ({unitSizePercent}%)</p>
            <p className="text-3xl font-semibold font-mono mt-1">{formatCurrency(unitSize)}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-slate-500">Risk Level</p>
            <p className="text-3xl font-semibold mt-1">
              {riskLevel ? riskLevel.charAt(0).toUpperCase() + riskLevel.slice(1) : "Moderate"}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Actions */}
      <div className="flex flex-wrap gap-3 mb-6">
        <Button onClick={handleDepositFunds}>Deposit Funds</Button>
        <Button variant="outline" onClick={handleWithdrawFunds}>Withdraw Funds</Button>
      </div>

      {/* Bankroll History Chart */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Bankroll History</CardTitle>
          <div className="flex justify-end">
            <Tabs value={timeframe} onValueChange={setTimeframe}>
              <TabsList>
                <TabsTrigger value="1month">1M</TabsTrigger>
                <TabsTrigger value="3months">3M</TabsTrigger>
                <TabsTrigger value="6months">6M</TabsTrigger>
                <TabsTrigger value="1year">1Y</TabsTrigger>
                <TabsTrigger value="all">All</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={getFilteredBankrollData()}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis domain={['dataMin - 100', 'dataMax + 100']} />
                <Tooltip formatter={(value) => formatCurrency(value)} />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="amount"
                  stroke="#3b82f6"
                  activeDot={{ r: 8 }}
                  name="Bankroll"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Advanced Bankroll Tools */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Bankroll Calculator */}
        <BankrollCalculatorCard />
        
        {/* Betting Strategies */}
        <Card className="border-0 bg-gradient-to-br from-indigo-900/90 to-purple-900/90 text-white shadow-lg">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-transparent bg-clip-text bg-gradient-to-r from-indigo-200 to-purple-200">
              <BarChart3 className="h-5 w-5 text-indigo-300" /> 
              Advanced Strategies
            </CardTitle>
            <CardDescription className="text-indigo-200/80">
              Maximize returns with proven betting systems
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-4">
            <div className="space-y-4">
              <div className="bg-indigo-800/50 rounded-md p-4">
                <h3 className="text-lg font-medium text-white mb-2">Kelly Criterion</h3>
                <p className="text-indigo-200/80 text-sm mb-3">
                  Optimizes bet sizes based on your edge to maximize bankroll growth while minimizing risk of ruin.
                </p>
                <div className="text-xs text-indigo-200/60">
                  Best for: Value bettors with accurate probability estimates
                </div>
              </div>
              
              <div className="bg-indigo-800/50 rounded-md p-4">
                <h3 className="text-lg font-medium text-white mb-2">Fixed Unit Model</h3>
                <p className="text-indigo-200/80 text-sm mb-3">
                  Consistent, disciplined approach that bets the same percentage of your bankroll on each wager.
                </p>
                <div className="text-xs text-indigo-200/60">
                  Best for: Beginners and risk-averse bettors
                </div>
              </div>
              
              <div className="bg-indigo-800/50 rounded-md p-4">
                <h3 className="text-lg font-medium text-white mb-2">Proportional Value Betting</h3>
                <p className="text-indigo-200/80 text-sm mb-3">
                  Sizes bets proportionally to the edge identified in the market, betting more when edge is larger.
                </p>
                <div className="text-xs text-indigo-200/60">
                  Best for: Experienced bettors with proven edge
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Transactions */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
          <CardDescription>Your recent bets and deposits/withdrawals</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Date</th>
                  <th className="text-left p-2">Type</th>
                  <th className="text-left p-2">Description</th>
                  <th className="text-left p-2">Amount</th>
                  <th className="text-left p-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {isLoadingBets ? (
                  <tr>
                    <td colSpan={5} className="p-4 text-center">Loading transactions...</td>
                  </tr>
                ) : bets.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-4 text-center">No transactions found.</td>
                  </tr>
                ) : (
                  bets.map((bet) => (
                    <tr key={bet.id} className="border-b hover:bg-slate-50">
                      <td className="p-2">{formatDate(bet.createdAt)}</td>
                      <td className="p-2">Bet</td>
                      <td className="p-2">{bet.recommendation.recommendation}</td>
                      <td className="p-2 text-danger-600 font-mono">-{formatCurrency(bet.amount)}</td>
                      <td className="p-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          bet.status === 'won' ? 'bg-success-50 text-success-600' :
                          bet.status === 'lost' ? 'bg-red-50 text-red-600' :
                          'bg-slate-100 text-slate-600'
                        }`}>
                          {bet.status.charAt(0).toUpperCase() + bet.status.slice(1)}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
                
                {/* Sample transactions for demonstration */}
                <tr className="border-b hover:bg-slate-50">
                  <td className="p-2">Oct 25, 2023</td>
                  <td className="p-2">Deposit</td>
                  <td className="p-2">Bank Transfer</td>
                  <td className="p-2 text-success-600 font-mono">+{formatCurrency(500)}</td>
                  <td className="p-2">
                    <span className="px-2 py-1 rounded-full text-xs font-medium bg-success-50 text-success-600">
                      Completed
                    </span>
                  </td>
                </tr>
                <tr className="border-b hover:bg-slate-50">
                  <td className="p-2">Oct 10, 2023</td>
                  <td className="p-2">Withdrawal</td>
                  <td className="p-2">Bank Transfer</td>
                  <td className="p-2 text-danger-600 font-mono">-{formatCurrency(200)}</td>
                  <td className="p-2">
                    <span className="px-2 py-1 rounded-full text-xs font-medium bg-success-50 text-success-600">
                      Completed
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

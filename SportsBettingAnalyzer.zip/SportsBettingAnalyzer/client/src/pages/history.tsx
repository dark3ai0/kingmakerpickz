import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getUserBetsWithDetails } from "@/lib/api";
import { formatCurrency, formatDate, formatTime, formatOdds } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie,
} from "recharts";

export default function History() {
  const [statusFilter, setStatusFilter] = useState("all");
  const [sportFilter, setSportFilter] = useState("all");
  const [strategyFilter, setStrategyFilter] = useState("all");
  const [timeframe, setTimeframe] = useState("all");

  // Get user bets
  const { data: bets = [], isLoading } = useQuery({
    queryKey: ['/api/bets/user/1/details'],
  });

  // Filter bets based on selected filters
  const filteredBets = bets.filter(bet => {
    const statusMatch = statusFilter === "all" || bet.status === statusFilter;
    const sportMatch = sportFilter === "all" || bet.recommendation.event.sportId.toString() === sportFilter;
    const strategyMatch = strategyFilter === "all" || bet.recommendation.strategyType === strategyFilter;
    
    return statusMatch && sportMatch && strategyMatch;
  });

  // Calculate summary statistics
  const calculateSummary = () => {
    if (filteredBets.length === 0) {
      return {
        total: 0,
        won: 0,
        lost: 0,
        pending: 0,
        winRate: 0,
        netProfit: 0,
        roi: 0
      };
    }

    const total = filteredBets.length;
    const won = filteredBets.filter(bet => bet.status === "won").length;
    const lost = filteredBets.filter(bet => bet.status === "lost").length;
    const pending = filteredBets.filter(bet => bet.status === "pending").length;
    const winRate = (won / (won + lost)) * 100 || 0;

    const totalStaked = filteredBets.reduce((sum, bet) => sum + parseFloat(bet.amount), 0);
    const wonAmount = filteredBets
      .filter(bet => bet.status === "won")
      .reduce((sum, bet) => sum + parseFloat(bet.potentialWin), 0);
    
    const netProfit = wonAmount - totalStaked;
    const roi = (netProfit / totalStaked) * 100 || 0;

    return {
      total,
      won,
      lost,
      pending,
      winRate,
      netProfit,
      roi
    };
  };

  const summary = calculateSummary();

  // Prepare data for charts
  const betsByStrategyData = [
    { name: "Moneyline", value: filteredBets.filter(bet => bet.recommendation.strategyType === "moneyline").length },
    { name: "Spread", value: filteredBets.filter(bet => bet.recommendation.strategyType === "spread").length },
    { name: "Over/Under", value: filteredBets.filter(bet => bet.recommendation.strategyType === "total").length },
  ].filter(item => item.value > 0);

  const betsByResultData = [
    { name: "Won", value: summary.won },
    { name: "Lost", value: summary.lost },
    { name: "Pending", value: summary.pending },
  ].filter(item => item.value > 0);

  const COLORS = ['#3b82f6', '#334155', '#16a34a', '#f59e0b', '#ef4444'];
  const RESULT_COLORS = { Won: '#16a34a', Lost: '#ef4444', Pending: '#f59e0b' };

  return (
    <div className="container mx-auto py-6 px-4">
      {/* Page Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Betting History</h1>
        <p className="text-sm text-slate-500">Track and analyze your past bets</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-slate-500">Total Bets</p>
            <p className="text-3xl font-semibold mt-1">{summary.total}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-slate-500">Win Rate</p>
            <p className="text-3xl font-semibold mt-1">{summary.winRate.toFixed(1)}%</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-slate-500">Net Profit</p>
            <p className={`text-3xl font-semibold mt-1 ${summary.netProfit >= 0 ? 'text-success-600' : 'text-red-600'}`}>
              {summary.netProfit >= 0 ? '+' : ''}{formatCurrency(summary.netProfit)}
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-slate-500">ROI</p>
            <p className={`text-3xl font-semibold mt-1 ${summary.roi >= 0 ? 'text-success-600' : 'text-red-600'}`}>
              {summary.roi >= 0 ? '+' : ''}{summary.roi.toFixed(1)}%
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-lg shadow-sm border border-slate-200 mb-6">
        <div className="flex flex-wrap gap-3">
          <div>
            <p className="text-sm text-slate-500 mb-1">Status</p>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="All Statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="won">Won</SelectItem>
                <SelectItem value="lost">Lost</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="pushed">Pushed</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <p className="text-sm text-slate-500 mb-1">Sport</p>
            <Select value={sportFilter} onValueChange={setSportFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="All Sports" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sports</SelectItem>
                <SelectItem value="1">NFL</SelectItem>
                <SelectItem value="2">NBA</SelectItem>
                <SelectItem value="3">MLB</SelectItem>
                <SelectItem value="4">NHL</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <p className="text-sm text-slate-500 mb-1">Strategy</p>
            <Select value={strategyFilter} onValueChange={setStrategyFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="All Strategies" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Strategies</SelectItem>
                <SelectItem value="moneyline">Moneyline</SelectItem>
                <SelectItem value="spread">Spread</SelectItem>
                <SelectItem value="total">Over/Under</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <p className="text-sm text-slate-500 mb-1">Timeframe</p>
            <Select value={timeframe} onValueChange={setTimeframe}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="All Time" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="7days">Last 7 Days</SelectItem>
                <SelectItem value="30days">Last 30 Days</SelectItem>
                <SelectItem value="90days">Last 90 Days</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Bets by Strategy</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={betsByStrategyData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                    label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {betsByStrategyData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [value, 'Bets']} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Bets by Result</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={betsByResultData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                    label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {betsByResultData.map((entry) => (
                      <Cell key={entry.name} fill={RESULT_COLORS[entry.name as keyof typeof RESULT_COLORS]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [value, 'Bets']} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bet History Table */}
      <Card>
        <CardHeader>
          <CardTitle>Bet History</CardTitle>
          <CardDescription>Your complete betting record</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">Loading betting history...</div>
          ) : filteredBets.length === 0 ? (
            <div className="text-center py-8">No bets found matching your filters.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-2">Date</th>
                    <th className="text-left p-2">Event</th>
                    <th className="text-left p-2">Strategy</th>
                    <th className="text-left p-2">Bet</th>
                    <th className="text-left p-2">Stake</th>
                    <th className="text-left p-2">Odds</th>
                    <th className="text-left p-2">Potential Win</th>
                    <th className="text-left p-2">Result</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredBets.map((bet) => (
                    <tr key={bet.id} className="border-b hover:bg-slate-50">
                      <td className="p-2">{formatDate(bet.createdAt)}</td>
                      <td className="p-2">
                        <div className="font-medium">{bet.recommendation.event.homeTeam}</div>
                        <div className="text-sm text-slate-500">vs {bet.recommendation.event.awayTeam}</div>
                      </td>
                      <td className="p-2">
                        <Badge variant="outline" className="capitalize">
                          {bet.recommendation.strategyType}
                        </Badge>
                      </td>
                      <td className="p-2">{bet.recommendation.recommendation}</td>
                      <td className="p-2 font-mono">{formatCurrency(bet.amount)}</td>
                      <td className="p-2 font-mono">{formatOdds(bet.placedOdds)}</td>
                      <td className="p-2 font-mono">{formatCurrency(bet.potentialWin)}</td>
                      <td className="p-2">
                        <Badge className={
                          bet.status === 'won' ? 'bg-success-500 hover:bg-success-600' :
                          bet.status === 'lost' ? 'bg-red-500 hover:bg-red-600' :
                          bet.status === 'pushed' ? 'bg-slate-500 hover:bg-slate-600' :
                          'bg-amber-500 hover:bg-amber-600'
                        }>
                          {bet.status.charAt(0).toUpperCase() + bet.status.slice(1)}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="mt-6 flex justify-end">
        <Button variant="outline" className="mr-2">
          Export History
        </Button>
      </div>
    </div>
  );
}

import { apiRequest } from "./queryClient";
import type {
  User,
  Sport,
  EventWithOdds,
  Recommendation,
  RecommendationWithEvent,
  Bet,
  BetWithDetails,
  UserPreference
} from "@shared/schema";

// User API
export async function getUser(id: number): Promise<User> {
  const res = await apiRequest("GET", `/api/user/${id}`);
  return res.json();
}

export async function updateUserBankroll(id: number, bankroll: number): Promise<User> {
  const res = await apiRequest("PATCH", `/api/user/${id}/bankroll`, { bankroll });
  return res.json();
}

export async function updateUserRiskLevel(id: number, riskLevel: string): Promise<User> {
  const res = await apiRequest("PATCH", `/api/user/${id}/risk-level`, { riskLevel });
  return res.json();
}

export async function updateUserUnitSize(id: number, unitSizePercent: number): Promise<User> {
  const res = await apiRequest("PATCH", `/api/user/${id}/unit-size`, { unitSizePercent });
  return res.json();
}

// Sports API
export async function getAllSports(): Promise<Sport[]> {
  const res = await apiRequest("GET", "/api/sports");
  return res.json();
}

// Events API
export async function getUpcomingEvents(limit: number = 10): Promise<EventWithOdds[]> {
  const res = await apiRequest("GET", `/api/events/upcoming?limit=${limit}`);
  return res.json();
}

export async function getEvent(id: number): Promise<EventWithOdds> {
  const res = await apiRequest("GET", `/api/events/${id}`);
  return res.json();
}

// Recommendations API
export async function getTopRecommendations(limit: number = 3): Promise<RecommendationWithEvent[]> {
  const res = await apiRequest("GET", `/api/recommendations/top?limit=${limit}`);
  return res.json();
}

export async function getRecommendationsByEventId(eventId: number): Promise<Recommendation[]> {
  const res = await apiRequest("GET", `/api/recommendations/event/${eventId}`);
  return res.json();
}

// Bets API
export async function getUserBets(userId: number): Promise<Bet[]> {
  const res = await apiRequest("GET", `/api/bets/user/${userId}`);
  return res.json();
}

export async function getUserBetsWithDetails(userId: number): Promise<BetWithDetails[]> {
  const res = await apiRequest("GET", `/api/bets/user/${userId}/details`);
  return res.json();
}

export async function placeBet(
  userId: number,
  recommendationId: number,
  amount: number,
  placedOdds: number
): Promise<Bet> {
  const potentialWin = amount * (placedOdds > 0 
    ? placedOdds / 100 
    : 100 / Math.abs(placedOdds));
    
  const res = await apiRequest("POST", "/api/bets", {
    userId,
    recommendationId,
    amount: amount.toString(),
    placedOdds,
    potentialWin: potentialWin.toString()
  });
  
  return res.json();
}

// User Preferences API
export async function getUserPreferences(userId: number): Promise<UserPreference> {
  const res = await apiRequest("GET", `/api/preferences/user/${userId}`);
  return res.json();
}

export async function updateUserPreferences(
  userId: number, 
  preferences: Partial<UserPreference>
): Promise<UserPreference> {
  const res = await apiRequest("PATCH", `/api/preferences/user/${userId}`, preferences);
  return res.json();
}

// Data refresh API
export async function refreshSportsData(): Promise<any> {
  const res = await apiRequest("POST", "/api/refresh-data");
  return res.json();
}

export async function generateRecommendations(): Promise<any> {
  const res = await apiRequest("POST", "/api/generate-recommendations");
  return res.json();
}

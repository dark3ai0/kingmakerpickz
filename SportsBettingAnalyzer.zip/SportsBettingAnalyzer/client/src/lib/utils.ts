import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Format currency values
 */
export function formatCurrency(amount: number | string): string {
  const num = typeof amount === 'string' ? parseFloat(amount) : amount;
  return new Intl.NumberFormat('en-US', { 
    style: 'currency', 
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(num);
}

/* We'll use the more comprehensive formatOdds function defined below */

/**
 * Format date in a human-readable way
 */
export function formatDate(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  const today = new Date();
  
  // Check if the date is today
  if (d.toDateString() === today.toDateString()) {
    return 'Today';
  }
  
  // Check if the date is tomorrow
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  if (d.toDateString() === tomorrow.toDateString()) {
    return 'Tomorrow';
  }
  
  // Otherwise, return the date in format: "Mon, Jan 1"
  return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
}

/**
 * Format time in a human-readable way (e.g. "7:30 PM ET")
 */
export function formatTime(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleTimeString('en-US', { 
    hour: 'numeric',
    minute: '2-digit',
    timeZoneName: 'short'
  });
}

/**
 * Convert American odds to implied probability
 */
export function oddsToImpliedProbability(odds: number): number {
  if (odds > 0) {
    return 100 / (odds + 100);
  } else {
    return Math.abs(odds) / (Math.abs(odds) + 100);
  }
}

/**
 * Format American odds for display
 */
export function formatOdds(odds: number | null): string {
  if (odds === null) {
    return 'N/A';
  }
  if (odds > 0) {
    return `+${odds}`;
  }
  return odds.toString();
}

/**
 * Calculate potential win amount based on bet amount and odds
 */
export function calculatePotentialWin(amount: number, odds: number): number {
  if (odds > 0) {
    return amount * (odds / 100);
  } else {
    return amount * (100 / Math.abs(odds));
  }
}

/**
 * Format confidence level as text
 */
export function getConfidenceLevel(confidence: number): string {
  if (confidence >= 75) return "High";
  if (confidence >= 60) return "Medium";
  return "Low";
}

/**
 * Get CSS class for confidence level
 */
export function getConfidenceLevelClass(confidence: number): string {
  if (confidence >= 75) return "bg-success-50 text-success-600";
  if (confidence >= 60) return "bg-slate-100 text-slate-600";
  return "bg-amber-50 text-amber-600";
}

/**
 * Format number as percentage
 */
export function formatPercent(value: number): string {
  return `${value.toFixed(1)}%`;
}

/**
 * Format decimal as readable with specified precision
 */
export function formatDecimal(value: number, precision: number = 1): string {
  return value.toFixed(precision);
}

import React, { useState } from 'react';

interface RetroDesktopProps {
  children: React.ReactNode;
  backgroundImage?: string;
}

const RetroDesktop: React.FC<RetroDesktopProps> = ({ 
  children,
  backgroundImage 
}) => {
  // Add a scanline effect to simulate CRT monitor
  const scanlineEffect = (
    <div className="scanlines absolute inset-0 pointer-events-none z-[9999]">
      {/* CSS for scanlines will be in index.css */}
    </div>
  );

  return (
    <div 
      className="retro-desktop w-full h-screen overflow-hidden relative bg-teal-900"
      style={{
        backgroundImage: backgroundImage ? `url(${backgroundImage})` : undefined,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        imageRendering: 'pixelated',
      }}
    >
      <div className="desktop-content relative h-full">
        {children}
      </div>
      
      {/* Taskbar */}
      <div className="retro-taskbar fixed bottom-0 left-0 right-0 h-8 bg-gray-400 border-t border-gray-300 flex items-center px-2 z-50">
        <button className="start-button h-6 px-2 bg-blue-600 text-white text-xs font-bold rounded-sm mr-2 flex items-center">
          <span className="mr-1">▶</span> Start
        </button>
        
        <div className="taskbar-separator h-6 border-l border-gray-500 mx-1"></div>
        
        <div className="taskbar-programs flex-1 flex items-center space-x-1">
          {/* Program buttons would go here */}
        </div>
        
        <div className="taskbar-tray flex items-center space-x-1 border-l border-gray-500 pl-1">
          <div className="clock text-xs px-2 py-1">12:00 PM</div>
        </div>
      </div>
      
      {scanlineEffect}
    </div>
  );
};

export default RetroDesktop;
import React, { useState, useRef, useEffect } from 'react';
import { X, Minus, Square } from 'lucide-react';

interface RetroWindowProps {
  title: string;
  width?: number;
  height?: number;
  initialPosition?: { x: number; y: number };
  zIndex?: number;
  onClose?: () => void;
  onMinimize?: () => void;
  onMaximize?: () => void;
  children: React.ReactNode;
  isActive?: boolean;
  onActivate?: () => void;
}

const RetroWindow: React.FC<RetroWindowProps> = ({
  title,
  width = 320,
  height = 240,
  initialPosition = { x: 50, y: 50 },
  zIndex = 1,
  onClose,
  onMinimize,
  onMaximize,
  children,
  isActive = false,
  onActivate,
}) => {
  const [position, setPosition] = useState(initialPosition);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [isMaximized, setIsMaximized] = useState(false);
  const windowRef = useRef<HTMLDivElement>(null);

  // Handle dragging
  const handleMouseDown = (e: React.MouseEvent) => {
    if (isMaximized) return;
    
    if (onActivate) {
      onActivate();
    }
    
    setIsDragging(true);
    setDragOffset({
      x: e.clientX - position.x,
      y: e.clientY - position.y,
    });
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!isDragging) return;
    
    setPosition({
      x: e.clientX - dragOffset.x,
      y: e.clientY - dragOffset.y,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Set up global event listeners for dragging
  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    } else {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    }
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  // Handle maximize/restore
  const toggleMaximize = () => {
    setIsMaximized(!isMaximized);
    if (onMaximize) {
      onMaximize();
    }
  };

  return (
    <div
      ref={windowRef}
      className={`retro-window absolute shadow-[4px_4px_0px_0px_rgba(0,0,0,0.8)] ${isActive ? 'border-blue-700' : 'border-gray-500'}`}
      style={{
        width: isMaximized ? '100%' : width,
        height: isMaximized ? 'calc(100vh - 40px)' : height,
        left: isMaximized ? 0 : position.x,
        top: isMaximized ? 0 : position.y,
        zIndex,
        imageRendering: 'pixelated',
      }}
      onClick={onActivate}
    >
      {/* Window title bar */}
      <div 
        className={`retro-window-titlebar h-6 flex items-center justify-between px-1 cursor-move ${isActive ? 'bg-blue-700 text-white' : 'bg-gray-500 text-gray-200'}`}
        onMouseDown={handleMouseDown}
        onDoubleClick={toggleMaximize}
      >
        <div className="text-xs font-pixel truncate">{title}</div>
        <div className="flex space-x-1">
          <button 
            className="retro-window-control w-4 h-4 bg-gray-300 border border-gray-400 flex items-center justify-center hover:bg-gray-400"
            onClick={onMinimize}
          >
            <Minus className="w-3 h-3" />
          </button>
          <button 
            className="retro-window-control w-4 h-4 bg-gray-300 border border-gray-400 flex items-center justify-center hover:bg-gray-400"
            onClick={toggleMaximize}
          >
            <Square className="w-3 h-3" />
          </button>
          <button 
            className="retro-window-control w-4 h-4 bg-red-500 border border-red-600 flex items-center justify-center hover:bg-red-600"
            onClick={onClose}
          >
            <X className="w-3 h-3 text-white" />
          </button>
        </div>
      </div>
      
      {/* Window content */}
      <div className="retro-window-content bg-gray-200 border-t border-gray-300 p-2 overflow-auto flex-1 h-[calc(100%-24px)]">
        {children}
      </div>
      
      {/* Window resize handle */}
      {!isMaximized && (
        <div className="retro-window-resize absolute bottom-0 right-0 w-4 h-4 cursor-se-resize">
          <div className="w-0 h-0 border-t-[6px] border-t-transparent border-l-[6px] border-l-transparent border-b-[6px] border-b-gray-600 border-r-[6px] border-r-gray-600"></div>
        </div>
      )}
    </div>
  );
};

export default RetroWindow;
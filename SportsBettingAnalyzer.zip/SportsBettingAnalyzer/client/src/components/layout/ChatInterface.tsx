import * as React from "react";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Brain, Calculator, Calendar, DollarSign, ChartBar, Upload } from "lucide-react";
import MarketTickerBar from "@/components/dashboard/MarketTickerBar";
import GeniusAnalysisCard from "@/components/dashboard/GeniusAnalysisCard";
import BankrollCalculatorCard from "@/components/dashboard/BankrollCalculatorCard";
import UpcomingEvents from "@/components/dashboard/UpcomingEvents";
import BankrollCard from "@/components/dashboard/BankrollCard";
import PerformanceCard from "@/components/dashboard/PerformanceCard";

const COMPONENT_MAP = {
  GeniusAnalysisCard,
  BankrollCalculatorCard,
  UpcomingEvents,
  BankrollCard,
  PerformanceCard,
};

export default function ChatInterface() {
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant', content: string }[]>([
    { role: 'assistant', content: 'Welcome to KingMaker AI! I can help you analyze sports data, manage your bankroll, and make informed betting decisions. What would you like to do?' }
  ]);
  const [input, setInput] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsAnalyzing(true);
    const formData = new FormData();
    formData.append('image', file);

    try {
      const response = await fetch('/api/analyze-image', {
        method: 'POST',
        body: formData
      });

      const analysis = await response.json();
      setMessages(prev => [...prev, 
        { role: 'user', content: `Uploaded image: ${file.name}` },
        { role: 'assistant', content: analysis.result }
      ]);
    } catch (error) {
      setMessages(prev => [...prev, 
        { role: 'assistant', content: 'Failed to analyze the image. Please try again.' }
      ]);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const tools = [
    { icon: Brain, name: 'AI Analysis', command: '/analyze', component: 'GeniusAnalysisCard' },
    { icon: Calculator, name: 'Calculator', command: '/calc', component: 'BankrollCalculatorCard' },
    { icon: Calendar, name: 'Events', command: '/events', component: 'UpcomingEvents' },
    { icon: DollarSign, name: 'Bankroll', command: '/bankroll', component: 'BankrollCard' },
    { icon: ChartBar, name: 'Performance', command: '/performance', component: 'PerformanceCard' },
  ];

  const [activeComponent, setActiveComponent] = useState<string | null>(null);

  const handleToolClick = (e: React.MouseEvent, command: string, component: string) => {
    e.preventDefault();
    setInput(command + ' ');
    setActiveComponent(component);
    setMessages(prev => [...prev, { 
      role: 'assistant', 
      content: `I've activated the ${component} tool. How can I help you with it?` 
    }]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    setMessages(prev => [...prev, { role: 'user', content: input }]);
    setInput('');

    // Here you would normally process the input and get a response
    // For now, we'll just echo a simple response
    setTimeout(() => {
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: "I understand you want to analyze sports data. You can access detailed features through the sidebar, or I can help guide you through specific actions." 
      }]);
    }, 1000);
  };

  return (
    <div className="flex flex-col h-full">
      <MarketTickerBar />
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((message, i) => (
            <div
              key={i}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.role === 'user'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-900'
                }`}
              >
                {message.content}
              </div>
            </div>
          ))}
          {activeComponent && COMPONENT_MAP[activeComponent as keyof typeof COMPONENT_MAP] && (
            <div className="w-full rounded-lg bg-white/5 backdrop-blur-sm p-4 border border-gray-200/20">
              {React.createElement(COMPONENT_MAP[activeComponent as keyof typeof COMPONENT_MAP], { inChat: true })}
            </div>
          )}
        </div>
      </ScrollArea>

      <form onSubmit={handleSubmit} className="p-4 border-t">
        <div className="flex flex-col gap-2">
          <div className="flex gap-2 mb-2">
            {tools.map((tool) => (
              <Button
                key={tool.command}
                variant="outline"
                size="sm"
                className="flex items-center gap-1"
                onClick={(e) => handleToolClick(e, tool.command, tool.component)}
              >
                <tool.icon className="h-4 w-4" />
                {tool.name}
              </Button>
            ))}
          </div>
          <div className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about sports analysis, betting strategies, or use specific features..."
              className="flex-1"
            />
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept="image/*"
              className="hidden"
            />
            <Button 
              type="button" 
              size="icon" 
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              disabled={isAnalyzing}
            >
              <Upload className="h-4 w-4" />
            </Button>
            <Button type="submit" size="icon" disabled={isAnalyzing}>
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}

import { useState } from "react";
import { formatCurrency } from "@/lib/utils";
import { useBankroll } from "@/hooks/useBankroll";
import { Search, Menu, Bell, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";

interface HeaderProps {
  toggleSidebar: () => void;
}

export default function Header({ toggleSidebar }: HeaderProps) {
  const { bankroll, isLoading } = useBankroll();
  
  return (
    <header className="bg-white/50 backdrop-blur-md border-b border-gray-100 h-14 z-20">
      <div className="px-4 h-full flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button 
            onClick={toggleSidebar}
            variant="ghost"
            size="icon"
            className="md:hidden text-gray-600"
          >
            <Menu className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-semibold text-gray-900">KingMaker AI</h1>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center px-3 py-1.5 bg-gradient-to-r from-indigo-500 to-indigo-600 text-white rounded-full text-sm font-medium">
            <DollarSign className="w-3.5 h-3.5 mr-1 text-indigo-200" />
            {isLoading ? "$0.00" : formatCurrency(bankroll)}
          </div>
          
          <Button 
            variant="ghost" 
            size="icon"
            className="relative text-gray-600 hover:text-gray-900 hover:bg-gray-50"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-indigo-500 rounded-full" />
          </Button>

          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-indigo-600 flex items-center justify-center text-white text-sm font-medium shadow-md">
            D
          </div>
        </div>
      </div>
    </header>
  );
}

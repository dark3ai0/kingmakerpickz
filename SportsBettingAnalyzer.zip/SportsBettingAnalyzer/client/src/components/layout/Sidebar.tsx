import { useState } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, LayoutDashboard, BarChart, DollarSign, Clock, Dribbble, Settings, Crown } from "lucide-react";

export default function Sidebar() {
  const [location] = useLocation();
  const [collapsed, setCollapsed] = useState(true);

  const { data: sports = [] } = useQuery({
    queryKey: ['/api/sports'],
  });

  return (
    <aside 
      className={cn(
        "bg-white/10 backdrop-blur-lg border-r border-gray-100/20 text-gray-700 flex-shrink-0 hidden md:flex md:flex-col h-screen transition-all duration-300 shadow-lg z-30",
        collapsed ? "w-16" : "w-56"
      )}
      style={{
        backgroundImage: "linear-gradient(to bottom, rgba(255,255,255,0.1), rgba(255,255,255,0.05))"
      }}
    >
      <div className="p-2 flex items-center justify-between">
        {!collapsed && (
          <div className="flex items-center space-x-2">
            <Crown className="w-5 h-5 text-indigo-600" />
            <span className="font-semibold text-sm">KingMaker</span>
          </div>
        )}
        {collapsed && <Crown className="w-6 h-6 text-indigo-600 mx-auto" />}
        <button 
          onClick={() => setCollapsed(!collapsed)}
          className="text-gray-400 hover:text-gray-600 p-1 rounded-lg hover:bg-gray-50 transition-colors"
        >
          {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
        </button>
      </div>

      <ScrollArea className="flex-1">
        <nav className="p-2 space-y-1">
          {[
            { href: "/", icon: LayoutDashboard, label: "Overview" },
            { href: "/analysis", icon: BarChart, label: "Analysis" },
            { href: "/bankroll", icon: DollarSign, label: "Bankroll" },
            { href: "/history", icon: Clock, label: "History" },
          ].map(({ href, icon: Icon, label }) => (
            <Link key={href} href={href}>
              <span className={cn(
                "flex items-center rounded-lg transition-colors",
                collapsed ? "justify-center p-3" : "px-3 py-2",
                location === href 
                  ? "bg-indigo-50 text-indigo-600" 
                  : "text-gray-600 hover:bg-gray-50"
              )}>
                <Icon className={cn("flex-shrink-0", collapsed ? "w-5 h-5" : "w-4 h-4 mr-3")} />
                {!collapsed && <span className="text-sm">{label}</span>}
              </span>
            </Link>
          ))}

          

          <Link href="/settings">
            <span className={cn(
              "flex items-center rounded-lg transition-colors mt-4",
              collapsed ? "justify-center p-3" : "px-3 py-2",
              location === "/settings"
                ? "bg-indigo-50 text-indigo-600"
                : "text-gray-600 hover:bg-gray-50"
            )}>
              <Settings className={cn("flex-shrink-0", collapsed ? "w-5 h-5" : "w-4 h-4 mr-3")} />
              {!collapsed && <span className="text-sm">Settings</span>}
            </span>
          </Link>
        </nav>
      </ScrollArea>
    </aside>
  );
}
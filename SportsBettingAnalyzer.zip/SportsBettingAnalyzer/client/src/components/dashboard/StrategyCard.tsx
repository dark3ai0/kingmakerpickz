import { useState } from "react";
import { 
  formatCurrency, 
  formatOdds, 
  formatDate, 
  formatTime, 
  formatPercent, 
  formatDecimal 
} from "@/lib/utils";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { placeBet } from "@/lib/api";
import { useBankroll } from "@/hooks/useBankroll";
import { type RecommendationWithEvent } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface StrategyCardProps {
  recommendation: RecommendationWithEvent;
}

export default function StrategyCard({ recommendation }: StrategyCardProps) {
  const { toast } = useToast();
  const { unitSize, bankroll } = useBankroll();
  const [isPlacingBet, setIsPlacingBet] = useState(false);
  
  const { event, strategyType, confidence, odds, value } = recommendation;
  
  // Determine card color based on strategy
  const getCardColors = () => {
    switch (strategyType) {
      case "moneyline":
        return {
          headerBg: "bg-gradient-to-r from-blue-600 to-blue-800",
          buttonBg: "bg-blue-600 hover:bg-blue-700",
          confidenceBg: "bg-blue-600",
          textColor: "text-blue-500"
        };
      case "spread":
        return {
          headerBg: "bg-gradient-to-r from-purple-600 to-purple-800",
          buttonBg: "bg-purple-600 hover:bg-purple-700",
          confidenceBg: "bg-purple-600",
          textColor: "text-purple-500"
        };
      case "total":
        return {
          headerBg: "bg-gradient-to-r from-emerald-600 to-emerald-800",
          buttonBg: "bg-emerald-600 hover:bg-emerald-700",
          confidenceBg: "bg-emerald-600",
          textColor: "text-emerald-500"
        };
      default:
        return {
          headerBg: "bg-gradient-to-r from-blue-600 to-blue-800",
          buttonBg: "bg-blue-600 hover:bg-blue-700",
          confidenceBg: "bg-blue-600",
          textColor: "text-blue-500"
        };
    }
  };
  
  const colors = getCardColors();
  
  // Format the label for the strategy card
  const getStrategyLabel = () => {
    switch (strategyType) {
      case "moneyline":
        return "Moneyline Strategy";
      case "spread":
        return "Against the Spread";
      case "total":
        return "Over/Under";
      default:
        return "Strategy";
    }
  };
  
  // Format the value label
  const getValueLabel = () => {
    if (confidence >= 75) return "Top Pick";
    if (confidence >= 65) return "Value Pick";
    return "High Value";
  };
  
  // Get odds change display
  const getOddsChange = () => {
    // For demo purposes, simulate a random change
    const change = Math.random() > 0.5 ? value : -value;
    const isPositive = change > 0;
    
    return (
      <div className={`text-xs ${isPositive ? "text-emerald-400" : "text-red-400"} flex items-center`}>
        <svg className="w-3 h-3 mr-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            strokeWidth="2" 
            d={isPositive 
              ? "M5 10l7-7m0 0l7 7m-7-7v18" 
              : "M19 14l-7 7m0 0l-7-7m7 7V3"
            }
          ></path>
        </svg>
        {Math.abs(change).toFixed(1)} {strategyType === "total" ? "" : "pts"}
      </div>
    );
  };
  
  // Bet placement mutation
  const betMutation = useMutation({
    mutationFn: () => {
      return placeBet(1, recommendation.id, unitSize, odds);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/1'] });
      toast({
        title: "Bet placed successfully",
        description: `Bet of ${formatCurrency(unitSize)} placed on ${recommendation.recommendation}`,
      });
      setIsPlacingBet(false);
    },
    onError: (error) => {
      toast({
        title: "Error placing bet",
        description: error.message,
        variant: "destructive"
      });
      setIsPlacingBet(false);
    }
  });
  
  const handlePlaceBet = () => {
    if (unitSize > bankroll) {
      toast({
        title: "Insufficient funds",
        description: "Your bankroll is too low to place this bet",
        variant: "destructive"
      });
      return;
    }
    
    setIsPlacingBet(true);
    betMutation.mutate();
  };
  
  return (
    <div className="bg-zinc-800 rounded-lg shadow-lg border border-zinc-700 overflow-hidden">
      <div className={`px-4 py-3 ${colors.headerBg} text-white flex justify-between items-center`}>
        <h3 className="font-medium">{getStrategyLabel()}</h3>
        <span className="text-xs py-1 px-2 bg-white bg-opacity-20 rounded-full">{getValueLabel()}</span>
      </div>
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="text-sm text-zinc-400">
              {event.sportId === 1 ? "NFL" : 
               event.sportId === 2 ? "NBA" : 
               event.sportId === 3 ? "MLB" : "NHL"} - {formatDate(event.startTime)}, {formatTime(event.startTime)}
            </span>
            <div className="mt-1">
              <div className="font-semibold text-white">{event.homeTeam}</div>
              <div className="text-zinc-400">vs {event.awayTeam}</div>
            </div>
          </div>
          <div className="flex flex-col items-end">
            <div className={`text-lg font-mono font-semibold ${colors.textColor}`}>
              {strategyType === "moneyline" 
                ? formatOdds(odds)
                : recommendation.recommendation}
            </div>
            {getOddsChange()}
          </div>
        </div>
        
        <div className="mb-3">
          <div className="flex justify-between items-center mb-1">
            <span className="text-sm font-medium text-zinc-300">Confidence</span>
            <span className={`text-sm font-bold ${colors.textColor}`}>
              {formatPercent(confidence)}
            </span>
          </div>
          <div className="confidence-indicator bg-zinc-700 h-2 rounded-full overflow-hidden">
            <div 
              className={`h-full ${colors.confidenceBg}`} 
              style={{ width: `${confidence}%` }}
            ></div>
          </div>
        </div>
        
        <div className="flex justify-between items-center mb-3">
          <div>
            <span className="text-sm text-zinc-400">
              {strategyType === "moneyline" ? "Implied Probability" : 
               strategyType === "spread" ? "Market Line" : "Market Total"}
            </span>
            <div className="font-mono font-medium text-zinc-200">
              {strategyType === "moneyline" 
                ? formatPercent(recommendation.event.odds?.moneylineHome 
                    ? (recommendation.event.odds.moneylineHome > 0 
                      ? 100 / (recommendation.event.odds.moneylineHome + 100) 
                      : Math.abs(recommendation.event.odds.moneylineHome) / (Math.abs(recommendation.event.odds.moneylineHome) + 100)) * 100
                    : 0)
                : strategyType === "spread" 
                  ? formatDecimal(recommendation.event.odds?.spreadHome || 0)
                  : formatDecimal(recommendation.event.odds?.totalPoints || 0)
              }
            </div>
          </div>
          <div>
            <span className="text-sm text-zinc-400">
              {strategyType === "moneyline" ? "Our Probability" : "Our Projection"}
            </span>
            <div className="font-mono font-medium text-zinc-200">
              {strategyType === "moneyline"
                ? formatPercent(confidence)
                : formatDecimal(
                    strategyType === "spread" 
                      ? (recommendation.event.odds?.spreadHome || 0) - value / 2 
                      : (recommendation.event.odds?.totalPoints || 0) - value
                  )
              }
            </div>
          </div>
        </div>
        
        <Button 
          className={`w-full py-2 ${colors.buttonBg} text-white rounded-md font-medium transition-colors`}
          onClick={handlePlaceBet}
          disabled={isPlacingBet || betMutation.isPending}
        >
          {isPlacingBet || betMutation.isPending ? "Placing Bet..." : "Place Bet"}
        </Button>
      </div>
    </div>
  );
}

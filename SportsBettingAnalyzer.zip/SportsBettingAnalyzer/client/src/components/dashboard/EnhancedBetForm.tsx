import { useState, useEffect } from "react";
import { Calendar, Clock, DollarSign, Star, Zap, BrainCircuit, BarChart4, Calendar as CalendarIcon, Clock as ClockIcon, CreditCard, Wallet, Bitcoin, Bell, AlertTriangle } from "lucide-react";
import { format, addDays, addHours, parseISO, isFuture } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { formatCurrency, formatOdds } from "@/lib/utils";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";

type BetSchedule = {
  isScheduled: boolean;
  scheduledDate: Date | null;
  reminderEnabled: boolean;
  reminderTime: string;
}

type BetEvent = {
  id: number;
  sportId: number;
  homeTeam: string;
  awayTeam: string;
  startTime: string;
  odds?: {
    moneylineHome: number | null;
    moneylineAway: number | null;
    spreadHome: number | null;
    spreadHomeOdds: number | null;
    spreadAway: number | null;
    spreadAwayOdds: number | null;
    totalPoints: number | null;
    totalOverOdds: number | null;
    totalUnderOdds: number | null;
  };
}

type PaymentMethod = {
  id: string;
  type: 'card' | 'crypto' | 'wallet';
  name: string;
  last4?: string;
  icon: React.ReactNode;
}

export default function EnhancedBetForm({ eventId, onClose }: { eventId?: number, onClose?: () => void }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [open, setOpen] = useState(true);
  const [amount, setAmount] = useState("50");
  const [betType, setBetType] = useState("moneyline");
  const [betSelection, setBetSelection] = useState("");
  const [confidenceLevel, setConfidenceLevel] = useState<number>(70);
  const [edgeValue, setEdgeValue] = useState<number>(5);
  const [useAiAnalysis, setUseAiAnalysis] = useState(true);
  const [aiInsight, setAiInsight] = useState<string | null>(null);
  const [aiInsightLoading, setAiInsightLoading] = useState(false);
  const [aiConfidenceScore, setAiConfidenceScore] = useState<number | null>(null);
  const [hasEdge, setHasEdge] = useState<boolean | null>(null);
  const [schedule, setSchedule] = useState<BetSchedule>({
    isScheduled: false,
    scheduledDate: addDays(new Date(), 1),
    reminderEnabled: false,
    reminderTime: "1hour"
  });
  
  const [paymentMethod, setPaymentMethod] = useState<string>("wallet");
  const [activePaymentTab, setActivePaymentTab] = useState<string>("crypto");
  
  // Mock payment methods
  const paymentMethods: Record<string, PaymentMethod[]> = {
    card: [
      { id: 'card1', type: 'card', name: 'Visa', last4: '4242', icon: <CreditCard className="w-4 h-4" /> },
      { id: 'card2', type: 'card', name: 'Mastercard', last4: '5678', icon: <CreditCard className="w-4 h-4" /> }
    ],
    crypto: [
      { id: 'btc', type: 'crypto', name: 'Bitcoin', icon: <Bitcoin className="w-4 h-4" /> },
      { id: 'eth', type: 'crypto', name: 'Ethereum', icon: <Wallet className="w-4 h-4" /> }
    ],
    wallet: [
      { id: 'wallet', type: 'wallet', name: 'Bankroll Balance', icon: <DollarSign className="w-4 h-4" /> }
    ]
  };

  // Fetch event details
  const { 
    data: event,
    isLoading: isEventLoading
  } = useQuery({
    queryKey: ['/api/events', eventId],
    enabled: !!eventId,
  });
  
  // Fetch user data
  const { 
    data: user,
    isLoading: isUserLoading
  } = useQuery({
    queryKey: ['/api/user/1'],
  });
  
  // Mutation for placing a bet
  const placeBetMutation = useMutation({
    mutationFn: (data: any) => {
      return apiRequest("POST", "/api/bets", data);
    },
    onSuccess: () => {
      toast({
        title: "Bet placed successfully",
        description: schedule.isScheduled 
          ? "Your bet has been scheduled" 
          : "Your bet has been placed",
      });
      queryClient.invalidateQueries({queryKey: ['/api/bets/user/1/details']});
      if (onClose) onClose();
      else setOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Error placing bet",
        description: "There was an error placing your bet. Please try again.",
        variant: "destructive",
      });
    }
  });
  
  // Generate AI insight when event and bet type/selection changes
  useEffect(() => {
    if (event && betType && betSelection && useAiAnalysis) {
      generateAiInsight();
    }
  }, [event, betType, betSelection, useAiAnalysis]);
  
  const generateAiInsight = async () => {
    if (!event) return;
    
    setAiInsightLoading(true);
    
    try {
      const response = await apiRequest("POST", "/api/analyze-bet", {
        event: `${event.homeTeam} vs ${event.awayTeam}`,
        betType,
        pick: betSelection
      });
      
      const data = await response.json();
      
      setAiInsight(data.analysis);
      setAiConfidenceScore(data.confidence);
      setHasEdge(data.confidence > 65);
      
      // Update suggested confidence level based on AI analysis
      setConfidenceLevel(data.confidence);
      setEdgeValue(Math.max(0, data.confidence - 60));
    } catch (error) {
      console.error("Error generating AI insight:", error);
      setAiInsight("Unable to generate AI insight at this time. Please try again later.");
      setAiConfidenceScore(null);
      setHasEdge(null);
    } finally {
      setAiInsightLoading(false);
    }
  };
  
  const handleBetTypeChange = (value: string) => {
    setBetType(value);
    setBetSelection(""); // Reset selection when bet type changes
  };
  
  const handleBetSelectionChange = (value: string) => {
    setBetSelection(value);
  };
  
  const getBetSelectionOptions = () => {
    if (!event || !event.odds) return [];
    
    switch (betType) {
      case "moneyline":
        return [
          { value: "home", label: `${event.homeTeam} (${formatOdds(event.odds.moneylineHome)})` },
          { value: "away", label: `${event.awayTeam} (${formatOdds(event.odds.moneylineAway)})` }
        ];
      case "spread":
        return [
          { 
            value: "home", 
            label: `${event.homeTeam} ${event.odds.spreadHome! > 0 ? '+' : ''}${event.odds.spreadHome} (${formatOdds(event.odds.spreadHomeOdds)})` 
          },
          { 
            value: "away", 
            label: `${event.awayTeam} ${event.odds.spreadAway! > 0 ? '+' : ''}${event.odds.spreadAway} (${formatOdds(event.odds.spreadAwayOdds)})` 
          }
        ];
      case "total":
        return [
          { 
            value: "over", 
            label: `Over ${event.odds.totalPoints} (${formatOdds(event.odds.totalOverOdds)})` 
          },
          { 
            value: "under", 
            label: `Under ${event.odds.totalPoints} (${formatOdds(event.odds.totalUnderOdds)})` 
          }
        ];
      default:
        return [];
    }
  };
  
  const getSelectedOdds = () => {
    if (!event || !event.odds || !betType || !betSelection) return null;
    
    switch (betType) {
      case "moneyline":
        return betSelection === "home" ? event.odds.moneylineHome : event.odds.moneylineAway;
      case "spread":
        return betSelection === "home" ? event.odds.spreadHomeOdds : event.odds.spreadAwayOdds;
      case "total":
        return betSelection === "over" ? event.odds.totalOverOdds : event.odds.totalUnderOdds;
      default:
        return null;
    }
  };
  
  const calculatePotentialWin = () => {
    const odds = getSelectedOdds();
    if (!odds || isNaN(parseFloat(amount))) return 0;
    
    const betAmount = parseFloat(amount);
    
    if (odds > 0) {
      return betAmount * (odds / 100);
    } else {
      return betAmount * (100 / Math.abs(odds));
    }
  };
  
  const handleSubmit = () => {
    if (!event || !betType || !betSelection || !amount) {
      toast({
        title: "Error",
        description: "Please fill out all required fields",
        variant: "destructive",
      });
      return;
    }
    
    const odds = getSelectedOdds();
    if (!odds) {
      toast({
        title: "Error",
        description: "Could not determine odds for selection",
        variant: "destructive",
      });
      return;
    }
    
    const betData = {
      userId: 1, // Hardcoded for demo
      eventId: event.id,
      amount: parseFloat(amount),
      odds,
      betType,
      pick: betSelection,
      confidenceLevel,
      useAiAnalysis,
      aiConfidenceScore: aiConfidenceScore || 0,
      isScheduled: schedule.isScheduled,
      scheduledDate: schedule.isScheduled ? schedule.scheduledDate : null,
      paymentMethod,
      potentialWin: calculatePotentialWin(),
      edgeValue,
      hasEdge: hasEdge || false
    };
    
    // Show schedule confirmation if bet is scheduled
    if (schedule.isScheduled) {
      toast({
        title: "Bet Scheduled",
        description: `Your bet will be placed on ${format(schedule.scheduledDate!, "MMMM d, yyyy")}`,
      });
      
      if (schedule.reminderEnabled) {
        toast({
          title: "Reminder Set",
          description: `You'll be notified ${schedule.reminderTime === "1hour" ? "1 hour" : "24 hours"} before the event`,
        });
      }
    }
    
    placeBetMutation.mutate(betData);
  };
  
  if (isEventLoading || isUserLoading) {
    return (
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-[550px] bg-slate-900 border-slate-800">
          <div className="space-y-4 py-4 flex justify-center items-center">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }
  
  const isValidBet = event && betType && betSelection && amount && parseFloat(amount) > 0;
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-[650px] bg-slate-900 border-slate-800 p-0 max-h-[90vh] overflow-hidden">
        <div className="flex flex-col h-full max-h-[90vh]">
          <DialogHeader className="px-6 pt-6 pb-2 bg-gradient-to-r from-slate-900 to-slate-800 border-b border-slate-800">
            <div className="flex justify-between items-center">
              <DialogTitle className="text-2xl font-bold text-slate-100 neon-text flex items-center">
                <Star className="h-5 w-5 mr-2 text-primary" />
                Edge Finder Bet System
              </DialogTitle>
              <Badge 
                variant="outline" 
                className={hasEdge ? "bg-green-900/30 text-green-400" : hasEdge === false ? "bg-red-900/30 text-red-400" : "bg-slate-800 text-slate-400"}
              >
                {hasEdge ? "Edge Detected" : hasEdge === false ? "No Edge" : "Analyzing..."}
              </Badge>
            </div>
            <DialogDescription className="text-slate-400">
              {event 
                ? `${event.homeTeam} vs ${event.awayTeam} - ${format(parseISO(event.startTime), "MMM d, yyyy")}`
                : "Select event to place bet"}
            </DialogDescription>
          </DialogHeader>
          
          <ScrollArea className="flex-1 px-6 overflow-y-auto">
            <div className="py-4 space-y-6">
              {/* AI Analysis Card */}
              {useAiAnalysis && (
                <Card className="border-slate-800 bg-slate-900/50">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center text-primary">
                      <BrainCircuit className="h-4 w-4 mr-2" />
                      DK's Genius Answer Bot Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {aiInsightLoading ? (
                      <div className="flex items-center space-x-2 text-sm text-slate-400">
                        <div className="animate-spin w-4 h-4 border-2 border-primary border-t-transparent rounded-full"></div>
                        <span>Analyzing odds and generating insights...</span>
                      </div>
                    ) : aiInsight ? (
                      <div className="space-y-2">
                        <p className="text-sm text-slate-300">{aiInsight}</p>
                        {aiConfidenceScore && (
                          <div className="mt-2">
                            <div className="flex justify-between mb-1">
                              <span className="text-xs text-slate-400">AI Confidence</span>
                              <span className="text-xs font-medium text-primary">{aiConfidenceScore}%</span>
                            </div>
                            <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                              <div 
                                className={`h-full ${
                                  aiConfidenceScore > 75 ? "bg-green-500" : 
                                  aiConfidenceScore > 60 ? "bg-yellow-500" : 
                                  "bg-red-500"
                                }`} 
                                style={{ width: `${aiConfidenceScore}%` }}
                              ></div>
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <p className="text-sm text-slate-400">Select a bet type and option to get AI insights</p>
                    )}
                  </CardContent>
                </Card>
              )}
              
              {/* Bet Options */}
              <div className="space-y-4">
                {/* Bet Type */}
                <div className="space-y-2">
                  <Label className="text-slate-300">Bet Type</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => handleBetTypeChange("moneyline")}
                      className={betType === "moneyline" 
                        ? "bg-primary hover:bg-primary/90 text-primary-foreground"
                        : "bg-slate-800 text-slate-300 hover:bg-slate-700 border-slate-700"}
                    >
                      Moneyline
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => handleBetTypeChange("spread")}
                      className={betType === "spread" 
                        ? "bg-primary hover:bg-primary/90 text-primary-foreground"
                        : "bg-slate-800 text-slate-300 hover:bg-slate-700 border-slate-700"}
                    >
                      Spread
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => handleBetTypeChange("total")}
                      className={betType === "total" 
                        ? "bg-primary hover:bg-primary/90 text-primary-foreground"
                        : "bg-slate-800 text-slate-300 hover:bg-slate-700 border-slate-700"}
                    >
                      Total
                    </Button>
                  </div>
                </div>
                
                {/* Bet Selection */}
                {betType && (
                  <div className="space-y-2">
                    <Label className="text-slate-300">Bet Selection</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {getBetSelectionOptions().map((option) => (
                        <Button
                          key={option.value}
                          type="button"
                          variant="outline"
                          onClick={() => handleBetSelectionChange(option.value)}
                          className={betSelection === option.value
                            ? "bg-primary hover:bg-primary/90 text-primary-foreground"
                            : "bg-slate-800 text-slate-300 hover:bg-slate-700 border-slate-700"}
                        >
                          {option.label}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Bet Amount */}
                <div className="space-y-2">
                  <Label className="text-slate-300">Bet Amount</Label>
                  <div className="flex space-x-2">
                    <Input
                      type="number"
                      min="5"
                      step="5"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="bg-slate-800 border-slate-700 text-slate-100"
                    />
                    <Button
                      onClick={() => setAmount("25")}
                      variant="outline"
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700"
                    >
                      $25
                    </Button>
                    <Button
                      onClick={() => setAmount("50")}
                      variant="outline"
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700"
                    >
                      $50
                    </Button>
                    <Button
                      onClick={() => setAmount("100")}
                      variant="outline"
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700"
                    >
                      $100
                    </Button>
                  </div>
                </div>
                
                {/* Edge Value Slider */}
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <Label className="text-slate-300">Edge Value</Label>
                    <span className="text-primary font-medium">{edgeValue}%</span>
                  </div>
                  <Slider 
                    defaultValue={[5]} 
                    max={20} 
                    step={1}
                    value={[edgeValue]}
                    onValueChange={(val) => setEdgeValue(val[0])}
                    className="cursor-pointer"
                  />
                  <p className="text-xs text-slate-400">Minimum edge required to place this bet automatically</p>
                </div>
                
                {/* Confidence Level */}
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <Label className="text-slate-300">Your Confidence Level</Label>
                    <span className="text-primary font-medium">{confidenceLevel}%</span>
                  </div>
                  <Slider 
                    defaultValue={[70]} 
                    max={100} 
                    step={1}
                    value={[confidenceLevel]}
                    onValueChange={(val) => setConfidenceLevel(val[0])}
                    className="cursor-pointer"
                  />
                </div>
                
                {/* Schedule Bet Options */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-slate-300 cursor-pointer" htmlFor="schedule-bet">
                      Schedule Bet
                    </Label>
                    <Switch 
                      id="schedule-bet" 
                      checked={schedule.isScheduled}
                      onCheckedChange={(checked) => setSchedule({...schedule, isScheduled: checked})}
                    />
                  </div>
                  
                  {schedule.isScheduled && (
                    <div className="pt-2 space-y-4 border-t border-slate-800">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <Label className="text-sm text-slate-400">Date</Label>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                variant="outline"
                                className="w-full justify-start text-left font-normal bg-slate-800 border-slate-700 text-slate-100"
                              >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {schedule.scheduledDate ? format(schedule.scheduledDate, 'PPP') : <span>Pick a date</span>}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0 bg-slate-900 border-slate-800">
                              {/* Calendar would go here - simplified for demo */}
                              <div className="p-3 bg-slate-900 space-y-3">
                                <Button 
                                  onClick={() => setSchedule({...schedule, scheduledDate: addDays(new Date(), 1)})}
                                  className="w-full justify-start text-left"
                                >
                                  Tomorrow
                                </Button>
                                <Button 
                                  onClick={() => setSchedule({...schedule, scheduledDate: addDays(new Date(), 2)})}
                                  className="w-full justify-start text-left"
                                >
                                  In 2 days
                                </Button>
                                <Button 
                                  onClick={() => setSchedule({...schedule, scheduledDate: addDays(new Date(), 7)})}
                                  className="w-full justify-start text-left"
                                >
                                  Next week
                                </Button>
                              </div>
                            </PopoverContent>
                          </Popover>
                        </div>
                        
                        <div className="space-y-1">
                          <Label className="text-sm text-slate-400">Set Reminder</Label>
                          <div className="flex items-center space-x-2">
                            <Switch
                              checked={schedule.reminderEnabled}
                              onCheckedChange={(checked) => setSchedule({...schedule, reminderEnabled: checked})}
                            />
                            
                            {schedule.reminderEnabled && (
                              <Select
                                value={schedule.reminderTime}
                                onValueChange={(value) => setSchedule({...schedule, reminderTime: value})}
                              >
                                <SelectTrigger className="w-full bg-slate-800 border-slate-700 text-slate-100">
                                  <SelectValue placeholder="Reminder Time" />
                                </SelectTrigger>
                                <SelectContent className="bg-slate-900 border-slate-800">
                                  <SelectItem value="1hour">1 hour before</SelectItem>
                                  <SelectItem value="24hours">24 hours before</SelectItem>
                                </SelectContent>
                              </Select>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                
                {/* AI Analysis Toggle */}
                <div className="flex items-center justify-between">
                  <Label className="text-slate-300 cursor-pointer" htmlFor="ai-analysis">
                    Use DK's Genius Bot Analysis
                  </Label>
                  <Switch 
                    id="ai-analysis" 
                    checked={useAiAnalysis}
                    onCheckedChange={setUseAiAnalysis}
                  />
                </div>
                
                {/* Payment Method Tabs */}
                <div className="space-y-3 pt-2">
                  <Label className="text-slate-300">Payment Method</Label>
                  <Tabs value={activePaymentTab} onValueChange={setActivePaymentTab} className="w-full">
                    <TabsList className="grid grid-cols-3 bg-slate-800">
                      <TabsTrigger value="wallet" className="data-[state=active]:bg-primary">Bankroll</TabsTrigger>
                      <TabsTrigger value="crypto" className="data-[state=active]:bg-primary">Crypto</TabsTrigger>
                      <TabsTrigger value="card" className="data-[state=active]:bg-primary">Card</TabsTrigger>
                    </TabsList>
                    
                    {Object.entries(paymentMethods).map(([tabKey, methods]) => (
                      <TabsContent key={tabKey} value={tabKey} className="pt-4 space-y-4">
                        <div className="grid gap-2">
                          {methods.map((method) => (
                            <div 
                              key={method.id}
                              className={`flex items-center justify-between p-3 rounded-md cursor-pointer border ${
                                paymentMethod === method.id 
                                  ? "border-primary bg-primary/10" 
                                  : "border-slate-800 bg-slate-800/50"
                              }`}
                              onClick={() => setPaymentMethod(method.id)}
                            >
                              <div className="flex items-center space-x-3">
                                <div className={`p-1.5 rounded-full ${paymentMethod === method.id ? "bg-primary/20" : "bg-slate-700"}`}>
                                  {method.icon}
                                </div>
                                <div>
                                  <p className="text-sm font-medium text-slate-200">{method.name}</p>
                                  {method.last4 && (
                                    <p className="text-xs text-slate-400">•••• {method.last4}</p>
                                  )}
                                  {method.id === 'wallet' && user && (
                                    <p className="text-xs text-slate-400">Balance: {formatCurrency(user.bankroll)}</p>
                                  )}
                                </div>
                              </div>
                              <div className={`w-4 h-4 rounded-full border-2 ${
                                paymentMethod === method.id 
                                  ? "border-primary bg-primary" 
                                  : "border-slate-600"
                              }`}></div>
                            </div>
                          ))}

                          <Button 
                            variant="outline" 
                            className="mt-2 border-dashed border-slate-700 bg-transparent hover:bg-slate-800/50 text-slate-400"
                          >
                            <span className="mr-2">+</span> Add New {activePaymentTab === 'card' ? 'Card' : activePaymentTab === 'crypto' ? 'Wallet' : 'Fund Source'}
                          </Button>
                        </div>
                      </TabsContent>
                    ))}
                  </Tabs>
                </div>
              </div>
              
              {/* Bet Summary */}
              {isValidBet && (
                <Card className="border-slate-800 bg-slate-800/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-slate-300">Bet Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-400">Event:</span>
                        <span className="text-slate-300 font-medium">{event.homeTeam} vs {event.awayTeam}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-400">Bet Type:</span>
                        <span className="text-slate-300 font-medium">{betType.charAt(0).toUpperCase() + betType.slice(1)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-400">Selection:</span>
                        <span className="text-slate-300 font-medium">
                          {betType === "moneyline" ? (betSelection === "home" ? event.homeTeam : event.awayTeam) :
                           betType === "spread" ? (betSelection === "home" ? `${event.homeTeam} ${event.odds!.spreadHome! > 0 ? '+' : ''}${event.odds!.spreadHome}` : `${event.awayTeam} ${event.odds!.spreadAway! > 0 ? '+' : ''}${event.odds!.spreadAway}`) :
                           betType === "total" ? (betSelection === "over" ? `Over ${event.odds!.totalPoints}` : `Under ${event.odds!.totalPoints}`) : 
                           ""}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-400">Odds:</span>
                        <span className="text-slate-300 font-medium">{formatOdds(getSelectedOdds()!)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-400">Amount:</span>
                        <span className="text-slate-300 font-medium">{formatCurrency(parseFloat(amount))}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-400">Potential Win:</span>
                        <span className="text-primary font-medium">{formatCurrency(calculatePotentialWin())}</span>
                      </div>
                      {hasEdge && (
                        <div className="flex justify-between text-sm pt-1 border-t border-slate-700 mt-1">
                          <span className="text-slate-400">Edge Value:</span>
                          <span className="text-green-400 font-medium">{edgeValue}%</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </ScrollArea>
          
          <DialogFooter className="px-6 py-4 border-t border-slate-800 bg-slate-900/50">
            <div className="flex justify-between w-full">
              <Button 
                variant="outline" 
                onClick={() => setOpen(false)}
                className="border-slate-700 text-slate-300 hover:bg-slate-800"
              >
                Cancel
              </Button>
              
              <div className="flex space-x-2">
                {hasEdge === false && (
                  <Button 
                    variant="outline" 
                    className="bg-slate-800 hover:bg-slate-700 text-amber-400 border-amber-900/60"
                    onClick={() => {
                      toast({
                        title: "Warning",
                        description: "This bet has no edge according to our analysis. We recommend finding a different bet.",
                        variant: "destructive",
                      });
                    }}
                  >
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    No Edge
                  </Button>
                )}

                <Button
                  onClick={handleSubmit}
                  disabled={!isValidBet || placeBetMutation.isPending}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  {placeBetMutation.isPending ? (
                    <>
                      <div className="animate-spin w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full mr-2"></div>
                      Processing...
                    </>
                  ) : schedule.isScheduled ? (
                    <>
                      <Calendar className="h-4 w-4 mr-2" />
                      Schedule Bet
                    </>
                  ) : (
                    <>
                      <Zap className="h-4 w-4 mr-2" />
                      Place Bet Now
                    </>
                  )}
                </Button>
              </div>
            </div>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}
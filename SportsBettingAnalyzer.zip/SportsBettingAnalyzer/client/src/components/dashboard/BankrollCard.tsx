import { useState } from "react";
import { formatCurrency } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter,
  DialogClose
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useBankroll } from "@/hooks/useBankroll";
import { TrendingUp, DollarSign, BarChart3 } from "lucide-react";

export default function BankrollCard() {
  const { 
    bankroll, 
    riskLevel, 
    unitSizePercent, 
    unitSize, 
    updateBankroll, 
    updateRiskLevel, 
    updateUnitSize,
    isLoading,
    isUpdating
  } = useBankroll();
  
  const [adjustDialogOpen, setAdjustDialogOpen] = useState(false);
  const [newBankroll, setNewBankroll] = useState("");
  
  // For demo purposes, show a small profit
  const profit = bankroll * 0.086;
  const profitPercent = 8.6;
  
  const handleRiskLevelChange = (level: string) => {
    updateRiskLevel(level);
  };
  
  const handleUnitSizeChange = (percent: number) => {
    updateUnitSize(percent);
  };
  
  const handleBankrollAdjust = () => {
    const amount = parseFloat(newBankroll);
    if (!isNaN(amount) && amount > 0) {
      updateBankroll(amount);
      setAdjustDialogOpen(false);
    }
  };

  const getRiskLevelButtonClass = (level: string) => {
    if (riskLevel === level) {
      return "bg-primary hover:bg-primary/90 text-primary-foreground neon-border";
    }
    return "bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700";
  };

  const getUnitSizeButtonClass = (percent: number) => {
    if (unitSizePercent === percent) {
      return "bg-primary hover:bg-primary/90 text-primary-foreground neon-border";
    }
    return "bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700";
  };
  
  return (
    <div className="neon-card rounded-lg border border-slate-800 bg-slate-900/80 overflow-hidden mb-4">
      <div className="px-4 py-3 bg-gradient-to-r from-slate-900 to-slate-800 border-b border-slate-800">
        <div className="flex items-center space-x-2">
          <BarChart3 className="h-5 w-5 text-primary pulse-effect" />
          <h3 className="font-semibold text-slate-100 neon-text">Bankroll Management</h3>
        </div>
      </div>
      <div className="p-4">
        <div className="flex justify-between items-center mb-4">
          <span className="text-sm text-slate-400">Current Bankroll</span>
          <span className="text-xl font-semibold font-mono text-primary neon-text">
            {isLoading ? "$0.00" : formatCurrency(bankroll)}
          </span>
        </div>
        
        <div className="mb-6">
          <div className="flex justify-between items-center mb-1">
            <span className="text-sm text-slate-400">Profit/Loss</span>
            <span className="text-sm font-medium text-green-400 flex items-center">
              <TrendingUp className="h-3 w-3 mr-1" />
              +{formatCurrency(profit)} ({profitPercent.toFixed(1)}%)
            </span>
          </div>
          <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
            <div className="progress-bar-glow h-full rounded-full" style={{ width: `${profitPercent}%` }}></div>
          </div>
        </div>
        
        <div className="mb-6">
          <div className="flex justify-between mb-2">
            <span className="text-sm text-slate-400">Risk Level</span>
            <span className="text-sm font-medium text-primary">
              {riskLevel ? riskLevel.charAt(0).toUpperCase() + riskLevel.slice(1) : "Moderate"}
            </span>
          </div>
          <div className="flex justify-between gap-2">
            <Button
              variant="outline"
              className={getRiskLevelButtonClass("low")}
              size="sm"
              onClick={() => handleRiskLevelChange("low")}
              disabled={isUpdating}
            >
              Low
            </Button>
            <Button
              variant="outline"
              className={getRiskLevelButtonClass("moderate")}
              size="sm"
              onClick={() => handleRiskLevelChange("moderate")}
              disabled={isUpdating}
            >
              Moderate
            </Button>
            <Button
              variant="outline"
              className={getRiskLevelButtonClass("high")}
              size="sm"
              onClick={() => handleRiskLevelChange("high")}
              disabled={isUpdating}
            >
              High
            </Button>
          </div>
        </div>
        
        <div className="mb-6">
          <div className="flex justify-between mb-2">
            <span className="text-sm text-slate-400">Unit Size ({unitSizePercent}%)</span>
            <span className="text-sm font-medium font-mono text-primary">{formatCurrency(unitSize)}</span>
          </div>
          <div className="flex justify-between gap-2">
            <Button
              variant="outline"
              className={getUnitSizeButtonClass(1)}
              size="sm"
              onClick={() => handleUnitSizeChange(1)}
              disabled={isUpdating}
            >
              1%
            </Button>
            <Button
              variant="outline"
              className={getUnitSizeButtonClass(2)}
              size="sm"
              onClick={() => handleUnitSizeChange(2)}
              disabled={isUpdating}
            >
              2%
            </Button>
            <Button
              variant="outline"
              className={getUnitSizeButtonClass(3)}
              size="sm"
              onClick={() => handleUnitSizeChange(3)}
              disabled={isUpdating}
            >
              3%
            </Button>
            <Button
              variant="outline"
              className={getUnitSizeButtonClass(5)}
              size="sm"
              onClick={() => handleUnitSizeChange(5)}
              disabled={isUpdating}
            >
              5%
            </Button>
          </div>
        </div>
        
        <Button 
          className="w-full py-2 bg-primary hover:bg-primary/90 text-primary-foreground rounded-md font-medium transition-colors"
          onClick={() => setAdjustDialogOpen(true)}
          disabled={isUpdating}
        >
          <DollarSign className="h-4 w-4 mr-1" />
          Adjust Bankroll
        </Button>
        
        {/* Bankroll Adjustment Dialog */}
        <Dialog open={adjustDialogOpen} onOpenChange={setAdjustDialogOpen}>
          <DialogContent className="bg-slate-900 border-slate-800">
            <DialogHeader>
              <DialogTitle className="text-primary neon-text">Adjust Bankroll</DialogTitle>
              <DialogDescription className="text-slate-400">
                Enter a new bankroll amount to update your account.
              </DialogDescription>
            </DialogHeader>
            
            <div className="py-4">
              <Label htmlFor="bankroll" className="text-slate-300">Bankroll Amount</Label>
              <Input
                id="bankroll"
                type="number"
                min="0"
                step="0.01"
                value={newBankroll}
                onChange={(e) => setNewBankroll(e.target.value)}
                placeholder="Enter new bankroll amount"
                className="mt-1 bg-slate-800 border-slate-700 text-slate-100"
              />
            </div>
            
            <DialogFooter>
              <DialogClose asChild>
                <Button variant="outline" className="border-slate-700 text-slate-300 hover:bg-slate-800">Cancel</Button>
              </DialogClose>
              <Button onClick={handleBankrollAdjust} className="bg-primary hover:bg-primary/90 text-primary-foreground">
                Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}

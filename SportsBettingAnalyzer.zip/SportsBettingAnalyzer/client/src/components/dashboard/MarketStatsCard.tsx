import { useState, useEffect } from 'react';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  BarChart,
  Bar,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";

// Define market data types
interface MarketDataPoint {
  date: string;
  value: number;
  volume?: number;
}

interface SportMetric {
  sport: string;
  data: MarketDataPoint[];
  change: number;
  current: number;
}

export default function MarketStatsCard() {
  // Define initial market data for different sports & metrics
  const [activeTab, setActiveTab] = useState('nfl');
  const [timeframe, setTimeframe] = useState('1w');
  
  // Generate simulated market data
  const generateMarketData = (days: number, trend: 'up' | 'down' | 'volatile', startValue: number): MarketDataPoint[] => {
    const data: MarketDataPoint[] = [];
    let value = startValue;
    
    // Generate a date string for n days ago
    const getDateString = (daysAgo: number) => {
      const date = new Date();
      date.setDate(date.getDate() - daysAgo);
      return `${date.getMonth() + 1}/${date.getDate()}`;
    };
    
    for (let i = days; i >= 0; i--) {
      // Generate random movement based on trend
      let change = 0;
      
      if (trend === 'up') {
        // Upward trend with some volatility
        change = (Math.random() * 0.08) - 0.02; // -2% to +8%
      } else if (trend === 'down') {
        // Downward trend with some volatility
        change = (Math.random() * 0.08) - 0.06; // -6% to +2%
      } else {
        // Highly volatile
        change = (Math.random() * 0.16) - 0.08; // -8% to +8%
      }
      
      // Apply change
      value = value * (1 + change);
      // Ensure value stays positive and reasonable
      value = Math.max(value, startValue * 0.6);
      value = Math.min(value, startValue * 1.4);
      
      // Add data point
      data.push({
        date: getDateString(i),
        value: parseFloat(value.toFixed(2)),
        volume: Math.floor(Math.random() * 1000) + 500
      });
    }
    
    return data;
  };
  
  // Generate data for different sports
  const [sportsMetrics, setSportsMetrics] = useState<Record<string, SportMetric>>({
    nfl: {
      sport: 'NFL',
      data: generateMarketData(30, 'up', 100),
      change: 8.7,
      current: 108.7
    },
    nba: {
      sport: 'NBA',
      data: generateMarketData(30, 'volatile', 100),
      change: -3.2,
      current: 96.8
    },
    mlb: {
      sport: 'MLB',
      data: generateMarketData(30, 'down', 100),
      change: -5.4,
      current: 94.6
    },
    nhl: {
      sport: 'NHL',
      data: generateMarketData(30, 'up', 100),
      change: 4.1,
      current: 104.1
    }
  });
  
  // Filter data based on timeframe
  const getFilteredData = (sportKey: string) => {
    const sport = sportsMetrics[sportKey];
    if (!sport) return [];
    
    const days = timeframe === '1d' ? 1 : timeframe === '1w' ? 7 : timeframe === '1m' ? 30 : 90;
    return sport.data.slice(-days - 1);
  };
  
  // Simulate occasional updates to the data
  useEffect(() => {
    const interval = setInterval(() => {
      setSportsMetrics(prev => {
        const newMetrics = { ...prev };
        
        // Randomly select a sport to update
        const sportKeys = Object.keys(newMetrics);
        const sportKey = sportKeys[Math.floor(Math.random() * sportKeys.length)];
        
        // Get the current sport data
        const sport = newMetrics[sportKey];
        
        // Add a new data point with slight change
        const lastValue = sport.data[sport.data.length - 1].value;
        const change = (Math.random() * 0.04) - 0.02; // -2% to +2%
        const newValue = parseFloat((lastValue * (1 + change)).toFixed(2));
        
        // Calculate new change percentage from start
        const startValue = 100; // Our starting baseline
        const newChangePercent = parseFloat(((newValue - startValue) / startValue * 100).toFixed(1));
        
        // Update the data
        sport.data = [...sport.data.slice(1), {
          date: sport.data[sport.data.length - 1].date,
          value: newValue,
          volume: Math.floor(Math.random() * 1000) + 500
        }];
        
        sport.change = newChangePercent;
        sport.current = newValue;
        
        return newMetrics;
      });
    }, 15000); // Update every 15 seconds
    
    return () => clearInterval(interval);
  }, []);
  
  // Get current metric
  const currentMetric = sportsMetrics[activeTab] || sportsMetrics.nfl;
  const filteredData = getFilteredData(activeTab);
  
  // Custom tooltip for recharts
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-zinc-900 border border-zinc-700 p-2 text-xs rounded shadow">
          <p className="font-bold">{label}</p>
          <p className="text-emerald-400">Value: {payload[0].value}</p>
          {payload[0].payload.volume && (
            <p className="text-blue-400">Volume: {payload[0].payload.volume}</p>
          )}
        </div>
      );
    }
    return null;
  };
  
  return (
    <Card className="bg-zinc-900/60 border-zinc-800 shadow-lg">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg text-zinc-200">Market Index</CardTitle>
          <div className="flex items-center space-x-2">
            <div className="text-xs bg-zinc-800 rounded-full px-2 py-0.5 text-zinc-400">LIVE</div>
            <div className={`text-sm font-mono font-semibold ${currentMetric.change >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {currentMetric.change >= 0 ? '+' : ''}{currentMetric.change}%
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="nfl" className="w-full" onValueChange={setActiveTab}>
          <div className="flex justify-between items-center mb-4">
            <TabsList className="bg-zinc-800">
              <TabsTrigger value="nfl" className="data-[state=active]:bg-zinc-700">NFL</TabsTrigger>
              <TabsTrigger value="nba" className="data-[state=active]:bg-zinc-700">NBA</TabsTrigger>
              <TabsTrigger value="mlb" className="data-[state=active]:bg-zinc-700">MLB</TabsTrigger>
              <TabsTrigger value="nhl" className="data-[state=active]:bg-zinc-700">NHL</TabsTrigger>
            </TabsList>
            
            <div className="flex text-xs rounded-md overflow-hidden border border-zinc-700">
              <Button 
                size="sm" 
                variant="ghost" 
                className={`px-2 py-1 h-auto ${timeframe === '1d' ? 'bg-zinc-700' : 'bg-zinc-800'}`}
                onClick={() => setTimeframe('1d')}
              >
                1D
              </Button>
              <Button 
                size="sm" 
                variant="ghost" 
                className={`px-2 py-1 h-auto ${timeframe === '1w' ? 'bg-zinc-700' : 'bg-zinc-800'}`}
                onClick={() => setTimeframe('1w')}
              >
                1W
              </Button>
              <Button 
                size="sm" 
                variant="ghost" 
                className={`px-2 py-1 h-auto ${timeframe === '1m' ? 'bg-zinc-700' : 'bg-zinc-800'}`}
                onClick={() => setTimeframe('1m')}
              >
                1M
              </Button>
              <Button 
                size="sm" 
                variant="ghost" 
                className={`px-2 py-1 h-auto ${timeframe === '3m' ? 'bg-zinc-700' : 'bg-zinc-800'}`}
                onClick={() => setTimeframe('3m')}
              >
                3M
              </Button>
            </div>
          </div>
          
          <TabsContent value="nfl" className="mt-0">
            <ResponsiveContainer width="100%" height={230}>
              <AreaChart data={filteredData} margin={{ top: 10, right: 10, left: -30, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis 
                  dataKey="date" 
                  tick={{ fill: '#71717a', fontSize: 10 }}
                  axisLine={{ stroke: '#3f3f46' }}
                  tickLine={{ stroke: '#3f3f46' }}
                />
                <YAxis 
                  domain={['dataMin - 5', 'dataMax + 5']} 
                  tick={{ fill: '#71717a', fontSize: 10 }}
                  axisLine={{ stroke: '#3f3f46' }}
                  tickLine={{ stroke: '#3f3f46' }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#10b981" 
                  fill="url(#colorValue)" 
                  strokeWidth={2}
                  dot={false}
                  activeDot={{ r: 5, fill: '#10b981', stroke: 'white', strokeWidth: 1 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </TabsContent>
          
          <TabsContent value="nba" className="mt-0">
            <ResponsiveContainer width="100%" height={230}>
              <LineChart data={filteredData} margin={{ top: 10, right: 10, left: -30, bottom: 0 }}>
                <XAxis 
                  dataKey="date" 
                  tick={{ fill: '#71717a', fontSize: 10 }}
                  axisLine={{ stroke: '#3f3f46' }}
                  tickLine={{ stroke: '#3f3f46' }}
                />
                <YAxis 
                  domain={['dataMin - 5', 'dataMax + 5']} 
                  tick={{ fill: '#71717a', fontSize: 10 }}
                  axisLine={{ stroke: '#3f3f46' }}
                  tickLine={{ stroke: '#3f3f46' }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Line 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#8b5cf6" 
                  strokeWidth={2}
                  dot={false}
                  activeDot={{ r: 5, fill: '#8b5cf6', stroke: 'white', strokeWidth: 1 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </TabsContent>
          
          <TabsContent value="mlb" className="mt-0">
            <ResponsiveContainer width="100%" height={230}>
              <AreaChart data={filteredData} margin={{ top: 10, right: 10, left: -30, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorValueMLB" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis 
                  dataKey="date" 
                  tick={{ fill: '#71717a', fontSize: 10 }}
                  axisLine={{ stroke: '#3f3f46' }}
                  tickLine={{ stroke: '#3f3f46' }}
                />
                <YAxis 
                  domain={['dataMin - 5', 'dataMax + 5']} 
                  tick={{ fill: '#71717a', fontSize: 10 }}
                  axisLine={{ stroke: '#3f3f46' }}
                  tickLine={{ stroke: '#3f3f46' }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#ef4444" 
                  fill="url(#colorValueMLB)" 
                  strokeWidth={2}
                  dot={false}
                  activeDot={{ r: 5, fill: '#ef4444', stroke: 'white', strokeWidth: 1 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </TabsContent>
          
          <TabsContent value="nhl" className="mt-0">
            <ResponsiveContainer width="100%" height={230}>
              <BarChart data={filteredData} margin={{ top: 10, right: 10, left: -30, bottom: 0 }}>
                <XAxis 
                  dataKey="date" 
                  tick={{ fill: '#71717a', fontSize: 10 }}
                  axisLine={{ stroke: '#3f3f46' }}
                  tickLine={{ stroke: '#3f3f46' }}
                />
                <YAxis 
                  domain={['dataMin - 5', 'dataMax + 5']} 
                  tick={{ fill: '#71717a', fontSize: 10 }}
                  axisLine={{ stroke: '#3f3f46' }}
                  tickLine={{ stroke: '#3f3f46' }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Bar 
                  dataKey="value" 
                  fill="#0ea5e9" 
                  radius={[4, 4, 0, 0]} 
                />
              </BarChart>
            </ResponsiveContainer>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
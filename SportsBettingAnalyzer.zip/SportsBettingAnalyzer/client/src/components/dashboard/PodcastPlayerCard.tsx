import { useState, useRef, useEffect, useCallback } from "react";
import { useMutation } from "@tanstack/react-query";
import { Mic, Play, Pause, Radio, SkipForward, Volume2, VolumeX } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function PodcastPlayerCard() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(80);
  const [podcastType, setPodcastType] = useState<"event" | "strategy" | "picks">("event");
  const [eventInput, setEventInput] = useState("");
  const [strategyInput, setStrategyInput] = useState("");
  const [analysisType, setAnalysisType] = useState<"preview" | "recap">("preview");
  const [currentScript, setCurrentScript] = useState("");
  const [liveMode, setLiveMode] = useState(false);
  const [liveText, setLiveText] = useState("");
  const [isLiveGenerating, setIsLiveGenerating] = useState(false);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { toast } = useToast();
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Create a reference to the Web Speech API
  const speechSynthesisRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Mutation for generating podcast for an event
  const eventPodcastMutation = useMutation({
    mutationFn: async (data: { event: string; type: 'preview' | 'recap' }) => {
      const response = await apiRequest("/api/podcast/event", { method: "POST", data });
      return response;
    },
    onSuccess: (data: any) => {
      setCurrentScript(data.script);
      toast({
        title: "Podcast Generated",
        description: "Your DK's KingMakerPickz podcast is ready to play!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate podcast. Please try again.",
        variant: "destructive"
      });
    }
  });

  // Mutation for generating podcast for top picks
  const topPicksPodcastMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("/api/podcast/top-picks");
      return response;
    },
    onSuccess: (data: any) => {
      setCurrentScript(data.script);
      toast({
        title: "Top Picks Generated",
        description: "DK's hot picks of the week are ready to play!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate top picks. Please try again.",
        variant: "destructive"
      });
    }
  });

  // Mutation for generating podcast for a strategy
  const strategyPodcastMutation = useMutation({
    mutationFn: async (data: { strategy: string }) => {
      const response = await apiRequest("/api/podcast/strategy", { method: "POST", data });
      return response;
    },
    onSuccess: (data: any) => {
      setCurrentScript(data.script);
      toast({
        title: "Strategy Podcast Generated",
        description: "Your strategy breakdown is ready to play!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate strategy podcast. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Mutation for live mode audio generation
  const livePodcastMutation = useMutation({
    mutationFn: async (data: { text: string; type: string }) => {
      // Make the API call based on the type
      let endpoint;
      let payload;
      
      if (data.type === 'event') {
        endpoint = "/api/podcast/event";
        payload = { event: data.text, type: analysisType };
      } else if (data.type === 'strategy') {
        endpoint = "/api/podcast/strategy";
        payload = { strategy: data.text };
      } else {
        return null;
      }
      
      const response = await apiRequest(endpoint, { method: "POST", data: payload });
      return response;
    },
    onSuccess: (data: any) => {
      if (data) {
        setLiveText(data.script);
        setIsLiveGenerating(false);
      }
    },
    onError: () => {
      setIsLiveGenerating(false);
    }
  });

  const handleGeneratePodcast = () => {
    switch (podcastType) {
      case "event":
        if (!eventInput.trim()) {
          toast({
            title: "Input Required",
            description: "Please enter an event to analyze.",
            variant: "destructive"
          });
          return;
        }
        eventPodcastMutation.mutate({ event: eventInput, type: analysisType });
        break;
      case "strategy":
        if (!strategyInput.trim()) {
          toast({
            title: "Input Required",
            description: "Please enter a strategy to analyze.",
            variant: "destructive"
          });
          return;
        }
        strategyPodcastMutation.mutate({ strategy: strategyInput });
        break;
      case "picks":
        topPicksPodcastMutation.mutate();
        break;
    }
  };

  const playPodcast = () => {
    // Determine which script to play - live text has priority if in live mode
    const textToPlay = liveMode && liveText ? liveText : currentScript;
    
    if (!textToPlay) {
      toast({
        title: "No Content",
        description: liveMode 
          ? "Type something to generate live audio!" 
          : "Generate a podcast first!",
        variant: "destructive"
      });
      return;
    }

    // Use Web Speech API for text-to-speech
    if (window.speechSynthesis) {
      // If already playing, stop current speech
      if (isPlaying) {
        window.speechSynthesis.cancel();
        setIsPlaying(false);
        return;
      }

      // Create a new speech synthesis utterance
      const utterance = new SpeechSynthesisUtterance(textToPlay);
      speechSynthesisRef.current = utterance;
      
      // Get available voices and try to select a male voice
      const voices = window.speechSynthesis.getVoices();
      const preferredVoice = voices.find(voice => 
        voice.name.includes('male') || voice.name.includes('Male')
      );
      
      // Set voice properties
      utterance.voice = preferredVoice || null;
      utterance.rate = 0.95; // Slightly slower than normal
      utterance.pitch = 1.0;
      utterance.volume = isMuted ? 0 : volume / 100;
      
      // Event handlers
      utterance.onend = () => {
        setIsPlaying(false);
      };
      
      // Play the audio
      window.speechSynthesis.cancel(); // Cancel any current speech first
      window.speechSynthesis.speak(utterance);
      setIsPlaying(true);
    } else {
      toast({
        title: "Not Supported",
        description: "Text-to-speech is not supported in your browser.",
        variant: "destructive"
      });
    }
  };

  const stopPodcast = () => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    }
  };

  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0];
    setVolume(newVolume);
    
    if (speechSynthesisRef.current) {
      speechSynthesisRef.current.volume = newVolume / 100;
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    
    if (speechSynthesisRef.current) {
      speechSynthesisRef.current.volume = !isMuted ? 0 : volume / 100;
    }
  };
  
  // Effect to handle live mode generation with debounce
  useEffect(() => {
    if (!liveMode) return;
    
    // Clear any existing timeouts
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    const currentInput = podcastType === 'event' ? eventInput : strategyInput;
    
    // Don't trigger for empty inputs or short inputs (less than 3 characters)
    if (!currentInput || currentInput.length < 3) {
      setLiveText("");
      return;
    }
    
    // Set a loading state
    setIsLiveGenerating(true);
    
    // Debounce the API call (wait 800ms before making a request)
    timeoutRef.current = setTimeout(() => {
      livePodcastMutation.mutate({ 
        text: currentInput, 
        type: podcastType === 'picks' ? 'strategy' : podcastType 
      });
    }, 800);
    
    // Cleanup function
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [
    liveMode, 
    podcastType, 
    eventInput, 
    strategyInput, 
    analysisType
  ]);
  
  // Effect to play live audio if live mode is on and text changes
  useEffect(() => {
    // We don't auto-play if the first part hasn't changed much, to avoid constant interruptions
    // Only play automatically if text is available and either:
    // 1. Nothing was playing before, or
    // 2. It's significantly different content (change is more than 50 characters from previous)
    const shouldAutoPlay = liveMode && 
                          liveText && 
                          window.speechSynthesis && 
                          (!isPlaying || (speechSynthesisRef.current && 
                                         Math.abs(liveText.length - speechSynthesisRef.current.text.length) > 50));
    
    if (shouldAutoPlay) {
      // Create a new speech synthesis utterance
      const utterance = new SpeechSynthesisUtterance(liveText);
      
      // Get available voices and try to select a male voice
      const voices = window.speechSynthesis.getVoices();
      const preferredVoice = voices.find(voice => 
        voice.name.includes('male') || voice.name.includes('Male')
      );
      
      // Set voice properties
      utterance.voice = preferredVoice || null;
      utterance.rate = 0.95;
      utterance.pitch = 1.0;
      utterance.volume = isMuted ? 0 : volume / 100;
      
      // Event handlers
      utterance.onend = () => {
        setIsPlaying(false);
      };
      
      // Stop any current speaking and play the new audio
      window.speechSynthesis.cancel();
      
      // Small delay to allow the cancel to complete
      setTimeout(() => {
        speechSynthesisRef.current = utterance;
        window.speechSynthesis.speak(utterance);
        setIsPlaying(true);
      }, 100);
    }
  }, [liveText, liveMode]);
  
  // Handle input changes with live mode support
  const handleEventInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEventInput(e.target.value);
    if (liveMode) {
      setCurrentScript(""); // Clear the regular script when in live mode
    }
  };
  
  const handleStrategyInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setStrategyInput(e.target.value);
    if (liveMode) {
      setCurrentScript(""); // Clear the regular script when in live mode
    }
  };
  
  const toggleLiveMode = () => {
    setLiveMode(!liveMode);
    if (!liveMode) {
      // Turning live mode on
      setCurrentScript("");  // Clear the regular script
      
      // Initial live generation if there's already input
      const currentInput = podcastType === 'event' ? eventInput : strategyInput;
      if (currentInput && currentInput.length >= 3) {
        setIsLiveGenerating(true);
        livePodcastMutation.mutate({ 
          text: currentInput, 
          type: podcastType === 'picks' ? 'strategy' : podcastType 
        });
      }
      
      toast({
        title: "Live Mode Activated",
        description: "Audio will generate as you type!",
      });
    } else {
      // Turning live mode off
      setLiveText("");
      if (isPlaying) {
        window.speechSynthesis.cancel();
        setIsPlaying(false);
      }
    }
  };

  return (
    <Card className="w-full shadow-lg border-0 bg-gradient-to-br from-slate-900/90 to-cyan-900/90 text-white">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-transparent bg-clip-text bg-gradient-to-r from-cyan-200 to-blue-300">
          <Mic className="h-5 w-5 text-cyan-300" />
          DK's KingMakerPickz Podcast
        </CardTitle>
        <CardDescription className="text-cyan-200/80">
          Listen to DK's hot takes and betting predictions
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-cyan-200">Generate Podcast</p>
            <div className="flex items-center space-x-2">
              <span className="text-xs text-cyan-300">Live Mode</span>
              <Switch 
                checked={liveMode}
                onCheckedChange={toggleLiveMode}
                className="data-[state=checked]:bg-cyan-500"
              />
              {liveMode && isLiveGenerating && (
                <span className="text-xs text-cyan-300 animate-pulse">Generating...</span>
              )}
            </div>
          </div>
          
          <Select
            value={podcastType}
            onValueChange={(value) => setPodcastType(value as any)}
          >
            <SelectTrigger className="bg-slate-800/50 border-cyan-700 text-cyan-100">
              <SelectValue placeholder="Select podcast type" />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 border-cyan-700 text-cyan-100">
              <SelectItem value="event">Event Analysis</SelectItem>
              <SelectItem value="strategy">Strategy Breakdown</SelectItem>
              <SelectItem value="picks">Top Picks of the Week</SelectItem>
            </SelectContent>
          </Select>
          
          {podcastType === "event" && (
            <div className="space-y-3">
              <Input
                className="bg-slate-800/50 border-cyan-700 text-cyan-100 placeholder:text-cyan-400/50"
                placeholder="Enter event (e.g. Lakers vs Warriors)"
                value={eventInput}
                onChange={handleEventInputChange}
              />
              
              <Select
                value={analysisType}
                onValueChange={(value) => setAnalysisType(value as any)}
              >
                <SelectTrigger className="bg-slate-800/50 border-cyan-700 text-cyan-100">
                  <SelectValue placeholder="Analysis type" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-cyan-700 text-cyan-100">
                  <SelectItem value="preview">Preview</SelectItem>
                  <SelectItem value="recap">Recap</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}
          
          {podcastType === "strategy" && (
            <Input
              className="bg-slate-800/50 border-cyan-700 text-cyan-100 placeholder:text-cyan-400/50"
              placeholder="Enter strategy (e.g. Moneyline, Over/Under)"
              value={strategyInput}
              onChange={handleStrategyInputChange}
            />
          )}
          
          <Button 
            className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white"
            onClick={handleGeneratePodcast}
            disabled={eventPodcastMutation.isPending || topPicksPodcastMutation.isPending || strategyPodcastMutation.isPending}
          >
            {eventPodcastMutation.isPending || topPicksPodcastMutation.isPending || strategyPodcastMutation.isPending
              ? "Generating Podcast..."
              : "Generate Podcast"}
          </Button>
        </div>
        
        <Separator className="bg-cyan-700/50" />
        
        {/* Display either live text or regular script */}
        {(liveMode && liveText) ? (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-cyan-200 flex items-center">
                <Radio className="h-4 w-4 mr-2 text-cyan-300" />
                Live Preview
              </h3>
              {isLiveGenerating && (
                <span className="text-xs text-cyan-300 animate-pulse">Updating...</span>
              )}
            </div>
            <div className="h-24 overflow-y-auto rounded bg-slate-800/40 p-2 text-sm text-cyan-100 border border-cyan-500/30">
              {liveText}
            </div>
          </div>
        ) : currentScript ? (
          <div className="space-y-3">
            <div className="h-24 overflow-y-auto rounded bg-slate-800/40 p-2 text-sm text-cyan-100">
              {currentScript}
            </div>
          </div>
        ) : null}
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              className="text-cyan-200 hover:text-white hover:bg-slate-700/50"
              onClick={isPlaying ? stopPodcast : playPodcast}
            >
              {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="text-cyan-200 hover:text-white hover:bg-slate-700/50"
              onClick={toggleMute}
            >
              {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
            </Button>
          </div>
          
          <div className="w-1/2">
            <Slider
              defaultValue={[80]}
              max={100}
              step={1}
              value={[volume]}
              onValueChange={handleVolumeChange}
              className="w-full"
            />
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="text-xs text-cyan-300/80 flex justify-between">
        <span>Powered by Gemini AI</span>
        {liveMode && (
          <span className="flex items-center">
            <Radio className="h-3 w-3 mr-1 text-cyan-500 animate-pulse" />
            Live Mode Active
          </span>
        )}
      </CardFooter>
    </Card>
  );
}
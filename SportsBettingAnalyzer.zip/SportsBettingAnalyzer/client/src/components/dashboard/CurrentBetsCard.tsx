import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  TicketIcon, 
  CheckCircle2, 
  XCircle, 
  Clock3, 
  Share2, 
  Twitter, 
  Facebook, 
  Copy, 
  Wallet,
  DollarSign,
  TrendingUp
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { formatCurrency } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";

export default function CurrentBetsCard() {
  const [activeTab, setActiveTab] = useState("active");
  const [selectedBet, setSelectedBet] = useState<any>(null);
  const [walletVisible, setWalletVisible] = useState(false);
  const { toast } = useToast();
  
  // Fetch user bets 
  const { data: bets = [], isLoading } = useQuery({
    queryKey: ['/api/bets/user/1/details'],
  });
  
  // Filter bets based on active tab
  const filteredBets = bets.filter((bet: any) => {
    if (activeTab === "active") return !bet.settled;
    if (activeTab === "settled") return bet.settled;
    return true; // "all" tab
  });
  
  const getStatusIcon = (bet: any) => {
    if (!bet.settled) return <Clock3 className="h-4 w-4 text-yellow-500 pulse-effect" />;
    return bet.status === "won" 
      ? <CheckCircle2 className="h-4 w-4 text-green-500" /> 
      : <XCircle className="h-4 w-4 text-red-500" />;
  };
  
  const getStatusColor = (bet: any) => {
    if (!bet.settled) return "bg-yellow-500/10 text-yellow-600";
    return bet.status === "won" 
      ? "bg-green-500/10 text-green-600" 
      : "bg-red-500/10 text-red-600";
  };

  const shareBet = (platform: string) => {
    if (!selectedBet) return;
    
    const betDetails = `Check out my bet on ${selectedBet.recommendation.event.homeTeam} vs ${selectedBet.recommendation.event.awayTeam}! #KingMakerPickz`;
    
    let shareUrl = '';
    switch (platform) {
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(betDetails)}`;
        break;
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}&quote=${encodeURIComponent(betDetails)}`;
        break;
      case 'copy':
        navigator.clipboard.writeText(betDetails).then(() => {
          toast({
            title: "Copied to clipboard",
            description: "Bet details copied to clipboard",
          });
        });
        return;
    }
    
    if (shareUrl) {
      window.open(shareUrl, '_blank', 'width=600,height=400');
    }
  };
  
  return (
    <Card className="neon-card border-slate-800 bg-slate-900/80">
      <CardHeader className="pb-2 bg-gradient-to-r from-slate-900 to-slate-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <TicketIcon className="h-5 w-5 text-primary pulse-effect" />
            <CardTitle className="text-lg font-semibold neon-text">Current Bets</CardTitle>
          </div>
          
          <div className="flex space-x-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setWalletVisible(!walletVisible)}
                    className="text-primary hover:text-primary/80 hover:bg-slate-800"
                  >
                    <Wallet className="h-5 w-5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Crypto Wallet</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full mt-2">
          <TabsList className="grid grid-cols-3 bg-slate-800">
            <TabsTrigger value="active" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Active</TabsTrigger>
            <TabsTrigger value="settled" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Settled</TabsTrigger>
            <TabsTrigger value="all" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">All</TabsTrigger>
          </TabsList>
        </Tabs>
        
        {walletVisible && (
          <div className="mt-3 p-3 rounded-lg border border-slate-700 bg-slate-800/50">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-slate-400">Crypto Wallet Balance:</span>
              <span className="font-mono text-primary font-bold neon-text">0.0345 BTC</span>
            </div>
            <div className="w-full h-2 bg-slate-700 rounded-full overflow-hidden">
              <div className="progress-bar-glow h-full rounded-full" style={{ width: '65%' }}></div>
            </div>
            <div className="flex justify-between mt-2">
              <span className="text-xs text-slate-500 flex items-center">
                <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
                +5.2% today
              </span>
              <Button variant="ghost" size="sm" className="h-6 text-xs text-primary">
                Deposit/Withdraw
              </Button>
            </div>
          </div>
        )}
      </CardHeader>
      
      <CardContent className="pt-4">
        {isLoading ? (
          <div className="space-y-3">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="flex items-center gap-4">
                <Skeleton className="h-12 w-12 rounded-md bg-slate-800" />
                <div className="space-y-2">
                  <Skeleton className="h-4 w-[200px] bg-slate-800" />
                  <Skeleton className="h-4 w-[160px] bg-slate-800" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredBets.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-6 text-center">
            <TicketIcon className="h-10 w-10 text-primary-400 mb-2" />
            <p className="text-slate-400">No bets found</p>
            <p className="text-sm text-slate-500">Place a bet to see it here</p>
          </div>
        ) : (
          <ScrollArea className="h-[240px] pr-4">
            <div className="space-y-3">
              {filteredBets.map((bet: any) => (
                <div 
                  key={bet.id} 
                  className="flex items-start p-3 rounded-lg border border-slate-800 bg-slate-800/30 hover:bg-slate-800/50 transition-colors"
                >
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-slate-200 neon-text">
                        {bet.recommendation.event.homeTeam} vs {bet.recommendation.event.awayTeam}
                      </h4>
                      <Badge variant="outline" className={`${getStatusColor(bet)}`}>
                        <span className="flex items-center gap-1">
                          {getStatusIcon(bet)}
                          {!bet.settled ? "Pending" : bet.status === "won" ? "Won" : "Lost"}
                        </span>
                      </Badge>
                    </div>
                    
                    <div className="flex justify-between mt-1 text-sm">
                      <div className="text-slate-300">
                        <span className="font-medium text-primary">{bet.recommendation.strategyType}:</span> {bet.recommendation.pick}
                      </div>
                      <div className="font-mono font-medium text-primary">
                        {formatCurrency(bet.amount)}
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center mt-1">
                      <div className="text-xs text-slate-500">
                        {new Date(bet.placedAt).toLocaleDateString()} 
                        <span className="mx-1">•</span> 
                        Odds: <span className="text-primary">{bet.odds > 0 ? `+${bet.odds}` : bet.odds}</span>
                      </div>
                      <div className="text-xs font-semibold text-primary">
                        Potential win: {formatCurrency(bet.potentialWin)}
                      </div>
                    </div>
                    
                    <div className="flex justify-end mt-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            className="h-7 text-xs text-slate-400 hover:text-primary"
                            onClick={() => setSelectedBet(bet)}
                          >
                            <Share2 className="h-3 w-3 mr-1" />
                            Share
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-md bg-slate-900 border-slate-800">
                          <DialogHeader>
                            <DialogTitle className="text-primary neon-text">Share your bet</DialogTitle>
                            <DialogDescription>
                              Post this bet to your social accounts or copy the link.
                            </DialogDescription>
                          </DialogHeader>
                          <div className="flex justify-center gap-4 py-4">
                            <Button
                              variant="outline"
                              size="icon"
                              className="rounded-full border-blue-500 hover:bg-blue-500/20"
                              onClick={() => shareBet('twitter')}
                            >
                              <Twitter className="h-4 w-4 text-blue-500" />
                            </Button>
                            <Button
                              variant="outline"
                              size="icon"
                              className="rounded-full border-blue-600 hover:bg-blue-600/20"
                              onClick={() => shareBet('facebook')}
                            >
                              <Facebook className="h-4 w-4 text-blue-600" />
                            </Button>
                            <Button
                              variant="outline"
                              size="icon"
                              className="rounded-full border-slate-600 hover:bg-slate-600/20"
                              onClick={() => shareBet('copy')}
                            >
                              <Copy className="h-4 w-4 text-slate-400" />
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
      
      <CardFooter className="flex justify-between border-t border-slate-800 pt-4">
        <div className="text-sm text-slate-500">
          {!isLoading && `Showing ${filteredBets.length} ${activeTab === "all" ? "total" : activeTab} bets`}
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          className="text-primary hover:text-primary/80 hover:bg-slate-800 border-slate-700"
        >
          <DollarSign className="h-3 w-3 mr-1" />
          View All History
        </Button>
      </CardFooter>
    </Card>
  );
}
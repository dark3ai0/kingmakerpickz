import { useState, useEffect, useRef } from 'react';
import { formatCurrency, formatPercent } from '@/lib/utils';
import { 
  Settings, 
  SlidersHorizontal, 
  X, 
  Filter, 
  Star, 
  Flame, 
  TrendingUp,
  ChevronUp,
  ChevronDown,
  Sparkles,
  Play,
  Pause
} from 'lucide-react';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger, 
  DropdownMenuSeparator,
  DropdownMenuLabel,
  DropdownMenuCheckboxItem
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

interface TickerItem {
  id: string;
  name: string;
  value: string;
  change: number;
  odds?: number;
  isHot?: boolean;
  sport: string;
  betType: string;
  player?: string;
  team?: string;
}

// Sports categories for filtering
const SPORTS = [
  { id: 'nfl', name: 'NFL', color: 'bg-blue-500' },
  { id: 'nba', name: 'NBA', color: 'bg-orange-500' },
  { id: 'mlb', name: 'MLB', color: 'bg-red-500' },
  { id: 'nhl', name: 'NHL', color: 'bg-sky-500' },
  { id: 'cfb', name: 'CFB', color: 'bg-purple-500' },
  { id: 'cbb', name: 'CBB', color: 'bg-indigo-500' },
  { id: 'epl', name: 'EPL', color: 'bg-emerald-500' },
  { id: 'mma', name: 'MMA', color: 'bg-rose-500' },
  { id: 'f1', name: 'F1', color: 'bg-gray-500' },
  { id: 'atp', name: 'ATP', color: 'bg-yellow-500' },
  { id: 'pga', name: 'PGA', color: 'bg-green-500' },
  { id: 'ufc', name: 'UFC', color: 'bg-red-600' }
];

// Bet types
const BET_TYPES = [
  { id: 'ml', name: 'Moneyline' },
  { id: 'spread', name: 'Spread' },
  { id: 'total', name: 'Total' },
  { id: 'prop', name: 'Prop' },
  { id: 'parlay', name: 'Parlay' },
  { id: 'future', name: 'Future' }
];

// Teams by sport for filtering
const TEAMS_BY_SPORT: Record<string, string[]> = {
  nfl: ['Chiefs', 'Eagles', 'Cowboys', 'Bills', '49ers', 'Ravens', 'Dolphins'],
  nba: ['Lakers', 'Celtics', 'Warriors', 'Bucks', 'Nuggets', 'Heat', 'Knicks'],
  mlb: ['Yankees', 'Dodgers', 'Red Sox', 'Braves', 'Astros', 'Cubs', 'Mets'],
  nhl: ['Maple Leafs', 'Rangers', 'Bruins', 'Golden Knights', 'Oilers', 'Panthers'],
  epl: ['Man City', 'Liverpool', 'Arsenal', 'Man United', 'Chelsea', 'Tottenham']
};

// Top players by sport for filtering
const PLAYERS_BY_SPORT: Record<string, string[]> = {
  nfl: ['Mahomes', 'Kelce', 'Burrow', 'Allen', 'Purdy', 'Jackson', 'Tagovailoa'],
  nba: ['James', 'Curry', 'Antetokounmpo', 'Jokic', 'Doncic', 'Embiid', 'Tatum'],
  mlb: ['Ohtani', 'Trout', 'Judge', 'Betts', 'Guerrero Jr', 'Acuña Jr', 'Cole'],
  nhl: ['McDavid', 'Matthews', 'MacKinnon', 'Kucherov', 'Draisaitl', 'Pastrnak'],
  pga: ['Scheffler', 'McIlroy', 'Rahm', 'Thomas', 'Koepka', 'Spieth', 'Morikawa']
};

export default function MarketTickerBar() {
  // Define sample ticker data
  const initialTickerData: TickerItem[] = [
    { id: "1", name: "NFL ML", value: "-110", change: 0.8, odds: -110, sport: "nfl", betType: "ml", team: "Chiefs" },
    { id: "2", name: "NBA SPRD", value: "+7.5", change: -1.2, odds: -115, sport: "nba", betType: "spread", team: "Lakers" },
    { id: "3", name: "MLB TOTAL", value: "O/U 8.5", change: 2.3, odds: -105, sport: "mlb", betType: "total", team: "Yankees" },
    { id: "4", name: "NHL ML", value: "+135", change: 5.5, odds: 135, isHot: true, sport: "nhl", betType: "ml", team: "Rangers" },
    { id: "5", name: "CFB SPRD", value: "-3.5", change: -0.5, odds: -110, sport: "cfb", betType: "spread" },
    { id: "6", name: "CBB ML", value: "-125", change: 1.2, odds: -125, sport: "cbb", betType: "ml" },
    { id: "7", name: "EPL", value: "+260", change: 8.2, odds: 260, isHot: true, sport: "epl", betType: "ml", team: "Liverpool" },
    { id: "8", name: "MMA", value: "-250", change: -3.1, odds: -250, sport: "mma", betType: "ml" },
    { id: "9", name: "F1", value: "+400", change: 12.5, odds: 400, isHot: true, sport: "f1", betType: "future" },
    { id: "10", name: "Mahomes TD", value: "O 2.5", change: 1.8, odds: -150, sport: "nfl", betType: "prop", player: "Mahomes", team: "Chiefs" },
    { id: "11", name: "Curry 3PT", value: "O 4.5", change: 2.2, odds: -120, sport: "nba", betType: "prop", player: "Curry", team: "Warriors" },
    { id: "12", name: "Judge HR", value: "+350", change: 5.4, odds: 350, sport: "mlb", betType: "prop", player: "Judge", team: "Yankees" },
    { id: "13", name: "PGA Open", value: "+120", change: 2.7, odds: 120, sport: "pga", betType: "future", player: "McIlroy" },
    { id: "14", name: "UFC 300", value: "-300", change: -5.2, odds: -300, sport: "ufc", betType: "ml" },
  ];

  const [tickerData, setTickerData] = useState<TickerItem[]>(initialTickerData);
  const [filteredData, setFilteredData] = useState<TickerItem[]>(initialTickerData);
  const [isPaused, setIsPaused] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [tickerSpeed, setTickerSpeed] = useState(60); // Animation duration in seconds
  
  // Filter states
  const [selectedSports, setSelectedSports] = useState<string[]>([]);
  const [selectedBetTypes, setSelectedBetTypes] = useState<string[]>([]);
  const [selectedTeams, setSelectedTeams] = useState<string[]>([]);
  const [selectedPlayers, setSelectedPlayers] = useState<string[]>([]);
  const [showHotOnly, setShowHotOnly] = useState(false);
  const [positiveChangeOnly, setPositiveChangeOnly] = useState(false);

  // Ticker customization
  const [showAlert, setShowAlert] = useState(true);
  const [showTickerItems, setShowTickerItems] = useState(true);
  const [showColors, setShowColors] = useState(true);
  const [tickerHeight, setTickerHeight] = useState(9); // Height in Tailwind units

  // For mobile screen size detection
  const [isMobile, setIsMobile] = useState(false);

  // Simulate live updates
  useEffect(() => {
    if (isPaused) return;

    const interval = setInterval(() => {
      setTickerData(prevData => {
        return prevData.map(item => {
          // Random change between -3% and 3%
          const changeModifier = (Math.random() * 6) - 3;
          const newChange = parseFloat((item.change + changeModifier / 10).toFixed(1));
          
          // Occasionally flip the hot status (10% chance)
          const shouldFlipHot = Math.random() < 0.1;
          
          return {
            ...item,
            change: newChange,
            isHot: shouldFlipHot ? !item.isHot : item.isHot
          };
        });
      });
    }, 5000); // Update every 5 seconds

    return () => clearInterval(interval);
  }, [isPaused]);

  // Apply filters when any filter or data changes
  useEffect(() => {
    let filtered = [...tickerData];
    
    if (selectedSports.length > 0) {
      filtered = filtered.filter(item => selectedSports.includes(item.sport));
    }
    
    if (selectedBetTypes.length > 0) {
      filtered = filtered.filter(item => selectedBetTypes.includes(item.betType));
    }
    
    if (selectedTeams.length > 0) {
      filtered = filtered.filter(item => item.team && selectedTeams.includes(item.team));
    }
    
    if (selectedPlayers.length > 0) {
      filtered = filtered.filter(item => item.player && selectedPlayers.includes(item.player));
    }
    
    if (showHotOnly) {
      filtered = filtered.filter(item => item.isHot);
    }
    
    if (positiveChangeOnly) {
      filtered = filtered.filter(item => item.change > 0);
    }
    
    setFilteredData(filtered);
  }, [
    tickerData, 
    selectedSports, 
    selectedBetTypes, 
    selectedTeams, 
    selectedPlayers, 
    showHotOnly, 
    positiveChangeOnly
  ]);

  // Detect mobile screen size
  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkScreenSize();
    window.addEventListener('resize', checkScreenSize);
    
    return () => window.removeEventListener('resize', checkScreenSize);
  }, []);

  // Format the ticker item display based on whether it's positive or negative
  const getTickerItemDisplay = (item: TickerItem, index: number) => {
    const isPositive = item.change > 0;
    const sport = SPORTS.find(s => s.id === item.sport);
    
    return (
      <div 
        key={`${item.id}-${index}`}
        className={`flex items-center space-x-2 sm:space-x-3 whitespace-nowrap mx-3 sm:mx-4 ${item.isHot ? 'animate-pulse' : ''}`}
      >
        {showColors && sport && (
          <div className={`h-2 w-2 rounded-full ${sport.color}`} />
        )}
        <span className="font-bold tracking-tight text-xs sm:text-sm">{item.name}</span>
        <span className="font-mono text-xs sm:text-sm">{item.value}</span>
        <span 
          className={`flex items-center text-xs sm:text-sm ${isPositive ? 'text-emerald-400' : 'text-red-400'}`}
        >
          <span className="mr-1">{isPositive ? '▲' : '▼'}</span>
          <span>{formatPercent(Math.abs(item.change))}</span>
        </span>
      </div>
    );
  };

  // Render random market insights
  const getMarketInsight = () => {
    const insights = [
      "Sharp money moving NFL lines",
      "Public heavily backing favorites",
      "MLB unders hitting at 62% this week",
      "Reverse line movement on NBA totals",
      "Heavy action on UFC underdogs",
      "EPL away teams showing value",
      "Predictive models favor home dogs",
      "Weather impacting NFL totals",
      "Key injuries affecting NBA lines",
      "Playoff odds shifting after upsets"
    ];
    
    return insights[Math.floor(Math.random() * insights.length)];
  };

  // Toggle sport selection
  const toggleSport = (sportId: string) => {
    setSelectedSports(prev => 
      prev.includes(sportId) 
        ? prev.filter(id => id !== sportId)
        : [...prev, sportId]
    );
  };

  // Toggle bet type selection
  const toggleBetType = (betTypeId: string) => {
    setSelectedBetTypes(prev => 
      prev.includes(betTypeId) 
        ? prev.filter(id => id !== betTypeId)
        : [...prev, betTypeId]
    );
  };

  // Toggle team selection
  const toggleTeam = (team: string) => {
    setSelectedTeams(prev => 
      prev.includes(team) 
        ? prev.filter(t => t !== team)
        : [...prev, team]
    );
  };

  // Toggle player selection
  const togglePlayer = (player: string) => {
    setSelectedPlayers(prev => 
      prev.includes(player) 
        ? prev.filter(p => p !== player)
        : [...prev, player]
    );
  };

  // Get all available teams from selected sports
  const getAvailableTeams = () => {
    if (selectedSports.length === 0) {
      return Object.values(TEAMS_BY_SPORT).flat();
    }
    
    return selectedSports
      .filter(sport => TEAMS_BY_SPORT[sport])
      .flatMap(sport => TEAMS_BY_SPORT[sport]);
  };

  // Get all available players from selected sports
  const getAvailablePlayers = () => {
    if (selectedSports.length === 0) {
      return Object.values(PLAYERS_BY_SPORT).flat();
    }
    
    return selectedSports
      .filter(sport => PLAYERS_BY_SPORT[sport])
      .flatMap(sport => PLAYERS_BY_SPORT[sport]);
  };

  // Get animation style based on ticker speed
  const getAnimationStyle = () => {
    return {
      animation: isPaused ? 'none' : `ticker ${tickerSpeed}s linear infinite`
    };
  };

  return (
    <div className={`bg-zinc-950 border-b border-zinc-800 overflow-hidden relative`}>
      <div className={`relative flex w-full h-${tickerHeight} items-center`}>
        {/* Left highlight */}
        <div className="absolute left-0 w-16 sm:w-20 bg-gradient-to-r from-zinc-950 to-transparent h-full z-10" />
        
        {/* Controls button */}
        <div className="absolute left-2 top-1/2 transform -translate-y-1/2 z-20">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-6 w-6 rounded-full bg-zinc-800/90 hover:bg-zinc-700/90 text-zinc-300"
              >
                <SlidersHorizontal className="h-3.5 w-3.5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent side="bottom" align="start" className="w-48 bg-zinc-900 border-zinc-700">
              <DropdownMenuLabel className="text-xs text-zinc-400">Ticker Controls</DropdownMenuLabel>
              
              <DropdownMenuItem 
                className="flex items-center justify-between cursor-pointer"
                onClick={() => setIsPaused(!isPaused)}
              >
                <span className="flex items-center">
                  {isPaused ? <Play className="h-4 w-4 mr-2" /> : <Pause className="h-4 w-4 mr-2" />}
                  {isPaused ? "Resume" : "Pause"}
                </span>
              </DropdownMenuItem>
              
              <DropdownMenuItem 
                className="flex items-center justify-between cursor-pointer"
                onClick={() => setShowSettings(true)}
              >
                <span className="flex items-center">
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </span>
              </DropdownMenuItem>
              
              <DropdownMenuSeparator className="bg-zinc-700" />
              <DropdownMenuLabel className="text-xs text-zinc-400">Filters</DropdownMenuLabel>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <div className="relative flex cursor-pointer select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none hover:bg-zinc-800 focus:bg-zinc-800">
                    <Filter className="h-4 w-4 mr-2" />
                    Sports ({selectedSports.length})
                    <ChevronUp className="ml-auto h-4 w-4" />
                  </div>
                </DropdownMenuTrigger>
                
                <DropdownMenuContent 
                  className="w-52 bg-zinc-900 border-zinc-700"
                  side="right"
                  sideOffset={-5}
                >
                  {SPORTS.map(sport => (
                    <DropdownMenuCheckboxItem
                      key={sport.id}
                      checked={selectedSports.includes(sport.id)}
                      onCheckedChange={() => toggleSport(sport.id)}
                    >
                      <div className="flex items-center">
                        <div className={`h-2 w-2 rounded-full ${sport.color} mr-2`} />
                        {sport.name}
                      </div>
                    </DropdownMenuCheckboxItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <div className="relative flex cursor-pointer select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none hover:bg-zinc-800 focus:bg-zinc-800">
                    <Filter className="h-4 w-4 mr-2" />
                    Bet Types ({selectedBetTypes.length})
                    <ChevronUp className="ml-auto h-4 w-4" />
                  </div>
                </DropdownMenuTrigger>
                
                <DropdownMenuContent 
                  className="w-52 bg-zinc-900 border-zinc-700"
                  side="right"
                  sideOffset={-5}
                >
                  {BET_TYPES.map(betType => (
                    <DropdownMenuCheckboxItem
                      key={betType.id}
                      checked={selectedBetTypes.includes(betType.id)}
                      onCheckedChange={() => toggleBetType(betType.id)}
                    >
                      {betType.name}
                    </DropdownMenuCheckboxItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
              
              <DropdownMenuSeparator className="bg-zinc-700" />
              
              {/* Hot items toggle */}
              <div className="flex items-center justify-between px-2 py-1.5">
                <span className="flex items-center text-sm">
                  <Flame className="h-4 w-4 mr-2 text-orange-500" />
                  Hot Items
                </span>
                <Switch
                  checked={showHotOnly}
                  onCheckedChange={setShowHotOnly}
                  className="ml-auto"
                />
              </div>
              
              {/* Positive change toggle */}
              <div className="flex items-center justify-between px-2 py-1.5">
                <span className="flex items-center text-sm">
                  <TrendingUp className="h-4 w-4 mr-2 text-emerald-500" />
                  Positive Change
                </span>
                <Switch
                  checked={positiveChangeOnly}
                  onCheckedChange={setPositiveChangeOnly}
                  className="ml-auto"
                />
              </div>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        {/* Market Alert - only show if enabled */}
        {showAlert && (
          <div className="bg-emerald-500/10 border-r border-emerald-500/30 text-emerald-400 font-medium px-2 sm:px-4 h-full hidden sm:flex items-center whitespace-nowrap z-20">
            <span className="mr-2 text-xs font-bold tracking-wide uppercase">ALERT</span>
            <span className="text-xs sm:text-sm">{getMarketInsight()}</span>
          </div>
        )}
        
        {/* Scrolling ticker - only show if enabled */}
        {showTickerItems && (
          <div className={`ticker-wrap overflow-hidden flex-1 h-full ${showAlert ? 'ml-8 sm:ml-0' : 'ml-10 sm:ml-12'}`}>
            <div className="ticker flex items-center h-full" style={getAnimationStyle()}>
              {filteredData.length > 0 ? (
                <>
                  {filteredData.map((item, index) => getTickerItemDisplay(item, index))}
                  {/* Duplicate for seamless loop */}
                  {filteredData.map((item, index) => getTickerItemDisplay(item, index))}
                </>
              ) : (
                <div className="flex items-center space-x-3 mx-4 text-zinc-500">
                  No items match your filter criteria
                </div>
              )}
            </div>
          </div>
        )}
        
        {/* Right highlight */}
        <div className="absolute right-0 w-16 sm:w-20 bg-gradient-to-l from-zinc-950 to-transparent h-full z-10" />
      </div>
      
      {/* CSS for ticker animation */}
      <style>
        {`
          @keyframes ticker {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
          }
          
          .ticker-wrap:hover .ticker {
            animation-play-state: paused;
          }
        `}
      </style>
      
      {/* Settings Dialog */}
      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent className="bg-zinc-900 border-zinc-700 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center">
              <Settings className="h-4 w-4 mr-2" />
              Ticker Configuration
            </DialogTitle>
            <DialogDescription>
              Customize the market ticker bar appearance and behavior
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-5 py-2">
            {/* Speed Control */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm text-zinc-300 flex items-center">
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Ticker Speed
                </span>
                <span className="text-sm font-medium text-white">{tickerSpeed}s</span>
              </div>
              <Slider
                value={[tickerSpeed]}
                onValueChange={(value) => setTickerSpeed(value[0])}
                max={120}
                min={20}
                step={10}
                className="[&>span]:bg-emerald-500"
              />
              <p className="text-xs text-zinc-500">
                Adjust how fast the ticker scrolls (lower is faster)
              </p>
            </div>
            
            {/* Height Control */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm text-zinc-300">Ticker Height</span>
                <span className="text-sm font-medium text-white">{tickerHeight}</span>
              </div>
              <Slider
                value={[tickerHeight]}
                onValueChange={(value) => setTickerHeight(value[0])}
                max={12}
                min={6}
                step={1}
                className="[&>span]:bg-emerald-500"
              />
            </div>
            
            {/* Display Options */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-white">Display Options</h3>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-zinc-300">Show Alert Section</span>
                <Switch
                  checked={showAlert}
                  onCheckedChange={setShowAlert}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-zinc-300">Show Ticker Items</span>
                <Switch
                  checked={showTickerItems}
                  onCheckedChange={setShowTickerItems}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-zinc-300">Show Sport Colors</span>
                <Switch
                  checked={showColors}
                  onCheckedChange={setShowColors}
                />
              </div>
            </div>
            
            {/* Advanced Filters */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-white">Advanced Filters</h3>
              
              {/* Teams */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-zinc-300">Teams ({selectedTeams.length})</span>
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="h-7 text-xs border-zinc-700 hover:bg-zinc-800"
                    onClick={() => setSelectedTeams([])}
                  >
                    Clear
                  </Button>
                </div>
                <div className="flex flex-wrap gap-1">
                  {getAvailableTeams().slice(0, 10).map(team => (
                    <Badge
                      key={team}
                      variant={selectedTeams.includes(team) ? "default" : "outline"}
                      className={selectedTeams.includes(team) 
                        ? "bg-cyan-800 hover:bg-cyan-700 border-none cursor-pointer"
                        : "border-zinc-700 hover:bg-zinc-800 cursor-pointer"}
                      onClick={() => toggleTeam(team)}
                    >
                      {team}
                    </Badge>
                  ))}
                  {getAvailableTeams().length > 10 && (
                    <Badge variant="outline" className="border-zinc-700">
                      +{getAvailableTeams().length - 10} more
                    </Badge>
                  )}
                </div>
              </div>
              
              {/* Players */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-zinc-300">Players ({selectedPlayers.length})</span>
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="h-7 text-xs border-zinc-700 hover:bg-zinc-800"
                    onClick={() => setSelectedPlayers([])}
                  >
                    Clear
                  </Button>
                </div>
                <div className="flex flex-wrap gap-1">
                  {getAvailablePlayers().slice(0, 10).map(player => (
                    <Badge
                      key={player}
                      variant={selectedPlayers.includes(player) ? "default" : "outline"}
                      className={selectedPlayers.includes(player) 
                        ? "bg-purple-800 hover:bg-purple-700 border-none cursor-pointer"
                        : "border-zinc-700 hover:bg-zinc-800 cursor-pointer"}
                      onClick={() => togglePlayer(player)}
                    >
                      {player}
                    </Badge>
                  ))}
                  {getAvailablePlayers().length > 10 && (
                    <Badge variant="outline" className="border-zinc-700">
                      +{getAvailablePlayers().length - 10} more
                    </Badge>
                  )}
                </div>
              </div>
            </div>
            
            {/* Reset and Apply Buttons */}
            <div className="flex justify-between pt-2">
              <Button
                variant="outline"
                className="border-zinc-700 hover:bg-zinc-800"
                onClick={() => {
                  setSelectedSports([]);
                  setSelectedBetTypes([]);
                  setSelectedTeams([]);
                  setSelectedPlayers([]);
                  setShowHotOnly(false);
                  setPositiveChangeOnly(false);
                  setTickerSpeed(60);
                  setTickerHeight(9);
                  setShowAlert(true);
                  setShowTickerItems(true);
                  setShowColors(true);
                  setIsPaused(false);
                }}
              >
                Reset All
              </Button>
              
              <Button
                className="bg-emerald-600 hover:bg-emerald-700"
                onClick={() => setShowSettings(false)}
              >
                Apply Changes
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
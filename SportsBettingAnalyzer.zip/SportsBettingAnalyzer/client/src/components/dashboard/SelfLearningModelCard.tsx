import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { 
  Brain, 
  LineChart, 
  BarChart3, 
  RefreshCw, 
  RotateCw, 
  Target,
  Check,
  Badge,
  XCircle,
  Zap
} from "lucide-react";
import { CustomProgress } from "@/components/ui/custom-progress";

interface ModelWeight {
  sportId: number;
  betType: string;
  accuracy: number;
  sampleSize: number;
  lastUpdated: Date;
  // Additional weights
  intercept: number;
  homeOddsWeight: number;
  awayOddsWeight: number;
  spreadWeight: number;
  totalPointsWeight: number;
  previousWinsWeight: number;
  avgPointsWeight: number;
  seasonWeight: number;
  weatherWeight: number;
  formWeight: number;
  restDaysWeight: number;
  rivalryWeight: number;
}

interface SportWeights {
  [betType: string]: ModelWeight;
}

interface AllWeights {
  [sportId: string]: SportWeights;
}

interface SelfLearningModelCardProps {
  onClose?: () => void;
}

export default function SelfLearningModelCard({ onClose }: SelfLearningModelCardProps) {
  const [isTraining, setIsTraining] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedSport, setSelectedSport] = useState(2); // Default to NBA (id: 2)
  const [selectedBetType, setSelectedBetType] = useState("moneyline");
  
  // Model weights state
  const [modelWeights, setModelWeights] = useState<AllWeights | null>(null);
  const [trainingResult, setTrainingResult] = useState<string | null>(null);
  const [accuracy, setAccuracy] = useState<number>(0);
  const [edgeBets, setEdgeBets] = useState<any[]>([]);
  
  // Feature importance toggles
  const [featureImportance, setFeatureImportance] = useState({
    odds: true,
    spread: true,
    total: true,
    teamStats: true,
    seasonality: false,
    weather: false,
    form: true,
    rest: true,
    rivalry: false
  });
  
  // Confidence threshold
  const [confidenceThreshold, setConfidenceThreshold] = useState([65]);
  
  // Handle loading the model weights
  const loadModelWeights = async () => {
    try {
      const response = await apiRequest("GET", "/api/self-learning/weights");
      const data = await response.json();
      setModelWeights(data.weights);
      
      // Set initial accuracy from weights
      if (data.weights && data.weights[selectedSport] && data.weights[selectedSport][selectedBetType]) {
        setAccuracy(data.weights[selectedSport][selectedBetType].accuracy * 100);
      }
    } catch (error) {
      console.error("Failed to load model weights:", error);
      toast({
        title: "Error",
        description: "Failed to load model weights",
        variant: "destructive"
      });
    }
  };
  
  // Handle training the model
  const trainModel = async () => {
    setIsTraining(true);
    try {
      const response = await apiRequest("POST", "/api/self-learning/train", {
        userId: 1 // Default user ID
      });
      const data = await response.json();
      
      if (data.success) {
        setModelWeights(data.updatedWeights);
        setTrainingResult(data.message);
        
        // Update accuracy
        if (data.updatedWeights && 
            data.updatedWeights[selectedSport] && 
            data.updatedWeights[selectedSport][selectedBetType]) {
          setAccuracy(data.updatedWeights[selectedSport][selectedBetType].accuracy * 100);
        }
        
        toast({
          title: "Training Complete",
          description: data.message,
        });
      } else {
        setTrainingResult(data.message);
        toast({
          title: "Training Issue",
          description: data.message,
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Failed to train model:", error);
      toast({
        title: "Error",
        description: "Failed to train the model",
        variant: "destructive"
      });
    } finally {
      setIsTraining(false);
    }
  };
  
  // Handle generating edge bets
  const generateEdgeBets = async () => {
    setIsGenerating(true);
    try {
      const response = await apiRequest("GET", "/api/self-learning/edge-bets");
      const data = await response.json();
      setEdgeBets(data);
      
      toast({
        title: "Edge Bets Generated",
        description: `Generated ${data.length} edge bets`,
      });
    } catch (error) {
      console.error("Failed to generate edge bets:", error);
      toast({
        title: "Error",
        description: "Failed to generate edge bets",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };
  
  // Handle resetting model weights
  const resetWeights = async () => {
    try {
      const response = await apiRequest("POST", "/api/self-learning/reset", {
        sportId: selectedSport,
        betType: selectedBetType
      });
      const data = await response.json();
      
      if (data.success) {
        // Reload weights
        loadModelWeights();
        
        toast({
          title: "Weights Reset",
          description: data.message,
        });
      } else {
        toast({
          title: "Reset Failed",
          description: data.message,
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Failed to reset weights:", error);
      toast({
        title: "Error",
        description: "Failed to reset the model weights",
        variant: "destructive"
      });
    }
  };
  
  // Load weights on initial render
  useState(() => {
    loadModelWeights();
  });
  
  // Get current weights for selected sport/bet type
  const currentWeights = modelWeights && 
    modelWeights[selectedSport] && 
    modelWeights[selectedSport][selectedBetType];
  
  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[900px] bg-zinc-900 border-zinc-700">
        <DialogHeader>
          <DialogTitle className="text-xl text-white flex items-center">
            <Brain className="h-5 w-5 mr-2 text-purple-400" />
            Self-Learning Prediction Model
          </DialogTitle>
          <DialogDescription className="text-zinc-400">
            Advanced machine learning model that learns from past betting results to improve prediction accuracy.
          </DialogDescription>
        </DialogHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
          <TabsList className="bg-zinc-800 border border-zinc-700">
            <TabsTrigger value="overview" className="data-[state=active]:bg-purple-900/40 data-[state=active]:text-white">
              Overview
            </TabsTrigger>
            <TabsTrigger value="training" className="data-[state=active]:bg-purple-900/40 data-[state=active]:text-white">
              Training & Parameters
            </TabsTrigger>
            <TabsTrigger value="predictions" className="data-[state=active]:bg-purple-900/40 data-[state=active]:text-white">
              Edge Predictions
            </TabsTrigger>
          </TabsList>
          
          {/* Overview Tab */}
          <TabsContent value="overview" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Accuracy Card */}
              <Card className="bg-zinc-800 border-zinc-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-white">Model Accuracy</CardTitle>
                  <CardDescription>Current prediction accuracy by sport and bet type</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-5">
                    <div className="flex justify-between">
                      <div className="space-y-1">
                        <div className="text-sm text-zinc-400">Sport</div>
                        <div className="flex space-x-2">
                          <Button 
                            variant={selectedSport === 1 ? "default" : "outline"} 
                            size="sm" 
                            onClick={() => setSelectedSport(1)}
                            className={selectedSport === 1 ? "bg-purple-700 hover:bg-purple-800" : "border-zinc-700"}
                          >
                            NFL
                          </Button>
                          <Button 
                            variant={selectedSport === 2 ? "default" : "outline"} 
                            size="sm" 
                            onClick={() => setSelectedSport(2)}
                            className={selectedSport === 2 ? "bg-purple-700 hover:bg-purple-800" : "border-zinc-700"}
                          >
                            NBA
                          </Button>
                        </div>
                      </div>
                      
                      <div className="space-y-1">
                        <div className="text-sm text-zinc-400">Bet Type</div>
                        <div className="flex space-x-2">
                          <Button 
                            variant={selectedBetType === "moneyline" ? "default" : "outline"} 
                            size="sm" 
                            onClick={() => setSelectedBetType("moneyline")}
                            className={selectedBetType === "moneyline" ? "bg-purple-700 hover:bg-purple-800" : "border-zinc-700"}
                          >
                            Moneyline
                          </Button>
                          <Button 
                            variant={selectedBetType === "spread" ? "default" : "outline"} 
                            size="sm" 
                            onClick={() => setSelectedBetType("spread")}
                            className={selectedBetType === "spread" ? "bg-purple-700 hover:bg-purple-800" : "border-zinc-700"}
                          >
                            Spread
                          </Button>
                          <Button 
                            variant={selectedBetType === "total" ? "default" : "outline"} 
                            size="sm" 
                            onClick={() => setSelectedBetType("total")}
                            className={selectedBetType === "total" ? "bg-purple-700 hover:bg-purple-800" : "border-zinc-700"}
                          >
                            Total
                          </Button>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm text-zinc-300">Prediction Accuracy</span>
                        <span className="text-sm font-semibold text-white">
                          {currentWeights ? (currentWeights.accuracy * 100).toFixed(1) : "0"}%
                        </span>
                      </div>
                      <CustomProgress 
                        value={currentWeights ? currentWeights.accuracy * 100 : 0} 
                        className="h-2 bg-zinc-700"
                        indicatorClassName="bg-gradient-to-r from-purple-600 to-indigo-500"
                      />
                      
                      <div className="flex justify-between">
                        <span className="text-sm text-zinc-300">Sample Size</span>
                        <span className="text-sm font-semibold text-white">
                          {currentWeights ? currentWeights.sampleSize : "0"} bets
                        </span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span className="text-sm text-zinc-300">Last Updated</span>
                        <span className="text-sm font-semibold text-white">
                          {currentWeights ? new Date(currentWeights.lastUpdated).toLocaleDateString() : "Never"}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Feature Importance Card */}
              <Card className="bg-zinc-800 border-zinc-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-white">Feature Importance</CardTitle>
                  <CardDescription>Impact of each feature on model predictions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {currentWeights && (
                      <>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-zinc-300">Odds</span>
                          <CustomProgress 
                            value={(currentWeights.homeOddsWeight + currentWeights.awayOddsWeight) * 100} 
                            className="h-2 w-48 bg-zinc-700"
                            indicatorClassName="bg-purple-500"
                          />
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-zinc-300">Spread</span>
                          <CustomProgress 
                            value={currentWeights.spreadWeight * 100} 
                            className="h-2 w-48 bg-zinc-700"
                            indicatorClassName="bg-indigo-500"
                          />
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-zinc-300">Total Points</span>
                          <CustomProgress 
                            value={currentWeights.totalPointsWeight * 100} 
                            className="h-2 w-48 bg-zinc-700"
                            indicatorClassName="bg-blue-500"
                          />
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-zinc-300">Team Stats</span>
                          <CustomProgress 
                            value={(currentWeights.previousWinsWeight + currentWeights.avgPointsWeight) * 100} 
                            className="h-2 w-48 bg-zinc-700"
                            indicatorClassName="bg-cyan-500"
                          />
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-zinc-300">Form</span>
                          <CustomProgress 
                            value={currentWeights.formWeight * 100} 
                            className="h-2 w-48 bg-zinc-700"
                            indicatorClassName="bg-teal-500"
                          />
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-zinc-300">Rest Days</span>
                          <CustomProgress 
                            value={currentWeights.restDaysWeight * 100} 
                            className="h-2 w-48 bg-zinc-700"
                            indicatorClassName="bg-green-500"
                          />
                        </div>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              {/* Actions */}
              <div className="md:col-span-2 space-y-4">
                <Card className="bg-zinc-800 border-zinc-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg text-white">AI Model Actions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-3">
                      <Button 
                        onClick={trainModel} 
                        disabled={isTraining}
                        className="bg-purple-700 hover:bg-purple-800"
                      >
                        {isTraining ? (
                          <>
                            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                            Training...
                          </>
                        ) : (
                          <>
                            <Brain className="h-4 w-4 mr-2" />
                            Train Model
                          </>
                        )}
                      </Button>
                      
                      <Button 
                        onClick={generateEdgeBets} 
                        disabled={isGenerating}
                        className="bg-cyan-700 hover:bg-cyan-800"
                      >
                        {isGenerating ? (
                          <>
                            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                            Generating...
                          </>
                        ) : (
                          <>
                            <Target className="h-4 w-4 mr-2" />
                            Generate Edge Bets
                          </>
                        )}
                      </Button>
                      
                      <Button 
                        onClick={resetWeights} 
                        variant="outline"
                        className="border-zinc-700 text-zinc-300 hover:bg-zinc-700"
                      >
                        <RotateCw className="h-4 w-4 mr-2" />
                        Reset Weights
                      </Button>
                      
                      <Button 
                        onClick={loadModelWeights} 
                        variant="outline"
                        className="border-zinc-700 text-zinc-300 hover:bg-zinc-700"
                      >
                        <RefreshCw className="h-4 w-4 mr-2" />
                        Refresh Data
                      </Button>
                    </div>
                    
                    {trainingResult && (
                      <div className="mt-4 p-3 bg-purple-900/20 border border-purple-900/40 rounded-md text-sm text-zinc-200">
                        {trainingResult}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
          
          {/* Training Tab */}
          <TabsContent value="training" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="bg-zinc-800 border-zinc-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-white">Feature Selection</CardTitle>
                  <CardDescription>Enable/disable features used by the model</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="odds" className="flex items-center text-sm">
                        <LineChart className="h-4 w-4 mr-2 text-purple-400" />
                        Odds Weighting
                      </Label>
                      <Switch 
                        id="odds" 
                        checked={featureImportance.odds}
                        onCheckedChange={(checked) => setFeatureImportance({...featureImportance, odds: checked})}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="spread" className="flex items-center text-sm">
                        <BarChart3 className="h-4 w-4 mr-2 text-indigo-400" />
                        Spread Analysis
                      </Label>
                      <Switch 
                        id="spread" 
                        checked={featureImportance.spread}
                        onCheckedChange={(checked) => setFeatureImportance({...featureImportance, spread: checked})}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="total" className="flex items-center text-sm">
                        <BarChart3 className="h-4 w-4 mr-2 text-blue-400" />
                        Total Points
                      </Label>
                      <Switch 
                        id="total" 
                        checked={featureImportance.total}
                        onCheckedChange={(checked) => setFeatureImportance({...featureImportance, total: checked})}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="teamStats" className="flex items-center text-sm">
                        <Badge className="h-4 w-4 mr-2 text-cyan-400" />
                        Team Statistics
                      </Label>
                      <Switch 
                        id="teamStats" 
                        checked={featureImportance.teamStats}
                        onCheckedChange={(checked) => setFeatureImportance({...featureImportance, teamStats: checked})}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="seasonality" className="flex items-center text-sm">
                        <Badge className="h-4 w-4 mr-2 text-yellow-400" />
                        Seasonality
                      </Label>
                      <Switch 
                        id="seasonality" 
                        checked={featureImportance.seasonality}
                        onCheckedChange={(checked) => setFeatureImportance({...featureImportance, seasonality: checked})}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="weather" className="flex items-center text-sm">
                        <Badge className="h-4 w-4 mr-2 text-blue-400" />
                        Weather Impact
                      </Label>
                      <Switch 
                        id="weather" 
                        checked={featureImportance.weather}
                        onCheckedChange={(checked) => setFeatureImportance({...featureImportance, weather: checked})}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="form" className="flex items-center text-sm">
                        <LineChart className="h-4 w-4 mr-2 text-green-400" />
                        Recent Form
                      </Label>
                      <Switch 
                        id="form" 
                        checked={featureImportance.form}
                        onCheckedChange={(checked) => setFeatureImportance({...featureImportance, form: checked})}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="rest" className="flex items-center text-sm">
                        <Badge className="h-4 w-4 mr-2 text-orange-400" />
                        Rest Days
                      </Label>
                      <Switch 
                        id="rest" 
                        checked={featureImportance.rest}
                        onCheckedChange={(checked) => setFeatureImportance({...featureImportance, rest: checked})}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="rivalry" className="flex items-center text-sm">
                        <Badge className="h-4 w-4 mr-2 text-red-400" />
                        Rivalry Factor
                      </Label>
                      <Switch 
                        id="rivalry" 
                        checked={featureImportance.rivalry}
                        onCheckedChange={(checked) => setFeatureImportance({...featureImportance, rivalry: checked})}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-zinc-800 border-zinc-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-white">Training Parameters</CardTitle>
                  <CardDescription>Configure model learning behavior</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-5">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Label className="text-sm">Confidence Threshold</Label>
                        <span className="text-sm font-medium text-white">{confidenceThreshold[0]}%</span>
                      </div>
                      <Slider
                        value={confidenceThreshold}
                        onValueChange={setConfidenceThreshold}
                        max={95}
                        min={50}
                        step={5}
                        className="[&>span]:bg-purple-500"
                      />
                      <p className="text-xs text-zinc-400">Minimum confidence required for bet recommendations</p>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Label className="text-sm">Model Accuracy</Label>
                        <span className="text-sm font-medium text-white">{accuracy.toFixed(1)}%</span>
                      </div>
                      <CustomProgress 
                        value={accuracy} 
                        className="h-2 bg-zinc-700"
                        indicatorClassName="bg-gradient-to-r from-purple-600 to-indigo-500"
                      />
                      <p className="text-xs text-zinc-400">
                        Current model accuracy based on {currentWeights?.sampleSize || 0} training samples
                      </p>
                    </div>
                    
                    <div className="pt-4">
                      <Button 
                        onClick={trainModel} 
                        disabled={isTraining}
                        className="w-full bg-purple-700 hover:bg-purple-800"
                      >
                        {isTraining ? (
                          <>
                            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                            Training Model...
                          </>
                        ) : (
                          <>
                            <Brain className="h-4 w-4 mr-2" />
                            Train Model With Current Settings
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Predictions Tab */}
          <TabsContent value="predictions" className="mt-4">
            <Card className="bg-zinc-800 border-zinc-700">
              <CardHeader className="pb-2 flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-lg text-white">Edge Bet Recommendations</CardTitle>
                  <CardDescription>Model-generated edge bets with positive value</CardDescription>
                </div>
                <Button 
                  onClick={generateEdgeBets} 
                  disabled={isGenerating}
                  size="sm"
                  className="bg-cyan-700 hover:bg-cyan-800"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Target className="h-4 w-4 mr-2" />
                      Generate New Edges
                    </>
                  )}
                </Button>
              </CardHeader>
              <CardContent>
                {edgeBets.length > 0 ? (
                  <div className="space-y-3">
                    {edgeBets.map((bet, index) => (
                      <div key={index} className="p-3 bg-zinc-800/80 border border-zinc-700 rounded-md hover:border-purple-700 transition-colors">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="text-xs text-zinc-500 uppercase">{bet.betType}</span>
                            <h4 className="font-medium text-white">{bet.pick} ({bet.odds > 2 ? `+${Math.round((bet.odds - 1) * 100)}` : `-${Math.round(100 / (bet.odds - 1))}`})</h4>
                            <p className="text-xs text-zinc-400 mt-1">{bet.analysis}</p>
                          </div>
                          <div className="flex flex-col items-end">
                            <span className="text-sm font-bold text-purple-400">{bet.edgePercentage.toFixed(1)}% Edge</span>
                            <div className="mt-2 flex items-center">
                              <span className="text-xs mr-2 text-zinc-500">Confidence</span>
                              <div className="bg-zinc-700 h-2 w-16 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full ${bet.confidence > 75 ? "bg-green-500" : bet.confidence > 65 ? "bg-cyan-500" : "bg-amber-500"}`}
                                  style={{ width: `${bet.confidence}%` }}
                                ></div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="mt-3 flex justify-end">
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-purple-700 text-purple-400 hover:bg-purple-900/30"
                          >
                            <Zap className="w-3 h-3 mr-1" />
                            Place Bet
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <XCircle className="h-12 w-12 text-zinc-600 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-zinc-400">No Edge Bets Found</h3>
                    <p className="text-sm text-zinc-500 mt-2 max-w-md mx-auto">
                      Generate new edge bets to get AI-powered recommendations with positive expected value.
                    </p>
                    <Button 
                      onClick={generateEdgeBets} 
                      className="mt-4 bg-purple-700 hover:bg-purple-800"
                      disabled={isGenerating}
                    >
                      {isGenerating ? "Generating..." : "Generate Edge Bets"}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Bot, PencilLine, ArrowUpDown, Coins, Brain, ChartBar, Calendar } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function GeniusAnalysisCard() {
  const [activeTab, setActiveTab] = useState('event');
  const [query, setQuery] = useState('');
  const [analysis, setAnalysis] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const analyzeQuery = async () => {
    if (!query.trim()) {
      toast({
        title: "Query Required",
        description: "Please enter your analysis request",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          query,
          type: activeTab,
        })
      });

      const data = await response.json();
      setAnalysis(data.analysis);
    } catch (error) {
      toast({
        title: "Analysis Failed",
        description: "Unable to generate analysis. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="relative overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
        <div className="flex items-center space-x-2">
          <Bot className="h-6 w-6" />
          <CardTitle>DK's Genius Analysis Bot</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="p-4 space-y-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-4 mb-4">
            <TabsTrigger value="event" className="flex items-center space-x-1">
              <Calendar className="h-4 w-4" />
              <span>Events</span>
            </TabsTrigger>
            <TabsTrigger value="strategy" className="flex items-center space-x-1">
              <Brain className="h-4 w-4" />
              <span>Strategy</span>
            </TabsTrigger>
            <TabsTrigger value="market" className="flex items-center space-x-1">
              <ChartBar className="h-4 w-4" />
              <span>Market</span>
            </TabsTrigger>
            <TabsTrigger value="crypto" className="flex items-center space-x-1">
              <Coins className="h-4 w-4" />
              <span>Crypto</span>
            </TabsTrigger>
          </TabsList>

          <div className="space-y-4">
            <div className="flex space-x-2">
              <Input
                placeholder={getPlaceholder(activeTab)}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && analyzeQuery()}
              />
              <Button 
                onClick={analyzeQuery}
                disabled={isLoading}
                className="min-w-[100px]"
              >
                {isLoading ? "Analyzing..." : "Analyze"}
              </Button>
            </div>

            <ScrollArea className="h-[300px] rounded-md border p-4">
              {analysis ? (
                <div className="prose prose-sm dark:prose-invert">
                  {analysis.split('\n').map((line, i) => (
                    <p key={i} className="mb-2">{line}</p>
                  ))}
                </div>
              ) : (
                <div className="text-center text-muted-foreground">
                  Ask me about events, strategies, market analysis, or crypto impact on sports betting
                </div>
              )}
            </ScrollArea>
          </div>
        </Tabs>
      </CardContent>
    </Card>
  );
}

function getPlaceholder(tab: string): string {
  switch (tab) {
    case 'event':
      return 'Analyze an event (e.g., "Lakers vs Warriors tonight")';
    case 'strategy':
      return 'Get betting strategy advice (e.g., "Best approach for NBA player props")';
    case 'market':
      return 'Market analysis request (e.g., "Current NBA betting trends")';
    case 'crypto':
      return 'Crypto market impact (e.g., "BTC price effect on betting")';
    default:
      return 'Enter your analysis request...';
  }
}
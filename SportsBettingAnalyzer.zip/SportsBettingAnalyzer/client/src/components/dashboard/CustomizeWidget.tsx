import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Check, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { DEFAULT_USER_ID } from "@/lib/constants";

interface CustomizeWidgetProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CustomizeWidget({ isOpen, onClose }: CustomizeWidgetProps) {
  const { toast } = useToast();
  const [widgetTitle, setWidgetTitle] = useState("");
  const [widgetType, setWidgetType] = useState("strategy");
  
  // Widget types with display names and descriptions
  const widgetTypes = [
    { 
      id: "strategy", 
      name: "Strategy Module", 
      description: "Shows betting recommendations based on strategy type" 
    },
    { 
      id: "performance", 
      name: "Performance Tracker", 
      description: "Visualizes your betting performance over time" 
    },
    { 
      id: "upcoming", 
      name: "Upcoming Events", 
      description: "Lists upcoming events with betting opportunities" 
    },
    { 
      id: "crypto", 
      name: "Crypto Tracker", 
      description: "Monitors your cryptocurrency assets" 
    },
    { 
      id: "news", 
      name: "Sports News", 
      description: "Latest sports news that might affect betting" 
    },
    { 
      id: "genius", 
      name: "Genius Analysis", 
      description: "AI-powered betting insights and analysis" 
    }
  ];
  
  // Get user's current widgets
  const { data: userWidgets = [], isLoading: loadingWidgets } = useQuery({
    queryKey: [`/api/widgets/user/${DEFAULT_USER_ID}`],
    enabled: isOpen,
  });
  
  // Create widget mutation
  const createWidgetMutation = useMutation({
    mutationFn: async (data: any) => {
      return fetch('/api/widgets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      }).then(res => {
        if (!res.ok) throw new Error('Failed to create widget');
        return res.json();
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/widgets/user/${DEFAULT_USER_ID}`] });
      setWidgetTitle("");
      setWidgetType("strategy");
      toast({
        title: "Widget added",
        description: "Your dashboard has been updated with the new widget."
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to add widget",
        description: `Error: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  // Toggle widget status mutation
  const toggleWidgetMutation = useMutation({
    mutationFn: async ({ id, enabled }: { id: number, enabled: boolean }) => {
      return fetch(`/api/widgets/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ enabled }),
      }).then(res => {
        if (!res.ok) throw new Error('Failed to update widget');
        return res.json();
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/widgets/user/${DEFAULT_USER_ID}`] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update widget",
        description: `Error: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  // Delete widget mutation
  const deleteWidgetMutation = useMutation({
    mutationFn: async (id: number) => {
      return fetch(`/api/widgets/${id}`, {
        method: 'DELETE',
      }).then(res => {
        if (!res.ok) throw new Error('Failed to delete widget');
        return res.json();
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/widgets/user/${DEFAULT_USER_ID}`] });
      toast({
        title: "Widget removed",
        description: "The widget has been removed from your dashboard."
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to remove widget",
        description: `Error: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  const handleAddWidget = () => {
    if (!widgetTitle) {
      toast({
        title: "Widget name required",
        description: "Please enter a name for your widget.",
        variant: "destructive"
      });
      return;
    }
    
    createWidgetMutation.mutate({
      userId: DEFAULT_USER_ID,
      title: widgetTitle,
      widgetType,
      position: { x: 0, y: 0 },
      size: { width: 300, height: 200 },
      enabled: true,
      config: {}
    });
  };
  
  const handleToggleWidget = (id: number, currentEnabled: boolean) => {
    toggleWidgetMutation.mutate({ id, enabled: !currentEnabled });
  };
  
  const handleDeleteWidget = (id: number) => {
    deleteWidgetMutation.mutate(id);
  };
  
  const getWidgetTypeName = (typeId: string) => {
    const widgetType = widgetTypes.find(type => type.id === typeId);
    return widgetType ? widgetType.name : typeId;
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Customize Dashboard</DialogTitle>
          <DialogDescription>
            Add, remove, or toggle widgets to personalize your betting dashboard.
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          <h3 className="text-sm font-medium mb-2">Current Widgets</h3>
          {loadingWidgets ? (
            <p className="text-sm text-slate-500">Loading widgets...</p>
          ) : userWidgets && userWidgets.length > 0 ? (
            <div className="space-y-2">
              {userWidgets.map((widget: any) => (
                <div key={widget.id} className="flex items-center justify-between p-2 border rounded-md">
                  <div>
                    <p className="font-medium">{widget.title}</p>
                    <p className="text-xs text-slate-500">{getWidgetTypeName(widget.widgetType)}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch 
                      checked={widget.enabled} 
                      onCheckedChange={() => handleToggleWidget(widget.id, widget.enabled)}
                    />
                    <Button 
                      variant="outline" 
                      size="icon" 
                      className="h-7 w-7"
                      onClick={() => handleDeleteWidget(widget.id)}
                    >
                      <span className="sr-only">Delete</span>
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                      </svg>
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-slate-500">No widgets configured yet.</p>
          )}
          
          <div className="border-t mt-4 pt-4">
            <h3 className="text-sm font-medium mb-2">Add New Widget</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="widget-name" className="text-right">
                  Name
                </Label>
                <Input
                  id="widget-name"
                  value={widgetTitle}
                  onChange={(e) => setWidgetTitle(e.target.value)}
                  className="col-span-3"
                  placeholder="e.g., My Strategy Widget"
                />
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="widget-type" className="text-right">
                  Type
                </Label>
                <select
                  id="widget-type"
                  value={widgetType}
                  onChange={(e) => setWidgetType(e.target.value)}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 col-span-3"
                >
                  {widgetTypes.map(type => (
                    <option key={type.id} value={type.id}>
                      {type.name} - {type.description}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button 
            onClick={handleAddWidget}
            disabled={!widgetTitle || createWidgetMutation.isPending}
            className="gap-1"
          >
            <Plus className="h-4 w-4" />
            Add Widget
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
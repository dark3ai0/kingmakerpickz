import { useState, useEffect, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { 
  Dices, 
  Loader2, 
  ChevronDown, 
  Ban, 
  CheckCircle, 
  DollarSign,
  Trophy 
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger
} from "@/components/ui/tooltip";
import { formatCurrency } from "@/lib/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription, 
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";

// Types of bets for the quick pick
const QUICK_PICK_TYPES = [
  { id: "moneyline", name: "Moneyline", description: "Straight up winner" },
  { id: "spread", name: "Spread", description: "Betting with points" },
  { id: "total", name: "Total", description: "Over/Under scoring" },
  { id: "prop", name: "Prop Bet", description: "Player performance" },
  { id: "parlay", name: "Parlay", description: "Multiple combined bets" },
];

// Sports for the quick pick
const QUICK_PICK_SPORTS = [
  { id: "nfl", name: "NFL", emoji: "🏈" },
  { id: "nba", name: "NBA", emoji: "🏀" },
  { id: "mlb", name: "MLB", emoji: "⚾" },
  { id: "nhl", name: "NHL", emoji: "🏒" },
  { id: "soccer", name: "Soccer", emoji: "⚽" },
];

export default function QuickPickGame() {
  const [isSpinning, setIsSpinning] = useState(false);
  const [spinComplete, setSpinComplete] = useState(false);
  const [selectedAmount, setSelectedAmount] = useState("5");
  const [quickPickResult, setQuickPickResult] = useState<any>(null);
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  
  // Visual slot machine state
  const [sport, setSport] = useState<string | null>(null);
  const [betType, setBetType] = useState<string | null>(null);
  const [confidence, setConfidence] = useState<number | null>(null);
  
  // References for the slot animation
  const slotRefs = {
    sport: useRef<HTMLDivElement>(null),
    betType: useRef<HTMLDivElement>(null),
    confidence: useRef<HTMLDivElement>(null),
  };
  
  const { toast } = useToast();
  
  // Simulated mutation for getting a quick pick
  const quickPickMutation = useMutation({
    mutationFn: async (data: { amount: string }) => {
      // Simulate API request to get a random quick pick using Gemini API
      // In a real implementation, this would call the backend
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Randomly select a sport, bet type, and confidence level
      const randomSport = QUICK_PICK_SPORTS[Math.floor(Math.random() * QUICK_PICK_SPORTS.length)];
      const randomBetType = QUICK_PICK_TYPES[Math.floor(Math.random() * QUICK_PICK_TYPES.length)];
      const randomConfidence = Math.floor(Math.random() * 5) + 6; // 6-10 range
      
      // Generate a random matchup and pick based on sport and bet type
      let matchup = "";
      let pick = "";
      
      switch (randomSport.id) {
        case "nfl":
          matchup = "Chiefs vs. 49ers";
          pick = randomBetType.id === "moneyline" ? "Chiefs ML (-150)" :
                 randomBetType.id === "spread" ? "Chiefs -3.5 (-110)" :
                 randomBetType.id === "total" ? "Over 51.5 (-110)" :
                 randomBetType.id === "prop" ? "Mahomes Over 275.5 Passing Yards" : 
                 "Chiefs ML + Over 51.5";
          break;
        case "nba":
          matchup = "Lakers vs. Celtics";
          pick = randomBetType.id === "moneyline" ? "Lakers ML (+120)" :
                 randomBetType.id === "spread" ? "Lakers +4.5 (-110)" :
                 randomBetType.id === "total" ? "Under 220.5 (-110)" :
                 randomBetType.id === "prop" ? "LeBron Over 26.5 Points" : 
                 "Lakers +4.5 + Under 220.5";
          break;
        case "mlb":
          matchup = "Yankees vs. Red Sox";
          pick = randomBetType.id === "moneyline" ? "Yankees ML (-135)" :
                 randomBetType.id === "spread" ? "Yankees -1.5 (+135)" :
                 randomBetType.id === "total" ? "Over 8.5 (-110)" :
                 randomBetType.id === "prop" ? "Judge to Hit a Home Run (+280)" : 
                 "Yankees ML + Over 8.5";
          break;
        case "nhl":
          matchup = "Maple Leafs vs. Canadiens";
          pick = randomBetType.id === "moneyline" ? "Maple Leafs ML (-145)" :
                 randomBetType.id === "spread" ? "Maple Leafs -1.5 (+145)" :
                 randomBetType.id === "total" ? "Under 5.5 (-115)" :
                 randomBetType.id === "prop" ? "Matthews to Score (+125)" : 
                 "Maple Leafs ML + Under 5.5";
          break;
        case "soccer":
          matchup = "Manchester United vs. Liverpool";
          pick = randomBetType.id === "moneyline" ? "Manchester United ML (+140)" :
                 randomBetType.id === "spread" ? "Manchester United +0.5 (-125)" :
                 randomBetType.id === "total" ? "Over 2.5 (-110)" :
                 randomBetType.id === "prop" ? "Rashford to Score (+180)" : 
                 "Manchester United ML + Both Teams to Score";
          break;
      }
      
      // Calculate odds and potential win
      const odds = randomBetType.id === "parlay" ? Math.floor(Math.random() * 400) + 200 : Math.floor(Math.random() * 200) - 120;
      const amount = parseFloat(data.amount);
      const potentialWin = odds > 0 
        ? amount * (odds/100)
        : amount * (100/Math.abs(odds));
      
      // Return the quick pick result
      return {
        sport: randomSport,
        betType: randomBetType,
        confidence: randomConfidence,
        matchup,
        pick,
        odds,
        amount,
        potentialWin: potentialWin.toFixed(2),
        reasoning: "Based on recent performance metrics, injury reports, and historical matchup data analyzed by our AI model, this bet offers favorable value."
      };
    },
    onSuccess: (data) => {
      // Set the result
      setQuickPickResult(data);
      
      // Wait for the animation to complete before showing the result
      setTimeout(() => {
        setSport(data.sport.id);
        setBetType(data.betType.id);
        setConfidence(data.confidence);
        setSpinComplete(true);
      }, 2000);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate a quick pick. Please try again.",
        variant: "destructive"
      });
      setIsSpinning(false);
    }
  });
  
  const handleSpin = () => {
    setIsSpinning(true);
    setSpinComplete(false);
    setQuickPickResult(null);
    setSport(null);
    setBetType(null);
    setConfidence(null);
    
    // Start the slot machine animation
    animateSlots();
    
    // Fetch the quick pick
    quickPickMutation.mutate({ amount: selectedAmount });
  };
  
  const animateSlots = () => {
    // Animate each slot
    if (slotRefs.sport.current) {
      slotRefs.sport.current.style.animation = "none";
      void slotRefs.sport.current.offsetHeight; // Trigger reflow
      slotRefs.sport.current.style.animation = "spin 2s ease-out forwards";
    }
    
    if (slotRefs.betType.current) {
      slotRefs.betType.current.style.animation = "none";
      void slotRefs.betType.current.offsetHeight; // Trigger reflow
      slotRefs.betType.current.style.animation = "spin 2.2s ease-out forwards";
    }
    
    if (slotRefs.confidence.current) {
      slotRefs.confidence.current.style.animation = "none";
      void slotRefs.confidence.current.offsetHeight; // Trigger reflow
      slotRefs.confidence.current.style.animation = "spin 2.4s ease-out forwards";
    }
  };
  
  const handlePlaceBet = () => {
    // In a real implementation, this would place the bet
    // via API call to the backend
    setConfirmDialogOpen(true);
  };
  
  const confirmBet = () => {
    toast({
      title: "Bet Placed Successfully!",
      description: "Your quick pick bet has been placed. Good luck!",
    });
    setConfirmDialogOpen(false);
    
    // Reset the slot machine
    setTimeout(() => {
      setIsSpinning(false);
      setSpinComplete(false);
      setQuickPickResult(null);
      setSport(null);
      setBetType(null);
      setConfidence(null);
    }, 1000);
  };
  
  // Add slot machine animation styles to the component
  useEffect(() => {
    const styleEl = document.createElement("style");
    styleEl.textContent = `
      @keyframes spin {
        0% { transform: translateY(0); }
        25% { transform: translateY(-300px); }
        50% { transform: translateY(-600px); }
        75% { transform: translateY(-900px); }
        100% { transform: translateY(0); }
      }
      
      .slot-item {
        height: 60px;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      
      .confidence-value {
        font-size: 24px;
        font-weight: bold;
      }
      
      .confidence-1-5 { color: #ef4444; }
      .confidence-6-7 { color: #eab308; }
      .confidence-8-9 { color: #22c55e; }
      .confidence-10 { color: #16a34a; }
    `;
    document.head.appendChild(styleEl);
    
    return () => {
      document.head.removeChild(styleEl);
    };
  }, []);
  
  return (
    <Card className="shadow-md border border-indigo-100 bg-white overflow-hidden">
      <CardHeader className="pb-2 bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
        <div className="flex items-center space-x-2">
          <Dices className="h-5 w-5 text-white" />
          <CardTitle className="text-lg font-semibold">Quick Pick Slot Machine</CardTitle>
        </div>
        <CardDescription className="text-indigo-100">
          Spin for a random AI-powered betting recommendation
        </CardDescription>
      </CardHeader>
      
      <CardContent className="p-4">
        <div className="grid grid-cols-3 gap-4 mb-4">
          {/* Sport Slot */}
          <div className="relative bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg p-2 overflow-hidden h-[80px] flex items-center justify-center">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="font-semibold text-slate-400 text-sm">SPORT</div>
            </div>
            <div 
              ref={slotRefs.sport} 
              className="relative w-full h-[60px] overflow-hidden"
            >
              {sport ? (
                <div className="slot-item">
                  <div className="flex items-center space-x-1">
                    <span className="text-2xl">{QUICK_PICK_SPORTS.find(s => s.id === sport)?.emoji}</span>
                    <span className="font-bold text-indigo-700">{QUICK_PICK_SPORTS.find(s => s.id === sport)?.name}</span>
                  </div>
                </div>
              ) : (
                <div className="slot-item">
                  <Dices className="h-6 w-6 text-slate-300" />
                </div>
              )}
            </div>
          </div>
          
          {/* Bet Type Slot */}
          <div className="relative bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg p-2 overflow-hidden h-[80px] flex items-center justify-center">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="font-semibold text-slate-400 text-sm">BET TYPE</div>
            </div>
            <div 
              ref={slotRefs.betType} 
              className="relative w-full h-[60px] overflow-hidden"
            >
              {betType ? (
                <div className="slot-item">
                  <span className="font-bold text-indigo-700">{QUICK_PICK_TYPES.find(b => b.id === betType)?.name}</span>
                </div>
              ) : (
                <div className="slot-item">
                  <Dices className="h-6 w-6 text-slate-300" />
                </div>
              )}
            </div>
          </div>
          
          {/* Confidence Slot */}
          <div className="relative bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg p-2 overflow-hidden h-[80px] flex items-center justify-center">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="font-semibold text-slate-400 text-sm">CONFIDENCE</div>
            </div>
            <div 
              ref={slotRefs.confidence} 
              className="relative w-full h-[60px] overflow-hidden"
            >
              {confidence ? (
                <div className="slot-item">
                  <span className={`confidence-value ${
                    confidence < 6 ? 'confidence-1-5' :
                    confidence < 8 ? 'confidence-6-7' :
                    confidence < 10 ? 'confidence-8-9' : 'confidence-10'
                  }`}>
                    {confidence}/10
                  </span>
                </div>
              ) : (
                <div className="slot-item">
                  <Dices className="h-6 w-6 text-slate-300" />
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Quick Pick Result */}
        {spinComplete && quickPickResult && (
          <div className="mt-4 border border-indigo-200 rounded-lg p-4 bg-indigo-50/50">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <h3 className="font-bold text-indigo-900">{quickPickResult.matchup}</h3>
                <div className="flex items-center mt-1 space-x-2">
                  <Badge variant="outline" className="bg-indigo-100 text-indigo-700 border-indigo-200">
                    {quickPickResult.sport.emoji} {quickPickResult.sport.name}
                  </Badge>
                  <Badge variant="outline" className="bg-purple-100 text-purple-700 border-purple-200">
                    {quickPickResult.betType.name}
                  </Badge>
                  <Badge variant="outline" className={`
                    ${quickPickResult.confidence < 6 ? 'bg-red-100 text-red-700 border-red-200' :
                      quickPickResult.confidence < 8 ? 'bg-yellow-100 text-yellow-700 border-yellow-200' :
                      quickPickResult.confidence < 10 ? 'bg-green-100 text-green-700 border-green-200' : 
                      'bg-emerald-100 text-emerald-700 border-emerald-200'}
                  `}>
                    Confidence: {quickPickResult.confidence}/10
                  </Badge>
                </div>
              </div>
              
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="flex items-center">
                      <Trophy className="h-5 w-5 text-yellow-500 mr-1" />
                      <span className="font-bold text-indigo-900">{formatCurrency(quickPickResult.potentialWin)}</span>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Potential Win</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            
            <Separator className="my-2" />
            
            <div className="mt-2">
              <div className="font-semibold text-indigo-900">Recommended Pick:</div>
              <div className="p-2 bg-white rounded border border-indigo-200 mt-1">
                <span className="text-lg font-bold text-indigo-700">{quickPickResult.pick}</span>
                <div className="text-sm text-slate-500 mt-1">
                  Odds: <span className="font-mono font-medium text-slate-700">
                    {quickPickResult.odds > 0 ? `+${quickPickResult.odds}` : quickPickResult.odds}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="mt-3 text-sm text-slate-600">
              <strong>AI Reasoning:</strong> {quickPickResult.reasoning}
            </div>
            
            <Button 
              className="w-full mt-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
              onClick={handlePlaceBet}
            >
              Place Bet ({formatCurrency(quickPickResult.amount)})
            </Button>
          </div>
        )}
        
        {/* Spin Controls */}
        <div className={`mt-4 flex ${spinComplete ? 'justify-between' : 'justify-center'} items-center`}>
          {!spinComplete && (
            <div className="flex items-center space-x-4">
              <Select
                value={selectedAmount}
                onValueChange={setSelectedAmount}
                disabled={isSpinning}
              >
                <SelectTrigger className="w-[120px]">
                  <DollarSign className="h-4 w-4 mr-1 text-green-600" />
                  <SelectValue placeholder="Bet Amount" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">$5.00</SelectItem>
                  <SelectItem value="10">$10.00</SelectItem>
                  <SelectItem value="25">$25.00</SelectItem>
                  <SelectItem value="50">$50.00</SelectItem>
                  <SelectItem value="100">$100.00</SelectItem>
                </SelectContent>
              </Select>
              
              <Button
                onClick={handleSpin}
                disabled={isSpinning && !spinComplete}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
              >
                {isSpinning && !spinComplete ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Spinning...
                  </>
                ) : (
                  <>
                    <Dices className="mr-2 h-4 w-4" />
                    Spin
                  </>
                )}
              </Button>
            </div>
          )}
          
          {spinComplete && (
            <Button
              variant="outline"
              onClick={() => {
                setIsSpinning(false);
                setSpinComplete(false);
                setQuickPickResult(null);
                setSport(null);
                setBetType(null);
                setConfidence(null);
              }}
              className="text-slate-600"
            >
              <Ban className="mr-2 h-4 w-4" />
              Clear & Reset
            </Button>
          )}
        </div>
      </CardContent>
      
      <CardFooter className="bg-indigo-50/50 border-t border-indigo-100 px-4 py-3 text-xs text-center text-slate-500 flex justify-center">
        Powered by Gemini AI • Free spin every 24 hours
      </CardFooter>
      
      {/* Confirmation Dialog */}
      <Dialog open={confirmDialogOpen} onOpenChange={setConfirmDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Your Bet</DialogTitle>
            <DialogDescription>
              You're about to place the following bet:
            </DialogDescription>
          </DialogHeader>
          
          {quickPickResult && (
            <div className="space-y-4">
              <div className="rounded-lg border border-slate-200 p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <div className="text-lg font-bold">{quickPickResult.matchup}</div>
                    <div className="text-sm text-slate-500">{quickPickResult.sport.name} • {quickPickResult.betType.name}</div>
                  </div>
                  <Badge variant="outline" className={`
                    ${quickPickResult.confidence < 6 ? 'bg-red-100 text-red-700 border-red-200' :
                      quickPickResult.confidence < 8 ? 'bg-yellow-100 text-yellow-700 border-yellow-200' :
                      quickPickResult.confidence < 10 ? 'bg-green-100 text-green-700 border-green-200' : 
                      'bg-emerald-100 text-emerald-700 border-emerald-200'}
                  `}>
                    Confidence: {quickPickResult.confidence}/10
                  </Badge>
                </div>
                
                <Separator className="my-2" />
                
                <div className="font-bold text-indigo-700">{quickPickResult.pick}</div>
                
                <div className="mt-3 flex justify-between">
                  <div>
                    <div className="text-sm text-slate-500">Bet Amount</div>
                    <div className="font-medium">{formatCurrency(quickPickResult.amount)}</div>
                  </div>
                  <div>
                    <div className="text-sm text-slate-500">Odds</div>
                    <div className="font-medium font-mono">{quickPickResult.odds > 0 ? `+${quickPickResult.odds}` : quickPickResult.odds}</div>
                  </div>
                  <div>
                    <div className="text-sm text-slate-500">Potential Win</div>
                    <div className="font-medium text-emerald-600">{formatCurrency(quickPickResult.potentialWin)}</div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={confirmBet}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
            >
              <CheckCircle className="mr-2 h-4 w-4" />
              Confirm Bet
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
import React, { useState } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Gauge, Calculator, Info, DollarSign, BarChart3, BarChart4, TrendingUp } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Progress } from "@/components/ui/progress";

// Form schema for bet calculator
const betCalculatorSchema = z.object({
  bankroll: z.number().min(1, "Bankroll must be at least 1").default(1000),
  riskLevel: z.enum(["low", "medium", "high"]).default("medium"),
  confidence: z.number().min(1).max(10).default(5),
  winProbability: z.number().min(0.01).max(0.99).default(0.5),
  odds: z.number().default(-110),
  unitSizePercent: z.number().min(0.1).max(10).default(2)
});

type BetCalculatorFormValues = z.infer<typeof betCalculatorSchema>;

export default function BankrollCalculatorCard() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [activeAlgorithm, setActiveAlgorithm] = useState<string | null>(null);
  
  // Initialize form with default values
  const form = useForm<BetCalculatorFormValues>({
    resolver: zodResolver(betCalculatorSchema),
    defaultValues: {
      bankroll: 1000,
      riskLevel: "medium",
      confidence: 5,
      winProbability: 0.5,
      odds: -110,
      unitSizePercent: 2
    }
  });
  
  // Submit handler
  const onSubmit = async (data: BetCalculatorFormValues) => {
    setLoading(true);
    try {
      const response = await apiRequest("POST", "/api/bankroll/calculate-bet-size", data);
      const result = await response.json();
      setResult(result);
      setActiveAlgorithm(null); // Reset active algorithm on new calculation
    } catch (error) {
      toast({
        title: "Calculation Error",
        description: "Failed to calculate optimal bet size.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  
  // Helper function to format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };
  
  // Helper function to format percentage
  const formatPercent = (value: number) => {
    return (value * 100).toFixed(1) + '%';
  };
  
  // Helper to calculate and format recommended amount as percentage of bankroll
  const getBetPercentage = (amount: number, bankroll: number) => {
    return ((amount / bankroll) * 100).toFixed(2) + '%';
  };
  
  // Get algorithm description
  const getAlgorithmDescription = (key: string) => {
    const descriptions: Record<string, string> = {
      kelly: "Kelly Criterion optimizes bet size based on your edge. It balances risk and reward for optimal bankroll growth.",
      fixedUnit: "Fixed Unit uses a simple flat betting approach with adjustments based on your risk tolerance.",
      percentage: "Percentage Model varies bet sizes proportionally to your bankroll and confidence level.",
      confidence: "Confidence-Weighted adjusts bet sizes based on your confidence in the bet, giving more weight to high-confidence bets.",
      proportional: "Proportional Value Betting sizes bets based on the perceived value or edge in the market odds.",
      drawdown: "Drawdown Protection automatically reduces bet sizes after losses and gradually increases after wins."
    };
    
    return descriptions[key] || "Advanced betting algorithm";
  };
  
  // For chart representation - get unique colors for each algorithm
  const getAlgorithmColor = (key: string) => {
    const colors: Record<string, string> = {
      kelly: "rgb(99, 102, 241)", // Indigo
      fixedUnit: "rgb(6, 182, 212)", // Cyan
      percentage: "rgb(16, 185, 129)", // Emerald
      confidence: "rgb(245, 158, 11)", // Amber
      proportional: "rgb(236, 72, 153)", // Pink
      drawdown: "rgb(124, 58, 237)" // Purple
    };
    
    return colors[key] || "#888888";
  };
  
  return (
    <Card className="w-full shadow-lg border-0 bg-gradient-to-br from-emerald-900/90 to-cyan-900/90 text-white">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-transparent bg-clip-text bg-gradient-to-r from-emerald-200 to-cyan-200">
          <Calculator className="h-5 w-5 text-emerald-300" />
          Bankroll Management Calculator
        </CardTitle>
        <CardDescription className="text-emerald-200/80">
          Calculate optimal bet sizes using advanced algorithms
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <Tabs defaultValue="calculator" className="w-full">
          <TabsList className="grid grid-cols-2 bg-emerald-800/50">
            <TabsTrigger value="calculator" className="data-[state=active]:bg-cyan-700 text-white">Calculator</TabsTrigger>
            <TabsTrigger value="results" className="data-[state=active]:bg-cyan-700 text-white">Results</TabsTrigger>
          </TabsList>
          
          <TabsContent value="calculator" className="space-y-4 pt-4">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="bankroll"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-emerald-200">Current Bankroll ($)</FormLabel>
                        <FormControl>
                          <Input
                            className="bg-emerald-800/50 border-emerald-700 text-emerald-100"
                            type="number"
                            {...field}
                            onChange={e => field.onChange(parseFloat(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="riskLevel"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-emerald-200">Risk Tolerance</FormLabel>
                        <Select
                          value={field.value}
                          onValueChange={field.onChange}
                        >
                          <FormControl>
                            <SelectTrigger className="bg-emerald-800/50 border-emerald-700 text-emerald-100">
                              <SelectValue placeholder="Select risk level" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-emerald-800 border-emerald-700 text-emerald-100">
                            <SelectItem value="low">Conservative (Low)</SelectItem>
                            <SelectItem value="medium">Balanced (Medium)</SelectItem>
                            <SelectItem value="high">Aggressive (High)</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="space-y-2">
                  <FormField
                    control={form.control}
                    name="confidence"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex items-center justify-between">
                          <FormLabel className="text-emerald-200">Confidence Level (1-10)</FormLabel>
                          <span className="text-emerald-200 text-sm">{field.value}</span>
                        </div>
                        <FormControl>
                          <Slider
                            min={1}
                            max={10}
                            step={1}
                            value={[field.value]}
                            onValueChange={([value]) => field.onChange(value)}
                            className="py-4"
                          />
                        </FormControl>
                        <FormDescription className="text-emerald-200/60 text-xs">
                          How confident are you in this bet? Higher values increase bet size.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="winProbability"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex items-center justify-between">
                          <FormLabel className="text-emerald-200">Win Probability</FormLabel>
                          <span className="text-emerald-200 text-sm">{(field.value * 100).toFixed(0)}%</span>
                        </div>
                        <FormControl>
                          <Slider
                            min={0.01}
                            max={0.99}
                            step={0.01}
                            value={[field.value]}
                            onValueChange={([value]) => field.onChange(value)}
                            className="py-4"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="odds"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-emerald-200">American Odds</FormLabel>
                        <FormControl>
                          <Input
                            className="bg-emerald-800/50 border-emerald-700 text-emerald-100"
                            type="number"
                            {...field}
                            onChange={e => field.onChange(parseInt(e.target.value))}
                          />
                        </FormControl>
                        <FormDescription className="text-emerald-200/60 text-xs">
                          E.g., -110 for favorite, +150 for underdog
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="unitSizePercent"
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center justify-between">
                        <FormLabel className="text-emerald-200">Base Unit Size (%)</FormLabel>
                        <span className="text-emerald-200 text-sm">{field.value.toFixed(1)}%</span>
                      </div>
                      <FormControl>
                        <Slider
                          min={0.1}
                          max={10}
                          step={0.1}
                          value={[field.value]}
                          onValueChange={([value]) => field.onChange(value)}
                          className="py-4"
                        />
                      </FormControl>
                      <FormDescription className="text-emerald-200/60 text-xs">
                        Base percentage of bankroll to bet (typically 1-5%)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit"
                  className="w-full bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white"
                  disabled={loading}
                >
                  {loading ? "Calculating..." : "Calculate Optimal Bet Size"}
                </Button>
              </form>
            </Form>
          </TabsContent>
          
          <TabsContent value="results" className="space-y-4 pt-4">
            {result ? (
              <div className="space-y-4">
                <div className="flex flex-col items-center justify-center p-4 bg-emerald-800/50 rounded-md text-center">
                  <div className="text-lg text-emerald-100">Recommended Bet:</div>
                  <div className="text-3xl font-bold text-white mt-1">
                    {formatCurrency(result.amount)}
                  </div>
                  <div className="text-sm text-emerald-200/80 mt-1">
                    {getBetPercentage(result.amount, form.getValues().bankroll)} of bankroll
                  </div>
                </div>
                
                <div className="relative h-8 bg-emerald-800/30 rounded-full overflow-hidden">
                  {Object.entries(result.breakdown.algorithms).map(([key, data]: [string, any], index) => {
                    const startPercent = Object.entries(result.breakdown.algorithms)
                      .slice(0, index)
                      .reduce((sum, [_, algorithmData]: [string, any]) => 
                        sum + (algorithmData.weight * 100), 0);
                      
                    return (
                      <div 
                        key={key}
                        className="absolute h-full" 
                        style={{
                          backgroundColor: getAlgorithmColor(key),
                          width: `${data.weight * 100}%`,
                          left: `${startPercent}%`,
                          transition: 'all 0.3s ease'
                        }}
                        onClick={() => setActiveAlgorithm(key)}
                      />
                    );
                  })}
                </div>
                
                <div className="grid grid-cols-3 gap-2 text-xs text-center mb-2">
                  {Object.entries(result.breakdown.algorithms).map(([key, data]: [string, any]) => (
                    <div 
                      key={key}
                      className={`p-1 rounded cursor-pointer transition-all ${activeAlgorithm === key ? 'bg-emerald-800/50 shadow-lg scale-105' : 'hover:bg-emerald-800/30'}`}
                      onClick={() => setActiveAlgorithm(key === activeAlgorithm ? null : key)}
                    >
                      <div className="flex items-center justify-center mb-1">
                        <div 
                          className="w-3 h-3 rounded-full mr-1" 
                          style={{ backgroundColor: getAlgorithmColor(key) }}
                        />
                        <span className="font-medium capitalize">{key}</span>
                      </div>
                      <div className="text-emerald-200/80">{(data.weight * 100).toFixed(0)}%</div>
                    </div>
                  ))}
                </div>
                
                <Separator className="bg-emerald-700/30 my-4" />
                
                <Accordion type="single" collapsible>
                  <AccordionItem value="algorithms" className="border-emerald-700/30">
                    <AccordionTrigger className="text-emerald-200 hover:text-white">
                      <div className="flex items-center">
                        <BarChart3 className="mr-2 h-4 w-4" />
                        Algorithm Breakdown
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="text-emerald-200/90">
                      <div className="space-y-3">
                        {Object.entries(result.breakdown.algorithms).map(([key, data]: [string, any]) => (
                          <div 
                            key={key} 
                            className={`p-3 rounded-md transition-all ${
                              activeAlgorithm === key 
                                ? 'bg-gradient-to-r from-emerald-800/70 to-cyan-800/70 border border-emerald-600/30' 
                                : 'bg-emerald-800/20 hover:bg-emerald-800/30'
                            }`}
                            onClick={() => setActiveAlgorithm(key === activeAlgorithm ? null : key)}
                          >
                            <div className="flex items-center justify-between mb-1">
                              <div className="flex items-center">
                                <div 
                                  className="w-3 h-3 rounded-full mr-2" 
                                  style={{ backgroundColor: getAlgorithmColor(key) }}
                                />
                                <h4 className="font-medium capitalize">{key} Algorithm</h4>
                              </div>
                              <span className="text-sm font-medium">{formatCurrency(data.amount)}</span>
                            </div>
                            
                            <p className="text-xs text-emerald-200/70 mb-2">
                              {getAlgorithmDescription(key)}
                            </p>
                            
                            <div className="flex justify-between text-xs">
                              <span>Weight: {(data.weight * 100).toFixed(0)}%</span>
                              <span>Contribution: {formatCurrency(data.contribution)}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-40 text-emerald-200/70">
                <Calculator className="h-8 w-8 mb-2 opacity-50" />
                <p>No calculation results yet.</p>
                <p className="text-sm">Fill out the form and click Calculate to see results.</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
      
      <CardFooter className="text-xs text-emerald-300/80 flex justify-between">
        <span>Advanced betting models</span>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" className="h-6 w-6 rounded-full text-emerald-300/80 hover:text-white hover:bg-emerald-800/50">
                <Info className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="left" className="bg-emerald-900 text-emerald-100 border-emerald-700">
              <p className="max-w-[200px] text-xs">
                Uses multiple algorithms weighted by risk level to calculate an optimal bet size
              </p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </CardFooter>
    </Card>
  );
}
import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/utils";
import { DEFAULT_USER_ID } from "@/lib/constants";
import { Bitcoin, Wallet } from "lucide-react";

export default function CryptoWalletCard() {
  const { toast } = useToast();
  const [addWalletOpen, setAddWalletOpen] = useState(false);
  const [newWallet, setNewWallet] = useState({
    currency: "BTC",
    address: ""
  });

  // Get crypto wallets for the user
  const { data: wallets = [], isLoading } = useQuery({
    queryKey: [`/api/crypto/wallets/user/${DEFAULT_USER_ID}`],
  });

  // Create new wallet
  const createWalletMutation = useMutation({
    mutationFn: async (data: any) => {
      return fetch('/api/crypto/wallets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      }).then(res => {
        if (!res.ok) throw new Error('Failed to add wallet');
        return res.json();
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/crypto/wallets/user/${DEFAULT_USER_ID}`] });
      toast({
        title: "Wallet added",
        description: "Your new crypto wallet has been added successfully.",
      });
      setAddWalletOpen(false);
      setNewWallet({ currency: "BTC", address: "" });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add wallet: ${error.message}`,
        variant: "destructive"
      });
    }
  });

  return (
    <Card>
      <CardHeader className="bg-gradient-to-r from-orange-500 to-amber-500 text-white rounded-t-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Bitcoin className="h-6 w-6" />
            <CardTitle>Crypto Wallets</CardTitle>
          </div>
          <Button 
            variant="secondary" 
            className="bg-white/20 hover:bg-white/30 text-white"
            onClick={() => setAddWalletOpen(true)}
          >
            <Wallet className="h-4 w-4 mr-2" />
            Add Wallet
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {isLoading ? (
          <div className="p-6 text-center">Loading wallets...</div>
        ) : wallets.length === 0 ? (
          <div className="p-6 text-center">
            <p className="text-slate-500 mb-4">No crypto wallets connected yet</p>
            <Button onClick={() => setAddWalletOpen(true)}>Connect a Wallet</Button>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Currency</TableHead>
                <TableHead>Address</TableHead>
                <TableHead>Balance</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {wallets.map((wallet: any) => (
                <TableRow key={wallet.id}>
                  <TableCell>{wallet.currency}</TableCell>
                  <TableCell className="font-mono text-sm truncate max-w-[200px]">
                    {wallet.address}
                  </TableCell>
                  <TableCell className="font-mono">
                    {wallet.balance} {wallet.currency}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>

      <Dialog open={addWalletOpen} onOpenChange={setAddWalletOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Crypto Wallet</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <label className="text-right">Currency</label>
              <select
                className="col-span-3 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={newWallet.currency}
                onChange={(e) => setNewWallet({ ...newWallet, currency: e.target.value })}
              >
                <option value="BTC">Bitcoin (BTC)</option>
                <option value="ETH">Ethereum (ETH)</option>
                <option value="SOL">Solana (SOL)</option>
              </select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label className="text-right">Address</label>
              <Input
                value={newWallet.address}
                onChange={(e) => setNewWallet({ ...newWallet, address: e.target.value })}
                className="col-span-3"
                placeholder={`Enter your ${newWallet.currency} wallet address`}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddWalletOpen(false)}>Cancel</Button>
            <Button 
              onClick={() => {
                if (!newWallet.address) return;
                createWalletMutation.mutate({
                  userId: DEFAULT_USER_ID,
                  ...newWallet,
                  balance: 0
                });
              }}
              disabled={!newWallet.address || createWalletMutation.isPending}
            >
              {createWalletMutation.isPending ? "Adding..." : "Add Wallet"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
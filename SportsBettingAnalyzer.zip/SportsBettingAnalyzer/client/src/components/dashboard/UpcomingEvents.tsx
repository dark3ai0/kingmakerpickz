import { useState } from "react";
import { formatDate, formatTime, formatOdds, getConfidenceLevelClass } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { type EventWithOdds } from "@shared/schema";

interface UpcomingEventsProps {
  events: EventWithOdds[];
  loading: boolean;
  onBetClick?: (eventId: number) => void;
}

export default function UpcomingEvents({ events, loading, onBetClick }: UpcomingEventsProps) {
  const [sportFilter, setSportFilter] = useState("all");
  
  // Map sport IDs to names
  const sportNames: Record<number, string> = {
    1: "NFL",
    2: "NBA",
    3: "MLB",
    4: "NHL"
  };
  
  // Filter events by sport
  const filteredEvents = sportFilter === "all" 
    ? events 
    : events.filter(event => event.sportId === parseInt(sportFilter));
  
  const handleSportChange = (value: string) => {
    setSportFilter(value);
  };
  
  return (
    <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
      <div className="px-4 py-3 bg-slate-100 border-b border-slate-200">
        <h3 className="font-semibold text-slate-800">Upcoming Events</h3>
      </div>
      <div className="p-4">
        <div className="flex justify-between items-center mb-4">
          <div className="relative">
            <Select value={sportFilter} onValueChange={handleSportChange}>
              <SelectTrigger className="w-[150px] pl-3 pr-8 py-1.5 border border-slate-300 rounded-md text-sm focus:outline-none">
                <SelectValue placeholder="All Sports" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sports</SelectItem>
                <SelectItem value="1">NFL</SelectItem>
                <SelectItem value="2">NBA</SelectItem>
                <SelectItem value="3">MLB</SelectItem>
                <SelectItem value="4">NHL</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md text-sm flex items-center">
              <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 4h13M3 8h9m-9 4h9m5-4v12m0 0l-4-4m4 4l4-4"></path>
              </svg>
              Sort
            </Button>
            <Button variant="outline" size="sm" className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md text-sm flex items-center">
              <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"></path>
              </svg>
              Filter
            </Button>
          </div>
        </div>
        
        <ScrollArea className="h-[400px]">
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left py-2 px-3 text-xs font-medium text-slate-500 uppercase tracking-wider">Event</th>
                  <th className="text-left py-2 px-3 text-xs font-medium text-slate-500 uppercase tracking-wider">Time</th>
                  <th className="text-left py-2 px-3 text-xs font-medium text-slate-500 uppercase tracking-wider">ML</th>
                  <th className="text-left py-2 px-3 text-xs font-medium text-slate-500 uppercase tracking-wider">Spread</th>
                  <th className="text-left py-2 px-3 text-xs font-medium text-slate-500 uppercase tracking-wider">Total</th>
                  <th className="text-left py-2 px-3 text-xs font-medium text-slate-500 uppercase tracking-wider">Value</th>
                  <th className="text-left py-2 px-3 text-xs font-medium text-slate-500 uppercase tracking-wider"></th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-500">
                      Loading events...
                    </td>
                  </tr>
                ) : filteredEvents.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-500">
                      No upcoming events found
                    </td>
                  </tr>
                ) : (
                  filteredEvents.map(event => (
                    <tr key={event.id} className="border-b border-slate-200 hover:bg-slate-50">
                      <td className="py-3 px-3">
                        <div>
                          <div className="font-medium">{event.homeTeam}</div>
                          <div className="text-slate-500">{event.awayTeam}</div>
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        <div className="text-sm">
                          <div>{formatDate(event.startTime)}</div>
                          <div className="text-slate-500">{formatTime(event.startTime)}</div>
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        <div>
                          <div className="font-mono">{event.odds ? formatOdds(event.odds.moneylineHome) : 'N/A'}</div>
                          <div className="font-mono text-slate-500">{event.odds ? formatOdds(event.odds.moneylineAway) : 'N/A'}</div>
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        <div>
                          <div className="font-mono">
                            {event.odds && event.odds.spreadHome !== null
                              ? `${event.odds.spreadHome > 0 ? '+' : ''}${event.odds.spreadHome} (${formatOdds(event.odds.spreadHomeOdds)})` 
                              : 'N/A'}
                          </div>
                          <div className="font-mono text-slate-500">
                            {event.odds && event.odds.spreadAway !== null
                              ? `${event.odds.spreadAway > 0 ? '+' : ''}${event.odds.spreadAway} (${formatOdds(event.odds.spreadAwayOdds)})` 
                              : 'N/A'}
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        <div className="font-mono">
                          <div>
                            {event.odds && event.odds.totalPoints !== null
                              ? `O ${event.odds.totalPoints} (${formatOdds(event.odds.totalOverOdds)})` 
                              : 'N/A'}
                          </div>
                          <div className="text-slate-500">
                            {event.odds && event.odds.totalPoints !== null
                              ? `U ${event.odds.totalPoints} (${formatOdds(event.odds.totalUnderOdds)})` 
                              : 'N/A'}
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        {/* For demo, use a random confidence level */}
                        <div className={`px-2 py-1 ${getConfidenceLevelClass(70 + Math.floor(Math.random() * 20))} rounded-full text-xs font-medium inline-block`}>
                          {Math.random() > 0.7 ? "High" : Math.random() > 0.3 ? "Medium" : "Low"} 
                          {` (${Math.floor(55 + Math.random() * 30)}%)`}
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        <button 
                          className="bg-cyan-700 text-white hover:bg-cyan-800 rounded-full p-1.5"
                          onClick={() => onBetClick && onBetClick(event.id)}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <line x1="12" y1="5" x2="12" y2="19"></line>
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                          </svg>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}

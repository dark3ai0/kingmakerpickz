import { useState } from "react";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";

export default function PerformanceCard() {
  const [timeframe, setTimeframe] = useState("30days");
  
  // Performance metrics - would come from API in real app
  const performanceData = {
    return: 8.6,
    winRate: 58.3,
    totalBets: 24,
    roi: 12.4,
    strategies: {
      moneyline: {
        winRate: 62.5,
        record: "10-6",
      },
      spread: {
        winRate: 55.6,
        record: "5-4",
      },
      overUnder: {
        winRate: 80.0,
        record: "4-1"
      }
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
      <div className="px-4 py-3 bg-slate-100 border-b border-slate-200 flex justify-between items-center">
        <h3 className="font-semibold text-slate-800">Performance</h3>
        <Select value={timeframe} onValueChange={setTimeframe}>
          <SelectTrigger className="w-[120px] h-auto py-0.5 text-xs border border-slate-300 rounded">
            <SelectValue placeholder="Last 30 Days" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7days">Last Week</SelectItem>
            <SelectItem value="30days">Last 30 Days</SelectItem>
            <SelectItem value="all">All Time</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="p-4">
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="p-3 bg-slate-50 rounded-lg">
            <div className="text-slate-500 text-xs mb-1">Return</div>
            <div className="text-success-600 font-semibold">+{performanceData.return}%</div>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg">
            <div className="text-slate-500 text-xs mb-1">Win Rate</div>
            <div className="font-semibold">{performanceData.winRate}%</div>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg">
            <div className="text-slate-500 text-xs mb-1">Total Bets</div>
            <div className="font-semibold">{performanceData.totalBets}</div>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg">
            <div className="text-slate-500 text-xs mb-1">ROI</div>
            <div className="text-success-600 font-semibold">{performanceData.roi}%</div>
          </div>
        </div>
        
        <div className="mb-4">
          <div className="mb-2 flex justify-between items-center">
            <span className="text-sm font-medium">Strategy Performance</span>
          </div>
          <div className="space-y-2">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span>Moneyline</span>
                <span className="text-success-600">
                  {performanceData.strategies.moneyline.winRate}% ({performanceData.strategies.moneyline.record})
                </span>
              </div>
              <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary-600" 
                  style={{ width: `${performanceData.strategies.moneyline.winRate}%` }}
                ></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span>Spread</span>
                <span className="text-success-600">
                  {performanceData.strategies.spread.winRate}% ({performanceData.strategies.spread.record})
                </span>
              </div>
              <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-slate-700" 
                  style={{ width: `${performanceData.strategies.spread.winRate}%` }}
                ></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span>Over/Under</span>
                <span className="text-success-600">
                  {performanceData.strategies.overUnder.winRate}% ({performanceData.strategies.overUnder.record})
                </span>
              </div>
              <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-success-600" 
                  style={{ width: `${performanceData.strategies.overUnder.winRate}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
        
        <Button 
          variant="outline"
          className="w-full py-2 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-md font-medium transition-colors"
        >
          View Detailed Stats
        </Button>
      </div>
    </div>
  );
}

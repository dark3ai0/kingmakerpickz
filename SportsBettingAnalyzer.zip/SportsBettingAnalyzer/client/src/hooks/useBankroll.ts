import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { updateUserBankroll, updateUserRiskLevel, updateUserUnitSize } from "@/lib/api";

// Default user ID for demo purposes
const DEFAULT_USER_ID = 1;

export function useBankroll(userId: number = DEFAULT_USER_ID) {
  // Get user data
  const { data: user, isLoading, error } = useQuery({
    queryKey: [`/api/user/${userId}`],
    refetchInterval: 60000, // Refetch every minute
  });

  // Calculate unit size based on bankroll and percentage
  const unitSize = user ? parseFloat(user.bankroll) * (user.unitSizePercent / 100) : 0;

  // Mutations for updating bankroll settings
  const updateBankrollMutation = useMutation({
    mutationFn: (amount: number) => updateUserBankroll(userId, amount),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/user/${userId}`] });
    },
  });

  const updateRiskLevelMutation = useMutation({
    mutationFn: (level: string) => updateUserRiskLevel(userId, level),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/user/${userId}`] });
    },
  });

  const updateUnitSizeMutation = useMutation({
    mutationFn: (percentage: number) => updateUserUnitSize(userId, percentage),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/user/${userId}`] });
    },
  });

  return {
    user,
    bankroll: user ? parseFloat(user.bankroll) : 0,
    riskLevel: user?.riskLevel,
    unitSizePercent: user?.unitSizePercent,
    unitSize,
    isLoading,
    error,
    updateBankroll: updateBankrollMutation.mutate,
    updateRiskLevel: updateRiskLevelMutation.mutate,
    updateUnitSize: updateUnitSizeMutation.mutate,
    isUpdating: updateBankrollMutation.isPending || 
                updateRiskLevelMutation.isPending || 
                updateUnitSizeMutation.isPending
  };
}

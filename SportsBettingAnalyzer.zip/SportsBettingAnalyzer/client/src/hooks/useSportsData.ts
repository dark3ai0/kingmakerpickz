import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { 
  getUpcomingEvents, 
  getTopRecommendations, 
  refreshSportsData,
  generateRecommendations,
  getAllSports
} from "@/lib/api";

export function useSportsData() {
  // Get top betting recommendations
  const { 
    data: topRecommendations = [],
    isLoading: isLoadingRecommendations,
    error: recommendationsError
  } = useQuery({
    queryKey: ['/api/recommendations/top'],
    refetchInterval: 60000 // Refetch every minute
  });

  // Get upcoming events
  const {
    data: upcomingEvents = [],
    isLoading: isLoadingEvents,
    error: eventsError
  } = useQuery({
    queryKey: ['/api/events/upcoming'],
    refetchInterval: 30000 // Refetch every 30 seconds
  });
  
  // Get all sports
  const {
    data: sports = [],
    isLoading: isLoadingSports,
    error: sportsError
  } = useQuery({
    queryKey: ['/api/sports']
  });

  // Mutation to refresh sports data
  const refreshDataMutation = useMutation({
    mutationFn: refreshSportsData,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/events/upcoming'] });
    }
  });

  // Mutation to generate new recommendations
  const generateRecommendationsMutation = useMutation({
    mutationFn: generateRecommendations,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/recommendations/top'] });
    }
  });

  return {
    topRecommendations,
    upcomingEvents,
    sports,
    isLoading: isLoadingRecommendations || isLoadingEvents || isLoadingSports,
    error: recommendationsError || eventsError || sportsError,
    refreshData: refreshDataMutation.mutate,
    generateRecommendations: generateRecommendationsMutation.mutate,
    isRefreshing: refreshDataMutation.isPending,
    isGenerating: generateRecommendationsMutation.isPending
  };
}
